<?php

namespace PHPMaker2023\vishaka2;

// Page object
$StudentDetailsDelete = &$Page;
?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { student_details: currentTable } });
var currentPageID = ew.PAGE_ID = "delete";
var currentForm;
var fstudent_detailsdelete;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery;
    let fields = currentTable.fields;

    // Form object
    let form = new ew.FormBuilder()
        .setId("fstudent_detailsdelete")
        .setPageId("delete")
        .build();
    window[form.id] = form;
    currentForm = form;
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<form name="fstudent_detailsdelete" id="fstudent_detailsdelete" class="ew-form ew-delete-form" action="<?= CurrentPageUrl(false) ?>" method="post" novalidate autocomplete="on">
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="student_details">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($Page->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?= HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid <?= $Page->TableGridClass ?>">
<div class="card-body ew-grid-middle-panel <?= $Page->TableContainerClass ?>" style="<?= $Page->TableContainerStyle ?>">
<table class="<?= $Page->TableClass ?>">
    <thead>
    <tr class="ew-table-header">
<?php if ($Page->AdmissionNo->Visible) { // Admission No ?>
        <th class="<?= $Page->AdmissionNo->headerCellClass() ?>"><span id="elh_student_details_AdmissionNo" class="student_details_AdmissionNo"><?= $Page->AdmissionNo->caption() ?></span></th>
<?php } ?>
<?php if ($Page->FullName->Visible) { // Full Name ?>
        <th class="<?= $Page->FullName->headerCellClass() ?>"><span id="elh_student_details_FullName" class="student_details_FullName"><?= $Page->FullName->caption() ?></span></th>
<?php } ?>
<?php if ($Page->NameWithInitials->Visible) { // Name With Initials ?>
        <th class="<?= $Page->NameWithInitials->headerCellClass() ?>"><span id="elh_student_details_NameWithInitials" class="student_details_NameWithInitials"><?= $Page->NameWithInitials->caption() ?></span></th>
<?php } ?>
<?php if ($Page->FathersName->Visible) { // Father's Name ?>
        <th class="<?= $Page->FathersName->headerCellClass() ?>"><span id="elh_student_details_FathersName" class="student_details_FathersName"><?= $Page->FathersName->caption() ?></span></th>
<?php } ?>
<?php if ($Page->MothersName->Visible) { // Mother's Name ?>
        <th class="<?= $Page->MothersName->headerCellClass() ?>"><span id="elh_student_details_MothersName" class="student_details_MothersName"><?= $Page->MothersName->caption() ?></span></th>
<?php } ?>
<?php if ($Page->Address->Visible) { // Address ?>
        <th class="<?= $Page->Address->headerCellClass() ?>"><span id="elh_student_details_Address" class="student_details_Address"><?= $Page->Address->caption() ?></span></th>
<?php } ?>
<?php if ($Page->Occupation->Visible) { // Occupation ?>
        <th class="<?= $Page->Occupation->headerCellClass() ?>"><span id="elh_student_details_Occupation" class="student_details_Occupation"><?= $Page->Occupation->caption() ?></span></th>
<?php } ?>
<?php if ($Page->TravellingMethodtoschoo->Visible) { // Travelling Method to schoo ?>
        <th class="<?= $Page->TravellingMethodtoschoo->headerCellClass() ?>"><span id="elh_student_details_TravellingMethodtoschoo" class="student_details_TravellingMethodtoschoo"><?= $Page->TravellingMethodtoschoo->caption() ?></span></th>
<?php } ?>
<?php if ($Page->inEmergencycontactno->Visible) { // in Emergency contact no ?>
        <th class="<?= $Page->inEmergencycontactno->headerCellClass() ?>"><span id="elh_student_details_inEmergencycontactno" class="student_details_inEmergencycontactno"><?= $Page->inEmergencycontactno->caption() ?></span></th>
<?php } ?>
<?php if ($Page->Specialneeds->Visible) { // Special needs ?>
        <th class="<?= $Page->Specialneeds->headerCellClass() ?>"><span id="elh_student_details_Specialneeds" class="student_details_Specialneeds"><?= $Page->Specialneeds->caption() ?></span></th>
<?php } ?>
<?php if ($Page->Grade->Visible) { // Grade ?>
        <th class="<?= $Page->Grade->headerCellClass() ?>"><span id="elh_student_details_Grade" class="student_details_Grade"><?= $Page->Grade->caption() ?></span></th>
<?php } ?>
<?php if ($Page->prefect->Visible) { // prefect ?>
        <th class="<?= $Page->prefect->headerCellClass() ?>"><span id="elh_student_details_prefect" class="student_details_prefect"><?= $Page->prefect->caption() ?></span></th>
<?php } ?>
    </tr>
    </thead>
    <tbody>
<?php
$Page->RecordCount = 0;
$i = 0;
while (!$Page->Recordset->EOF) {
    $Page->RecordCount++;
    $Page->RowCount++;

    // Set row properties
    $Page->resetAttributes();
    $Page->RowType = ROWTYPE_VIEW; // View

    // Get the field contents
    $Page->loadRowValues($Page->Recordset);

    // Render row
    $Page->renderRow();
?>
    <tr <?= $Page->rowAttributes() ?>>
<?php if ($Page->AdmissionNo->Visible) { // Admission No ?>
        <td<?= $Page->AdmissionNo->cellAttributes() ?>>
<span id="el<?= $Page->RowCount ?>_student_details_AdmissionNo" class="el_student_details_AdmissionNo">
<span<?= $Page->AdmissionNo->viewAttributes() ?>>
<?= $Page->AdmissionNo->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->FullName->Visible) { // Full Name ?>
        <td<?= $Page->FullName->cellAttributes() ?>>
<span id="el<?= $Page->RowCount ?>_student_details_FullName" class="el_student_details_FullName">
<span<?= $Page->FullName->viewAttributes() ?>>
<?= $Page->FullName->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->NameWithInitials->Visible) { // Name With Initials ?>
        <td<?= $Page->NameWithInitials->cellAttributes() ?>>
<span id="el<?= $Page->RowCount ?>_student_details_NameWithInitials" class="el_student_details_NameWithInitials">
<span<?= $Page->NameWithInitials->viewAttributes() ?>>
<?= $Page->NameWithInitials->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->FathersName->Visible) { // Father's Name ?>
        <td<?= $Page->FathersName->cellAttributes() ?>>
<span id="el<?= $Page->RowCount ?>_student_details_FathersName" class="el_student_details_FathersName">
<span<?= $Page->FathersName->viewAttributes() ?>>
<?= $Page->FathersName->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->MothersName->Visible) { // Mother's Name ?>
        <td<?= $Page->MothersName->cellAttributes() ?>>
<span id="el<?= $Page->RowCount ?>_student_details_MothersName" class="el_student_details_MothersName">
<span<?= $Page->MothersName->viewAttributes() ?>>
<?= $Page->MothersName->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->Address->Visible) { // Address ?>
        <td<?= $Page->Address->cellAttributes() ?>>
<span id="el<?= $Page->RowCount ?>_student_details_Address" class="el_student_details_Address">
<span<?= $Page->Address->viewAttributes() ?>>
<?= $Page->Address->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->Occupation->Visible) { // Occupation ?>
        <td<?= $Page->Occupation->cellAttributes() ?>>
<span id="el<?= $Page->RowCount ?>_student_details_Occupation" class="el_student_details_Occupation">
<span<?= $Page->Occupation->viewAttributes() ?>>
<?= $Page->Occupation->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->TravellingMethodtoschoo->Visible) { // Travelling Method to schoo ?>
        <td<?= $Page->TravellingMethodtoschoo->cellAttributes() ?>>
<span id="el<?= $Page->RowCount ?>_student_details_TravellingMethodtoschoo" class="el_student_details_TravellingMethodtoschoo">
<span<?= $Page->TravellingMethodtoschoo->viewAttributes() ?>>
<?= $Page->TravellingMethodtoschoo->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->inEmergencycontactno->Visible) { // in Emergency contact no ?>
        <td<?= $Page->inEmergencycontactno->cellAttributes() ?>>
<span id="el<?= $Page->RowCount ?>_student_details_inEmergencycontactno" class="el_student_details_inEmergencycontactno">
<span<?= $Page->inEmergencycontactno->viewAttributes() ?>>
<?= $Page->inEmergencycontactno->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->Specialneeds->Visible) { // Special needs ?>
        <td<?= $Page->Specialneeds->cellAttributes() ?>>
<span id="el<?= $Page->RowCount ?>_student_details_Specialneeds" class="el_student_details_Specialneeds">
<span<?= $Page->Specialneeds->viewAttributes() ?>>
<?= $Page->Specialneeds->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->Grade->Visible) { // Grade ?>
        <td<?= $Page->Grade->cellAttributes() ?>>
<span id="el<?= $Page->RowCount ?>_student_details_Grade" class="el_student_details_Grade">
<span<?= $Page->Grade->viewAttributes() ?>>
<?= $Page->Grade->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->prefect->Visible) { // prefect ?>
        <td<?= $Page->prefect->cellAttributes() ?>>
<span id="el<?= $Page->RowCount ?>_student_details_prefect" class="el_student_details_prefect">
<span<?= $Page->prefect->viewAttributes() ?>>
<?= $Page->prefect->getViewValue() ?></span>
</span>
</td>
<?php } ?>
    </tr>
<?php
    $Page->Recordset->moveNext();
}
$Page->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div class="ew-buttons ew-desktop-buttons">
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?= $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?= HtmlEncode(GetUrl($Page->getReturnUrl())) ?>"><?= $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function () {
    // Write your table-specific startup script here, no need to add script tags.
});
</script>
