<?php

namespace PHPMaker2023\vishaka;

// Page object
$StudentDetailsSearch = &$Page;
?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { student_details: currentTable } });
var currentPageID = ew.PAGE_ID = "search";
var currentForm;
var fstudent_detailssearch, currentSearchForm, currentAdvancedSearchForm;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery,
        fields = currentTable.fields;

    // Form object for search
    let form = new ew.FormBuilder()
        .setId("fstudent_detailssearch")
        .setPageId("search")
<?php if ($Page->IsModal && $Page->UseAjaxActions) { ?>
        .setSubmitWithFetch(true)
<?php } ?>

        // Add fields
        .addFields([
            ["AdmissionNo", [ew.Validators.integer], fields.AdmissionNo.isInvalid],
            ["FullName", [], fields.FullName.isInvalid],
            ["NameWithInitials", [], fields.NameWithInitials.isInvalid],
            ["FathersName", [], fields.FathersName.isInvalid],
            ["MothersName", [], fields.MothersName.isInvalid],
            ["Address", [], fields.Address.isInvalid],
            ["Occupation", [], fields.Occupation.isInvalid],
            ["TravellingMethodtoschoo", [], fields.TravellingMethodtoschoo.isInvalid],
            ["inEmergencycontactno", [ew.Validators.integer], fields.inEmergencycontactno.isInvalid],
            ["Specialneeds", [], fields.Specialneeds.isInvalid],
            ["Grade", [ew.Validators.integer], fields.Grade.isInvalid]
        ])
        // Validate form
        .setValidate(
            async function () {
                if (!this.validateRequired)
                    return true; // Ignore validation
                let fobj = this.getForm();

                // Validate fields
                if (!this.validateFields())
                    return false;

                // Call Form_CustomValidate event
                if (!(await this.customValidate?.(fobj) ?? true)) {
                    this.focus();
                    return false;
                }
                return true;
            }
        )

        // Form_CustomValidate
        .setCustomValidate(
            function (fobj) { // DO NOT CHANGE THIS LINE! (except for adding "async" keyword)!
                    // Your custom validation code here, return false if invalid.
                    return true;
                }
        )

        // Use JavaScript validation or not
        .setValidateRequired(ew.CLIENT_VALIDATE)

        // Dynamic selection lists
        .setQueryBuilderLists({
            "Specialneeds": <?= $Page->Specialneeds->toClientList($Page) ?>,
        })
        .build();
    window[form.id] = form;
<?php if ($Page->IsModal) { ?>
    currentAdvancedSearchForm = form;
<?php } else { ?>
    currentForm = form;
<?php } ?>
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<form name="fstudent_detailssearch" id="fstudent_detailssearch" class="<?= $Page->FormClassName ?>" action="<?= HtmlEncode(GetUrl("StudentDetailsList")) ?>" method="post" novalidate autocomplete="on">
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="student_details">
<input type="hidden" name="action" id="action" value="search">
<?php if ($Page->IsModal && $Page->UseAjaxActions) { ?>
<input type="hidden" name="modal" value="1">
<?php } ?>
<input type="hidden" name="rules" value="<?= HtmlEncode($Page->getSessionRules()) ?>">
<template id="tpx_student_details_AdmissionNo" class="student_detailssearch"><span id="el_student_details_AdmissionNo" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->AdmissionNo->getInputTextType() ?>" name="x_AdmissionNo" id="x_AdmissionNo" data-table="student_details" data-field="x_AdmissionNo" value="<?= $Page->AdmissionNo->EditValue ?>" size="30" placeholder="<?= HtmlEncode($Page->AdmissionNo->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->AdmissionNo->formatPattern()) ?>"<?= $Page->AdmissionNo->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->AdmissionNo->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_student_details_FullName" class="student_detailssearch"><span id="el_student_details_FullName" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->FullName->getInputTextType() ?>" name="x_FullName" id="x_FullName" data-table="student_details" data-field="x_FullName" value="<?= $Page->FullName->EditValue ?>" size="35" placeholder="<?= HtmlEncode($Page->FullName->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->FullName->formatPattern()) ?>"<?= $Page->FullName->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->FullName->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_student_details_NameWithInitials" class="student_detailssearch"><span id="el_student_details_NameWithInitials" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->NameWithInitials->getInputTextType() ?>" name="x_NameWithInitials" id="x_NameWithInitials" data-table="student_details" data-field="x_NameWithInitials" value="<?= $Page->NameWithInitials->EditValue ?>" size="35" placeholder="<?= HtmlEncode($Page->NameWithInitials->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->NameWithInitials->formatPattern()) ?>"<?= $Page->NameWithInitials->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->NameWithInitials->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_student_details_FathersName" class="student_detailssearch"><span id="el_student_details_FathersName" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->FathersName->getInputTextType() ?>" name="x_FathersName" id="x_FathersName" data-table="student_details" data-field="x_FathersName" value="<?= $Page->FathersName->EditValue ?>" size="35" placeholder="<?= HtmlEncode($Page->FathersName->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->FathersName->formatPattern()) ?>"<?= $Page->FathersName->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->FathersName->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_student_details_MothersName" class="student_detailssearch"><span id="el_student_details_MothersName" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->MothersName->getInputTextType() ?>" name="x_MothersName" id="x_MothersName" data-table="student_details" data-field="x_MothersName" value="<?= $Page->MothersName->EditValue ?>" size="35" placeholder="<?= HtmlEncode($Page->MothersName->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->MothersName->formatPattern()) ?>"<?= $Page->MothersName->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->MothersName->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_student_details_Address" class="student_detailssearch"><span id="el_student_details_Address" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->Address->getInputTextType() ?>" name="x_Address" id="x_Address" data-table="student_details" data-field="x_Address" value="<?= $Page->Address->EditValue ?>" size="35" placeholder="<?= HtmlEncode($Page->Address->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->Address->formatPattern()) ?>"<?= $Page->Address->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->Address->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_student_details_Occupation" class="student_detailssearch"><span id="el_student_details_Occupation" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->Occupation->getInputTextType() ?>" name="x_Occupation" id="x_Occupation" data-table="student_details" data-field="x_Occupation" value="<?= $Page->Occupation->EditValue ?>" size="35" placeholder="<?= HtmlEncode($Page->Occupation->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->Occupation->formatPattern()) ?>"<?= $Page->Occupation->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->Occupation->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_student_details_TravellingMethodtoschoo" class="student_detailssearch"><span id="el_student_details_TravellingMethodtoschoo" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->TravellingMethodtoschoo->getInputTextType() ?>" name="x_TravellingMethodtoschoo" id="x_TravellingMethodtoschoo" data-table="student_details" data-field="x_TravellingMethodtoschoo" value="<?= $Page->TravellingMethodtoschoo->EditValue ?>" size="35" placeholder="<?= HtmlEncode($Page->TravellingMethodtoschoo->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->TravellingMethodtoschoo->formatPattern()) ?>"<?= $Page->TravellingMethodtoschoo->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->TravellingMethodtoschoo->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_student_details_inEmergencycontactno" class="student_detailssearch"><span id="el_student_details_inEmergencycontactno" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->inEmergencycontactno->getInputTextType() ?>" name="x_inEmergencycontactno" id="x_inEmergencycontactno" data-table="student_details" data-field="x_inEmergencycontactno" value="<?= $Page->inEmergencycontactno->EditValue ?>" size="30" placeholder="<?= HtmlEncode($Page->inEmergencycontactno->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->inEmergencycontactno->formatPattern()) ?>"<?= $Page->inEmergencycontactno->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->inEmergencycontactno->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_student_details_Specialneeds" class="student_detailssearch"><span id="el_student_details_Specialneeds" class="ew-search-field ew-search-field-single">
<div class="form-check d-inline-block">
    <input type="checkbox" class="form-check-input<?= $Page->Specialneeds->isInvalidClass() ?>" data-table="student_details" data-field="x_Specialneeds" data-boolean name="x_Specialneeds" id="x_Specialneeds" value="1"<?= ConvertToBool($Page->Specialneeds->AdvancedSearch->SearchValue) ? " checked" : "" ?><?= $Page->Specialneeds->editAttributes() ?>>
    <div class="invalid-feedback"><?= $Page->Specialneeds->getErrorMessage(false) ?></div>
</div>
</span></template>
<template id="tpx_student_details_Grade" class="student_detailssearch"><span id="el_student_details_Grade" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->Grade->getInputTextType() ?>" name="x_Grade" id="x_Grade" data-table="student_details" data-field="x_Grade" value="<?= $Page->Grade->EditValue ?>" size="30" placeholder="<?= HtmlEncode($Page->Grade->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->Grade->formatPattern()) ?>"<?= $Page->Grade->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->Grade->getErrorMessage(false) ?></div>
</span></template>
<div id="student_details_query_builder" class="query-builder mb-3"></div>
<div class="btn-group mb-3 query-btn-group"></div>
<button type="button" id="btn-view-rules" class="btn btn-primary d-none disabled" title="<?= HtmlEncode($Language->phrase("View", true)) ?>"><i class="fa-solid fa-eye ew-icon"></i></button>
<button type="button" id="btn-clear-rules" class="btn btn-primary d-none disabled" title="<?= HtmlEncode($Language->phrase("Clear", true)) ?>"><i class="fa-solid fa-xmark ew-icon"></i></button>
<script>
// Filter builder
loadjs.ready(["wrapper", "head"], () => {
    let filters = [
            {
                id: "AdmissionNo",
                type: "integer",
                label: currentTable.fields.AdmissionNo.caption,
                operators: currentTable.fields.AdmissionNo.clientSearchOperators,
                default_operator: "equal",
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(fstudent_detailssearch.fields.AdmissionNo.validators),
                data: {
                    format: currentTable.fields.AdmissionNo.clientFormatPattern
                }
            },
            {
                id: "FullName",
                type: "string",
                label: currentTable.fields.FullName.caption,
                operators: currentTable.fields.FullName.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(fstudent_detailssearch.fields.FullName.validators),
                data: {
                    format: currentTable.fields.FullName.clientFormatPattern
                }
            },
            {
                id: "NameWithInitials",
                type: "string",
                label: currentTable.fields.NameWithInitials.caption,
                operators: currentTable.fields.NameWithInitials.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(fstudent_detailssearch.fields.NameWithInitials.validators),
                data: {
                    format: currentTable.fields.NameWithInitials.clientFormatPattern
                }
            },
            {
                id: "FathersName",
                type: "string",
                label: currentTable.fields.FathersName.caption,
                operators: currentTable.fields.FathersName.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(fstudent_detailssearch.fields.FathersName.validators),
                data: {
                    format: currentTable.fields.FathersName.clientFormatPattern
                }
            },
            {
                id: "MothersName",
                type: "string",
                label: currentTable.fields.MothersName.caption,
                operators: currentTable.fields.MothersName.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(fstudent_detailssearch.fields.MothersName.validators),
                data: {
                    format: currentTable.fields.MothersName.clientFormatPattern
                }
            },
            {
                id: "Address",
                type: "string",
                label: currentTable.fields.Address.caption,
                operators: currentTable.fields.Address.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(fstudent_detailssearch.fields.Address.validators),
                data: {
                    format: currentTable.fields.Address.clientFormatPattern
                }
            },
            {
                id: "Occupation",
                type: "string",
                label: currentTable.fields.Occupation.caption,
                operators: currentTable.fields.Occupation.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(fstudent_detailssearch.fields.Occupation.validators),
                data: {
                    format: currentTable.fields.Occupation.clientFormatPattern
                }
            },
            {
                id: "TravellingMethodtoschoo",
                type: "string",
                label: currentTable.fields.TravellingMethodtoschoo.caption,
                operators: currentTable.fields.TravellingMethodtoschoo.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(fstudent_detailssearch.fields.TravellingMethodtoschoo.validators),
                data: {
                    format: currentTable.fields.TravellingMethodtoschoo.clientFormatPattern
                }
            },
            {
                id: "inEmergencycontactno",
                type: "integer",
                label: currentTable.fields.inEmergencycontactno.caption,
                operators: currentTable.fields.inEmergencycontactno.clientSearchOperators,
                default_operator: "equal",
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(fstudent_detailssearch.fields.inEmergencycontactno.validators),
                data: {
                    format: currentTable.fields.inEmergencycontactno.clientFormatPattern
                }
            },
            {
                id: "Specialneeds",
                type: "boolean",
                label: currentTable.fields.Specialneeds.caption,
                operators: currentTable.fields.Specialneeds.clientSearchOperators,
                default_operator: "equal",
                input: ew.getQueryBuilderFilterInput(),
                valueSetter: ew.getQueryBuilderValueSetter(),
                validation: ew.getQueryBuilderFilterValidation(fstudent_detailssearch.fields.Specialneeds.validators),
                data: {
                    format: currentTable.fields.Specialneeds.clientFormatPattern
                }
            },
            {
                id: "Grade",
                type: "integer",
                label: currentTable.fields.Grade.caption,
                operators: currentTable.fields.Grade.clientSearchOperators,
                default_operator: "equal",
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(fstudent_detailssearch.fields.Grade.validators),
                data: {
                    format: currentTable.fields.Grade.clientFormatPattern
                }
            },
        ],
        $ = jQuery,
        $qb = $("#student_details_query_builder"),
        args = {},
        rules = ew.parseJson($("#fstudent_detailssearch input[name=rules]").val()),
        queryBuilderOptions = Object.assign({}, ew.queryBuilderOptions),
        allowViewRules = queryBuilderOptions.allowViewRules,
        allowClearRules = queryBuilderOptions.allowClearRules,
        hasRules = group => Array.isArray(group?.rules) && group.rules.length > 0,
        getRules = () => $qb.queryBuilder("getRules", { skip_empty: true }),
        getSql = () => $qb.queryBuilder("getSQL", false, false, rules)?.sql;
    delete queryBuilderOptions.allowViewRules;
    delete queryBuilderOptions.allowClearRules;
    args.options = ew.deepAssign({
        plugins: Object.assign({}, ew.queryBuilderPlugins),
        lang: ew.language.phrase("querybuilderjs"),
        select_placeholder: ew.language.phrase("PleaseSelect"),
        inputs_separator: `<div class="d-inline-flex ms-2 me-2">${ew.language.phrase("AND")}</div>`, // For "between"
        filters,
        rules
    }, queryBuilderOptions);
    $qb.trigger("querybuilder", [args]);
    $qb.queryBuilder(args.options).on("rulesChanged.queryBuilder", () => {
        let rules = getRules();
        !ew.DEBUG || console.log(rules, getSql());
        $("#btn-reset, #btn-action, #btn-clear-rules, #btn-view-rules").toggleClass("disabled", !rules);
    }).on("afterCreateRuleInput.queryBuilder", function(e, rule) {
        let select = rule.$el.find(".rule-value-container").find("selection-list")[0];
        if (select) { // Selection list
            let id = select.dataset.field.replace("^x_", ""),
                form = ew.forms.get(select);
            form.updateList(select, undefined, undefined, true); // Update immediately
        }
    });
    $("#fstudent_detailssearch").on("beforesubmit", function () {
        this.rules.value = JSON.stringify(getRules());
    });
    $("#btn-reset").toggleClass("d-none", false).on("click", () => {
        hasRules(rules) ? $qb.queryBuilder("setRules", rules) : $qb.queryBuilder("reset");
        return false;
    });
    $("#btn-action").toggleClass("d-none", false);
    if (allowClearRules) {
        $("#btn-clear-rules").appendTo(".query-btn-group").removeClass("d-none").on("click", () => $qb.queryBuilder("reset"));
    }
    if (allowViewRules) {
        $("#btn-view-rules").appendTo(".query-btn-group").removeClass("d-none").on("click", () => {
            let rules = getRules();
            if (hasRules(rules)) {
                let sql = getSql();
                ew.alert(sql ? '<pre class="text-start fs-6">' + sql + '</pre>' : '', "dark");
                !ew.DEBUG || console.log(rules, sql);
            } else {
                ew.alert(ew.language.phrase("EmptyLabel"));
            }
        });
    }
    if (hasRules(rules)) { // Enable buttons if rules exist initially
        $("#btn-reset, #btn-action, #btn-clear-rules, #btn-view-rules").removeClass("disabled");
    }
});
</script>
<?= $Page->IsModal ? '<template class="ew-modal-buttons">' : '<div class="row ew-buttons">' ?><!-- buttons .row -->
    <div class="<?= $Page->OffsetColumnClass ?>"><!-- buttons offset -->
        <button class="btn btn-primary ew-btn d-none disabled" name="btn-action" id="btn-action" type="submit" form="fstudent_detailssearch" formaction="<?= HtmlEncode(GetUrl("StudentDetailsList")) ?>" data-ajax="<?= $Page->UseAjaxActions ? "true" : "false" ?>"><?= $Language->phrase("Search") ?></button>
        <?php if ($Page->IsModal) { ?>
        <button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" form="fstudent_detailssearch"><?= $Language->phrase("Cancel") ?></button>
        <?php } else { ?>
        <button class="btn btn-default ew-btn d-none disabled" name="btn-reset" id="btn-reset" type="button" form="fstudent_detailssearch" data-ew-action="reload"><?= $Language->phrase("Reset") ?></button>
        <?php } ?>
    </div><!-- /buttons offset -->
<?= $Page->IsModal ? "</template>" : "</div>" ?><!-- /buttons .row -->
</form>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<script>
// Field event handlers
loadjs.ready("head", function() {
    ew.addEventHandlers("student_details");
});
</script>
<script>
loadjs.ready("load", function () {
    // Write your table-specific startup script here, no need to add script tags.
});
</script>
