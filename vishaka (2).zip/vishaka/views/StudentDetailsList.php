<?php

namespace PHPMaker2023\vishaka2;

// Page object
$StudentDetailsList = &$Page;
?>
<?php if (!$Page->isExport()) { ?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { student_details: currentTable } });
var currentPageID = ew.PAGE_ID = "list";
var currentForm;
var <?= $Page->FormName ?>;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery;
    let fields = currentTable.fields;

    // Form object
    let form = new ew.FormBuilder()
        .setId("<?= $Page->FormName ?>")
        .setPageId("list")
        .setSubmitWithFetch(<?= $Page->UseAjaxActions ? "true" : "false" ?>)
        .setFormKeyCountName("<?= $Page->FormKeyCountName ?>")

        // Add fields
        .setFields([
            ["AdmissionNo", [fields.AdmissionNo.visible && fields.AdmissionNo.required ? ew.Validators.required(fields.AdmissionNo.caption) : null, ew.Validators.integer], fields.AdmissionNo.isInvalid],
            ["FullName", [fields.FullName.visible && fields.FullName.required ? ew.Validators.required(fields.FullName.caption) : null], fields.FullName.isInvalid],
            ["NameWithInitials", [fields.NameWithInitials.visible && fields.NameWithInitials.required ? ew.Validators.required(fields.NameWithInitials.caption) : null], fields.NameWithInitials.isInvalid],
            ["FathersName", [fields.FathersName.visible && fields.FathersName.required ? ew.Validators.required(fields.FathersName.caption) : null], fields.FathersName.isInvalid],
            ["MothersName", [fields.MothersName.visible && fields.MothersName.required ? ew.Validators.required(fields.MothersName.caption) : null], fields.MothersName.isInvalid],
            ["Address", [fields.Address.visible && fields.Address.required ? ew.Validators.required(fields.Address.caption) : null], fields.Address.isInvalid],
            ["Occupation", [fields.Occupation.visible && fields.Occupation.required ? ew.Validators.required(fields.Occupation.caption) : null], fields.Occupation.isInvalid],
            ["TravellingMethodtoschoo", [fields.TravellingMethodtoschoo.visible && fields.TravellingMethodtoschoo.required ? ew.Validators.required(fields.TravellingMethodtoschoo.caption) : null], fields.TravellingMethodtoschoo.isInvalid],
            ["inEmergencycontactno", [fields.inEmergencycontactno.visible && fields.inEmergencycontactno.required ? ew.Validators.required(fields.inEmergencycontactno.caption) : null, ew.Validators.integer], fields.inEmergencycontactno.isInvalid],
            ["Specialneeds", [fields.Specialneeds.visible && fields.Specialneeds.required ? ew.Validators.required(fields.Specialneeds.caption) : null], fields.Specialneeds.isInvalid],
            ["Grade", [fields.Grade.visible && fields.Grade.required ? ew.Validators.required(fields.Grade.caption) : null], fields.Grade.isInvalid],
            ["prefect", [fields.prefect.visible && fields.prefect.required ? ew.Validators.required(fields.prefect.caption) : null], fields.prefect.isInvalid]
        ])

        // Check empty row
        .setEmptyRow(
            function (rowIndex) {
                let fobj = this.getForm(),
                    fields = [["AdmissionNo",false],["FullName",false],["NameWithInitials",false],["FathersName",false],["MothersName",false],["Address",false],["Occupation",false],["TravellingMethodtoschoo",false],["inEmergencycontactno",false],["Specialneeds",true],["Grade",false],["prefect",true]];
                if (fields.some(field => ew.valueChanged(fobj, rowIndex, ...field)))
                    return false;
                return true;
            }
        )

        // Form_CustomValidate
        .setCustomValidate(
            function (fobj) { // DO NOT CHANGE THIS LINE! (except for adding "async" keyword)!
                    // Your custom validation code here, return false if invalid.
                    return true;
                }
        )

        // Use JavaScript validation or not
        .setValidateRequired(ew.CLIENT_VALIDATE)

        // Dynamic selection lists
        .setLists({
            "AdmissionNo": <?= $Page->AdmissionNo->toClientList($Page) ?>,
            "FullName": <?= $Page->FullName->toClientList($Page) ?>,
            "NameWithInitials": <?= $Page->NameWithInitials->toClientList($Page) ?>,
            "FathersName": <?= $Page->FathersName->toClientList($Page) ?>,
            "MothersName": <?= $Page->MothersName->toClientList($Page) ?>,
            "Address": <?= $Page->Address->toClientList($Page) ?>,
            "Occupation": <?= $Page->Occupation->toClientList($Page) ?>,
            "TravellingMethodtoschoo": <?= $Page->TravellingMethodtoschoo->toClientList($Page) ?>,
            "inEmergencycontactno": <?= $Page->inEmergencycontactno->toClientList($Page) ?>,
            "Specialneeds": <?= $Page->Specialneeds->toClientList($Page) ?>,
            "Grade": <?= $Page->Grade->toClientList($Page) ?>,
            "prefect": <?= $Page->prefect->toClientList($Page) ?>,
        })
        .build();
    window[form.id] = form;
    currentForm = form;
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php } ?>
<?php if (!$Page->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($Page->TotalRecords > 0 && $Page->ExportOptions->visible()) { ?>
<?php $Page->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($Page->ImportOptions->visible()) { ?>
<?php $Page->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($Page->SearchOptions->visible()) { ?>
<?php $Page->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($Page->FilterOptions->visible()) { ?>
<?php $Page->FilterOptions->render("body") ?>
<?php } ?>
</div>
<?php } ?>
<?php if ($Page->ShowCurrentFilter) { ?>
<?php $Page->showFilterList() ?>
<?php } ?>
<?php if ($Security->canSearch()) { ?>
<?php if (!$Page->isExport() && !($Page->CurrentAction && $Page->CurrentAction != "search") && $Page->hasSearchFields()) { ?>
<form name="fstudent_detailssrch" id="fstudent_detailssrch" class="ew-form ew-ext-search-form" action="<?= CurrentPageUrl(false) ?>" novalidate autocomplete="on">
<div id="fstudent_detailssrch_search_panel" class="mb-2 mb-sm-0 <?= $Page->SearchPanelClass ?>"><!-- .ew-search-panel -->
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { student_details: currentTable } });
var currentForm;
var fstudent_detailssrch, currentSearchForm, currentAdvancedSearchForm;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery,
        fields = currentTable.fields;

    // Form object for search
    let form = new ew.FormBuilder()
        .setId("fstudent_detailssrch")
        .setPageId("list")
<?php if ($Page->UseAjaxActions) { ?>
        .setSubmitWithFetch(true)
<?php } ?>

        // Add fields
        .addFields([
            ["AdmissionNo", [], fields.AdmissionNo.isInvalid],
            ["FullName", [], fields.FullName.isInvalid],
            ["NameWithInitials", [], fields.NameWithInitials.isInvalid],
            ["FathersName", [], fields.FathersName.isInvalid],
            ["MothersName", [], fields.MothersName.isInvalid],
            ["Address", [], fields.Address.isInvalid],
            ["Occupation", [], fields.Occupation.isInvalid],
            ["TravellingMethodtoschoo", [], fields.TravellingMethodtoschoo.isInvalid],
            ["inEmergencycontactno", [], fields.inEmergencycontactno.isInvalid],
            ["Specialneeds", [], fields.Specialneeds.isInvalid],
            ["Grade", [], fields.Grade.isInvalid],
            ["prefect", [], fields.prefect.isInvalid]
        ])
        // Validate form
        .setValidate(
            async function () {
                if (!this.validateRequired)
                    return true; // Ignore validation
                let fobj = this.getForm();

                // Validate fields
                if (!this.validateFields())
                    return false;

                // Call Form_CustomValidate event
                if (!(await this.customValidate?.(fobj) ?? true)) {
                    this.focus();
                    return false;
                }
                return true;
            }
        )

        // Form_CustomValidate
        .setCustomValidate(
            function (fobj) { // DO NOT CHANGE THIS LINE! (except for adding "async" keyword)!
                    // Your custom validation code here, return false if invalid.
                    return true;
                }
        )

        // Use JavaScript validation or not
        .setValidateRequired(ew.CLIENT_VALIDATE)

        // Dynamic selection lists
        .setLists({
            "AdmissionNo": <?= $Page->AdmissionNo->toClientList($Page) ?>,
            "FullName": <?= $Page->FullName->toClientList($Page) ?>,
            "NameWithInitials": <?= $Page->NameWithInitials->toClientList($Page) ?>,
            "FathersName": <?= $Page->FathersName->toClientList($Page) ?>,
            "MothersName": <?= $Page->MothersName->toClientList($Page) ?>,
            "Address": <?= $Page->Address->toClientList($Page) ?>,
            "Occupation": <?= $Page->Occupation->toClientList($Page) ?>,
            "TravellingMethodtoschoo": <?= $Page->TravellingMethodtoschoo->toClientList($Page) ?>,
            "inEmergencycontactno": <?= $Page->inEmergencycontactno->toClientList($Page) ?>,
            "Specialneeds": <?= $Page->Specialneeds->toClientList($Page) ?>,
            "Grade": <?= $Page->Grade->toClientList($Page) ?>,
            "prefect": <?= $Page->prefect->toClientList($Page) ?>,
        })

        // Filters
        .setFilterList(<?= $Page->getFilterList() ?>)
        .build();
    window[form.id] = form;
    currentSearchForm = form;
    loadjs.done(form.id);
});
</script>
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="student_details">
<div class="ew-extended-search container-fluid ps-2">
<div class="row mb-0<?= ($Page->SearchFieldsPerRow > 0) ? " row-cols-sm-" . $Page->SearchFieldsPerRow : "" ?>">
<?php
// Render search row
$Page->RowType = ROWTYPE_SEARCH;
$Page->resetAttributes();
$Page->renderRow();
?>
<?php if ($Page->AdmissionNo->Visible) { // Admission No ?>
<?php
if (!$Page->AdmissionNo->UseFilter) {
    $Page->SearchColumnCount++;
}
?>
    <div id="xs_AdmissionNo" class="col-sm-auto d-sm-flex align-items-start mb-3 px-0 pe-sm-2<?= $Page->AdmissionNo->UseFilter ? " ew-filter-field" : "" ?>">
        <select
            id="x_AdmissionNo"
            name="x_AdmissionNo[]"
            class="form-control ew-select<?= $Page->AdmissionNo->isInvalidClass() ?>"
            data-select2-id="fstudent_detailssrch_x_AdmissionNo"
            data-table="student_details"
            data-field="x_AdmissionNo"
            data-caption="<?= HtmlEncode(RemoveHtml($Page->AdmissionNo->caption())) ?>"
            data-filter="true"
            multiple
            size="1"
            data-value-separator="<?= $Page->AdmissionNo->displayValueSeparatorAttribute() ?>"
            data-placeholder="<?= HtmlEncode($Page->AdmissionNo->getPlaceHolder()) ?>"
            data-ew-action="update-options"
            <?= $Page->AdmissionNo->editAttributes() ?>>
            <?= $Page->AdmissionNo->selectOptionListHtml("x_AdmissionNo", true) ?>
        </select>
        <div class="invalid-feedback"><?= $Page->AdmissionNo->getErrorMessage(false) ?></div>
        <script>
        loadjs.ready("fstudent_detailssrch", function() {
            var options = {
                name: "x_AdmissionNo",
                selectId: "fstudent_detailssrch_x_AdmissionNo",
                ajax: { id: "x_AdmissionNo", form: "fstudent_detailssrch", limit: ew.FILTER_PAGE_SIZE, data: { ajax: "filter" } }
            };
            options = Object.assign({}, ew.filterOptions, options, ew.vars.tables.student_details.fields.AdmissionNo.filterOptions);
            ew.createFilter(options);
        });
        </script>
    </div><!-- /.col-sm-auto -->
<?php } ?>
<?php if ($Page->FullName->Visible) { // Full Name ?>
<?php
if (!$Page->FullName->UseFilter) {
    $Page->SearchColumnCount++;
}
?>
    <div id="xs_FullName" class="col-sm-auto d-sm-flex align-items-start mb-3 px-0 pe-sm-2<?= $Page->FullName->UseFilter ? " ew-filter-field" : "" ?>">
        <select
            id="x_FullName"
            name="x_FullName[]"
            class="form-control ew-select<?= $Page->FullName->isInvalidClass() ?>"
            data-select2-id="fstudent_detailssrch_x_FullName"
            data-table="student_details"
            data-field="x_FullName"
            data-caption="<?= HtmlEncode(RemoveHtml($Page->FullName->caption())) ?>"
            data-filter="true"
            multiple
            size="1"
            data-value-separator="<?= $Page->FullName->displayValueSeparatorAttribute() ?>"
            data-placeholder="<?= HtmlEncode($Page->FullName->getPlaceHolder()) ?>"
            data-ew-action="update-options"
            <?= $Page->FullName->editAttributes() ?>>
            <?= $Page->FullName->selectOptionListHtml("x_FullName", true) ?>
        </select>
        <div class="invalid-feedback"><?= $Page->FullName->getErrorMessage(false) ?></div>
        <script>
        loadjs.ready("fstudent_detailssrch", function() {
            var options = {
                name: "x_FullName",
                selectId: "fstudent_detailssrch_x_FullName",
                ajax: { id: "x_FullName", form: "fstudent_detailssrch", limit: ew.FILTER_PAGE_SIZE, data: { ajax: "filter" } }
            };
            options = Object.assign({}, ew.filterOptions, options, ew.vars.tables.student_details.fields.FullName.filterOptions);
            ew.createFilter(options);
        });
        </script>
    </div><!-- /.col-sm-auto -->
<?php } ?>
<?php if ($Page->NameWithInitials->Visible) { // Name With Initials ?>
<?php
if (!$Page->NameWithInitials->UseFilter) {
    $Page->SearchColumnCount++;
}
?>
    <div id="xs_NameWithInitials" class="col-sm-auto d-sm-flex align-items-start mb-3 px-0 pe-sm-2<?= $Page->NameWithInitials->UseFilter ? " ew-filter-field" : "" ?>">
        <select
            id="x_NameWithInitials"
            name="x_NameWithInitials[]"
            class="form-control ew-select<?= $Page->NameWithInitials->isInvalidClass() ?>"
            data-select2-id="fstudent_detailssrch_x_NameWithInitials"
            data-table="student_details"
            data-field="x_NameWithInitials"
            data-caption="<?= HtmlEncode(RemoveHtml($Page->NameWithInitials->caption())) ?>"
            data-filter="true"
            multiple
            size="1"
            data-value-separator="<?= $Page->NameWithInitials->displayValueSeparatorAttribute() ?>"
            data-placeholder="<?= HtmlEncode($Page->NameWithInitials->getPlaceHolder()) ?>"
            data-ew-action="update-options"
            <?= $Page->NameWithInitials->editAttributes() ?>>
            <?= $Page->NameWithInitials->selectOptionListHtml("x_NameWithInitials", true) ?>
        </select>
        <div class="invalid-feedback"><?= $Page->NameWithInitials->getErrorMessage(false) ?></div>
        <script>
        loadjs.ready("fstudent_detailssrch", function() {
            var options = {
                name: "x_NameWithInitials",
                selectId: "fstudent_detailssrch_x_NameWithInitials",
                ajax: { id: "x_NameWithInitials", form: "fstudent_detailssrch", limit: ew.FILTER_PAGE_SIZE, data: { ajax: "filter" } }
            };
            options = Object.assign({}, ew.filterOptions, options, ew.vars.tables.student_details.fields.NameWithInitials.filterOptions);
            ew.createFilter(options);
        });
        </script>
    </div><!-- /.col-sm-auto -->
<?php } ?>
<?php if ($Page->FathersName->Visible) { // Father's Name ?>
<?php
if (!$Page->FathersName->UseFilter) {
    $Page->SearchColumnCount++;
}
?>
    <div id="xs_FathersName" class="col-sm-auto d-sm-flex align-items-start mb-3 px-0 pe-sm-2<?= $Page->FathersName->UseFilter ? " ew-filter-field" : "" ?>">
        <select
            id="x_FathersName"
            name="x_FathersName[]"
            class="form-control ew-select<?= $Page->FathersName->isInvalidClass() ?>"
            data-select2-id="fstudent_detailssrch_x_FathersName"
            data-table="student_details"
            data-field="x_FathersName"
            data-caption="<?= HtmlEncode(RemoveHtml($Page->FathersName->caption())) ?>"
            data-filter="true"
            multiple
            size="1"
            data-value-separator="<?= $Page->FathersName->displayValueSeparatorAttribute() ?>"
            data-placeholder="<?= HtmlEncode($Page->FathersName->getPlaceHolder()) ?>"
            data-ew-action="update-options"
            <?= $Page->FathersName->editAttributes() ?>>
            <?= $Page->FathersName->selectOptionListHtml("x_FathersName", true) ?>
        </select>
        <div class="invalid-feedback"><?= $Page->FathersName->getErrorMessage(false) ?></div>
        <script>
        loadjs.ready("fstudent_detailssrch", function() {
            var options = {
                name: "x_FathersName",
                selectId: "fstudent_detailssrch_x_FathersName",
                ajax: { id: "x_FathersName", form: "fstudent_detailssrch", limit: ew.FILTER_PAGE_SIZE, data: { ajax: "filter" } }
            };
            options = Object.assign({}, ew.filterOptions, options, ew.vars.tables.student_details.fields.FathersName.filterOptions);
            ew.createFilter(options);
        });
        </script>
    </div><!-- /.col-sm-auto -->
<?php } ?>
<?php if ($Page->MothersName->Visible) { // Mother's Name ?>
<?php
if (!$Page->MothersName->UseFilter) {
    $Page->SearchColumnCount++;
}
?>
    <div id="xs_MothersName" class="col-sm-auto d-sm-flex align-items-start mb-3 px-0 pe-sm-2<?= $Page->MothersName->UseFilter ? " ew-filter-field" : "" ?>">
        <select
            id="x_MothersName"
            name="x_MothersName[]"
            class="form-control ew-select<?= $Page->MothersName->isInvalidClass() ?>"
            data-select2-id="fstudent_detailssrch_x_MothersName"
            data-table="student_details"
            data-field="x_MothersName"
            data-caption="<?= HtmlEncode(RemoveHtml($Page->MothersName->caption())) ?>"
            data-filter="true"
            multiple
            size="1"
            data-value-separator="<?= $Page->MothersName->displayValueSeparatorAttribute() ?>"
            data-placeholder="<?= HtmlEncode($Page->MothersName->getPlaceHolder()) ?>"
            data-ew-action="update-options"
            <?= $Page->MothersName->editAttributes() ?>>
            <?= $Page->MothersName->selectOptionListHtml("x_MothersName", true) ?>
        </select>
        <div class="invalid-feedback"><?= $Page->MothersName->getErrorMessage(false) ?></div>
        <script>
        loadjs.ready("fstudent_detailssrch", function() {
            var options = {
                name: "x_MothersName",
                selectId: "fstudent_detailssrch_x_MothersName",
                ajax: { id: "x_MothersName", form: "fstudent_detailssrch", limit: ew.FILTER_PAGE_SIZE, data: { ajax: "filter" } }
            };
            options = Object.assign({}, ew.filterOptions, options, ew.vars.tables.student_details.fields.MothersName.filterOptions);
            ew.createFilter(options);
        });
        </script>
    </div><!-- /.col-sm-auto -->
<?php } ?>
<?php if ($Page->Address->Visible) { // Address ?>
<?php
if (!$Page->Address->UseFilter) {
    $Page->SearchColumnCount++;
}
?>
    <div id="xs_Address" class="col-sm-auto d-sm-flex align-items-start mb-3 px-0 pe-sm-2<?= $Page->Address->UseFilter ? " ew-filter-field" : "" ?>">
        <select
            id="x_Address"
            name="x_Address[]"
            class="form-control ew-select<?= $Page->Address->isInvalidClass() ?>"
            data-select2-id="fstudent_detailssrch_x_Address"
            data-table="student_details"
            data-field="x_Address"
            data-caption="<?= HtmlEncode(RemoveHtml($Page->Address->caption())) ?>"
            data-filter="true"
            multiple
            size="1"
            data-value-separator="<?= $Page->Address->displayValueSeparatorAttribute() ?>"
            data-placeholder="<?= HtmlEncode($Page->Address->getPlaceHolder()) ?>"
            data-ew-action="update-options"
            <?= $Page->Address->editAttributes() ?>>
            <?= $Page->Address->selectOptionListHtml("x_Address", true) ?>
        </select>
        <div class="invalid-feedback"><?= $Page->Address->getErrorMessage(false) ?></div>
        <script>
        loadjs.ready("fstudent_detailssrch", function() {
            var options = {
                name: "x_Address",
                selectId: "fstudent_detailssrch_x_Address",
                ajax: { id: "x_Address", form: "fstudent_detailssrch", limit: ew.FILTER_PAGE_SIZE, data: { ajax: "filter" } }
            };
            options = Object.assign({}, ew.filterOptions, options, ew.vars.tables.student_details.fields.Address.filterOptions);
            ew.createFilter(options);
        });
        </script>
    </div><!-- /.col-sm-auto -->
<?php } ?>
<?php if ($Page->Occupation->Visible) { // Occupation ?>
<?php
if (!$Page->Occupation->UseFilter) {
    $Page->SearchColumnCount++;
}
?>
    <div id="xs_Occupation" class="col-sm-auto d-sm-flex align-items-start mb-3 px-0 pe-sm-2<?= $Page->Occupation->UseFilter ? " ew-filter-field" : "" ?>">
        <select
            id="x_Occupation"
            name="x_Occupation[]"
            class="form-control ew-select<?= $Page->Occupation->isInvalidClass() ?>"
            data-select2-id="fstudent_detailssrch_x_Occupation"
            data-table="student_details"
            data-field="x_Occupation"
            data-caption="<?= HtmlEncode(RemoveHtml($Page->Occupation->caption())) ?>"
            data-filter="true"
            multiple
            size="1"
            data-value-separator="<?= $Page->Occupation->displayValueSeparatorAttribute() ?>"
            data-placeholder="<?= HtmlEncode($Page->Occupation->getPlaceHolder()) ?>"
            data-ew-action="update-options"
            <?= $Page->Occupation->editAttributes() ?>>
            <?= $Page->Occupation->selectOptionListHtml("x_Occupation", true) ?>
        </select>
        <div class="invalid-feedback"><?= $Page->Occupation->getErrorMessage(false) ?></div>
        <script>
        loadjs.ready("fstudent_detailssrch", function() {
            var options = {
                name: "x_Occupation",
                selectId: "fstudent_detailssrch_x_Occupation",
                ajax: { id: "x_Occupation", form: "fstudent_detailssrch", limit: ew.FILTER_PAGE_SIZE, data: { ajax: "filter" } }
            };
            options = Object.assign({}, ew.filterOptions, options, ew.vars.tables.student_details.fields.Occupation.filterOptions);
            ew.createFilter(options);
        });
        </script>
    </div><!-- /.col-sm-auto -->
<?php } ?>
<?php if ($Page->TravellingMethodtoschoo->Visible) { // Travelling Method to schoo ?>
<?php
if (!$Page->TravellingMethodtoschoo->UseFilter) {
    $Page->SearchColumnCount++;
}
?>
    <div id="xs_TravellingMethodtoschoo" class="col-sm-auto d-sm-flex align-items-start mb-3 px-0 pe-sm-2<?= $Page->TravellingMethodtoschoo->UseFilter ? " ew-filter-field" : "" ?>">
        <select
            id="x_TravellingMethodtoschoo"
            name="x_TravellingMethodtoschoo[]"
            class="form-control ew-select<?= $Page->TravellingMethodtoschoo->isInvalidClass() ?>"
            data-select2-id="fstudent_detailssrch_x_TravellingMethodtoschoo"
            data-table="student_details"
            data-field="x_TravellingMethodtoschoo"
            data-caption="<?= HtmlEncode(RemoveHtml($Page->TravellingMethodtoschoo->caption())) ?>"
            data-filter="true"
            multiple
            size="1"
            data-value-separator="<?= $Page->TravellingMethodtoschoo->displayValueSeparatorAttribute() ?>"
            data-placeholder="<?= HtmlEncode($Page->TravellingMethodtoschoo->getPlaceHolder()) ?>"
            data-ew-action="update-options"
            <?= $Page->TravellingMethodtoschoo->editAttributes() ?>>
            <?= $Page->TravellingMethodtoschoo->selectOptionListHtml("x_TravellingMethodtoschoo", true) ?>
        </select>
        <div class="invalid-feedback"><?= $Page->TravellingMethodtoschoo->getErrorMessage(false) ?></div>
        <script>
        loadjs.ready("fstudent_detailssrch", function() {
            var options = {
                name: "x_TravellingMethodtoschoo",
                selectId: "fstudent_detailssrch_x_TravellingMethodtoschoo",
                ajax: { id: "x_TravellingMethodtoschoo", form: "fstudent_detailssrch", limit: ew.FILTER_PAGE_SIZE, data: { ajax: "filter" } }
            };
            options = Object.assign({}, ew.filterOptions, options, ew.vars.tables.student_details.fields.TravellingMethodtoschoo.filterOptions);
            ew.createFilter(options);
        });
        </script>
    </div><!-- /.col-sm-auto -->
<?php } ?>
<?php if ($Page->inEmergencycontactno->Visible) { // in Emergency contact no ?>
<?php
if (!$Page->inEmergencycontactno->UseFilter) {
    $Page->SearchColumnCount++;
}
?>
    <div id="xs_inEmergencycontactno" class="col-sm-auto d-sm-flex align-items-start mb-3 px-0 pe-sm-2<?= $Page->inEmergencycontactno->UseFilter ? " ew-filter-field" : "" ?>">
        <select
            id="x_inEmergencycontactno"
            name="x_inEmergencycontactno[]"
            class="form-control ew-select<?= $Page->inEmergencycontactno->isInvalidClass() ?>"
            data-select2-id="fstudent_detailssrch_x_inEmergencycontactno"
            data-table="student_details"
            data-field="x_inEmergencycontactno"
            data-caption="<?= HtmlEncode(RemoveHtml($Page->inEmergencycontactno->caption())) ?>"
            data-filter="true"
            multiple
            size="1"
            data-value-separator="<?= $Page->inEmergencycontactno->displayValueSeparatorAttribute() ?>"
            data-placeholder="<?= HtmlEncode($Page->inEmergencycontactno->getPlaceHolder()) ?>"
            data-ew-action="update-options"
            <?= $Page->inEmergencycontactno->editAttributes() ?>>
            <?= $Page->inEmergencycontactno->selectOptionListHtml("x_inEmergencycontactno", true) ?>
        </select>
        <div class="invalid-feedback"><?= $Page->inEmergencycontactno->getErrorMessage(false) ?></div>
        <script>
        loadjs.ready("fstudent_detailssrch", function() {
            var options = {
                name: "x_inEmergencycontactno",
                selectId: "fstudent_detailssrch_x_inEmergencycontactno",
                ajax: { id: "x_inEmergencycontactno", form: "fstudent_detailssrch", limit: ew.FILTER_PAGE_SIZE, data: { ajax: "filter" } }
            };
            options = Object.assign({}, ew.filterOptions, options, ew.vars.tables.student_details.fields.inEmergencycontactno.filterOptions);
            ew.createFilter(options);
        });
        </script>
    </div><!-- /.col-sm-auto -->
<?php } ?>
<?php if ($Page->Specialneeds->Visible) { // Special needs ?>
<?php
if (!$Page->Specialneeds->UseFilter) {
    $Page->SearchColumnCount++;
}
?>
    <div id="xs_Specialneeds" class="col-sm-auto d-sm-flex align-items-start mb-3 px-0 pe-sm-2<?= $Page->Specialneeds->UseFilter ? " ew-filter-field" : "" ?>">
        <select
            id="x_Specialneeds"
            name="x_Specialneeds[]"
            class="form-control ew-select<?= $Page->Specialneeds->isInvalidClass() ?>"
            data-select2-id="fstudent_detailssrch_x_Specialneeds"
            data-table="student_details"
            data-field="x_Specialneeds"
            data-caption="<?= HtmlEncode(RemoveHtml($Page->Specialneeds->caption())) ?>"
            data-filter="true"
            multiple
            size="1"
            data-value-separator="<?= $Page->Specialneeds->displayValueSeparatorAttribute() ?>"
            data-placeholder="<?= HtmlEncode($Page->Specialneeds->getPlaceHolder()) ?>"
            data-ew-action="update-options"
            <?= $Page->Specialneeds->editAttributes() ?>>
            <?= $Page->Specialneeds->selectOptionListHtml("x_Specialneeds", true) ?>
        </select>
        <div class="invalid-feedback"><?= $Page->Specialneeds->getErrorMessage(false) ?></div>
        <script>
        loadjs.ready("fstudent_detailssrch", function() {
            var options = {
                name: "x_Specialneeds",
                selectId: "fstudent_detailssrch_x_Specialneeds",
                ajax: { id: "x_Specialneeds", form: "fstudent_detailssrch", limit: ew.FILTER_PAGE_SIZE, data: { ajax: "filter" } }
            };
            options = Object.assign({}, ew.filterOptions, options, ew.vars.tables.student_details.fields.Specialneeds.filterOptions);
            ew.createFilter(options);
        });
        </script>
    </div><!-- /.col-sm-auto -->
<?php } ?>
<?php if ($Page->Grade->Visible) { // Grade ?>
<?php
if (!$Page->Grade->UseFilter) {
    $Page->SearchColumnCount++;
}
?>
    <div id="xs_Grade" class="col-sm-auto d-sm-flex align-items-start mb-3 px-0 pe-sm-2<?= $Page->Grade->UseFilter ? " ew-filter-field" : "" ?>">
        <select
            id="x_Grade"
            name="x_Grade[]"
            class="form-control ew-select<?= $Page->Grade->isInvalidClass() ?>"
            data-select2-id="fstudent_detailssrch_x_Grade"
            data-table="student_details"
            data-field="x_Grade"
            data-caption="<?= HtmlEncode(RemoveHtml($Page->Grade->caption())) ?>"
            data-filter="true"
            multiple
            size="1"
            data-value-separator="<?= $Page->Grade->displayValueSeparatorAttribute() ?>"
            data-placeholder="<?= HtmlEncode($Page->Grade->getPlaceHolder()) ?>"
            data-ew-action="update-options"
            <?= $Page->Grade->editAttributes() ?>>
            <?= $Page->Grade->selectOptionListHtml("x_Grade", true) ?>
        </select>
        <div class="invalid-feedback"><?= $Page->Grade->getErrorMessage(false) ?></div>
        <script>
        loadjs.ready("fstudent_detailssrch", function() {
            var options = {
                name: "x_Grade",
                selectId: "fstudent_detailssrch_x_Grade",
                ajax: { id: "x_Grade", form: "fstudent_detailssrch", limit: ew.FILTER_PAGE_SIZE, data: { ajax: "filter" } }
            };
            options = Object.assign({}, ew.filterOptions, options, ew.vars.tables.student_details.fields.Grade.filterOptions);
            ew.createFilter(options);
        });
        </script>
    </div><!-- /.col-sm-auto -->
<?php } ?>
<?php if ($Page->prefect->Visible) { // prefect ?>
<?php
if (!$Page->prefect->UseFilter) {
    $Page->SearchColumnCount++;
}
?>
    <div id="xs_prefect" class="col-sm-auto d-sm-flex align-items-start mb-3 px-0 pe-sm-2<?= $Page->prefect->UseFilter ? " ew-filter-field" : "" ?>">
        <select
            id="x_prefect"
            name="x_prefect[]"
            class="form-control ew-select<?= $Page->prefect->isInvalidClass() ?>"
            data-select2-id="fstudent_detailssrch_x_prefect"
            data-table="student_details"
            data-field="x_prefect"
            data-caption="<?= HtmlEncode(RemoveHtml($Page->prefect->caption())) ?>"
            data-filter="true"
            multiple
            size="1"
            data-value-separator="<?= $Page->prefect->displayValueSeparatorAttribute() ?>"
            data-placeholder="<?= HtmlEncode($Page->prefect->getPlaceHolder()) ?>"
            data-ew-action="update-options"
            <?= $Page->prefect->editAttributes() ?>>
            <?= $Page->prefect->selectOptionListHtml("x_prefect", true) ?>
        </select>
        <div class="invalid-feedback"><?= $Page->prefect->getErrorMessage(false) ?></div>
        <script>
        loadjs.ready("fstudent_detailssrch", function() {
            var options = {
                name: "x_prefect",
                selectId: "fstudent_detailssrch_x_prefect",
                ajax: { id: "x_prefect", form: "fstudent_detailssrch", limit: ew.FILTER_PAGE_SIZE, data: { ajax: "filter" } }
            };
            options = Object.assign({}, ew.filterOptions, options, ew.vars.tables.student_details.fields.prefect.filterOptions);
            ew.createFilter(options);
        });
        </script>
    </div><!-- /.col-sm-auto -->
<?php } ?>
</div><!-- /.row -->
<div class="row mb-0">
    <div class="col-sm-auto px-0 pe-sm-2">
        <div class="ew-basic-search input-group">
            <input type="search" name="<?= Config("TABLE_BASIC_SEARCH") ?>" id="<?= Config("TABLE_BASIC_SEARCH") ?>" class="form-control ew-basic-search-keyword" value="<?= HtmlEncode($Page->BasicSearch->getKeyword()) ?>" placeholder="<?= HtmlEncode($Language->phrase("Search")) ?>" aria-label="<?= HtmlEncode($Language->phrase("Search")) ?>">
            <input type="hidden" name="<?= Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?= Config("TABLE_BASIC_SEARCH_TYPE") ?>" class="ew-basic-search-type" value="<?= HtmlEncode($Page->BasicSearch->getType()) ?>">
            <button type="button" data-bs-toggle="dropdown" class="btn btn-outline-secondary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false">
                <span id="searchtype"><?= $Page->BasicSearch->getTypeNameShort() ?></span>
            </button>
            <div class="dropdown-menu dropdown-menu-end">
                <button type="button" class="dropdown-item<?= $Page->BasicSearch->getType() == "" ? " active" : "" ?>" form="fstudent_detailssrch" data-ew-action="search-type"><?= $Language->phrase("QuickSearchAuto") ?></button>
                <button type="button" class="dropdown-item<?= $Page->BasicSearch->getType() == "=" ? " active" : "" ?>" form="fstudent_detailssrch" data-ew-action="search-type" data-search-type="="><?= $Language->phrase("QuickSearchExact") ?></button>
                <button type="button" class="dropdown-item<?= $Page->BasicSearch->getType() == "AND" ? " active" : "" ?>" form="fstudent_detailssrch" data-ew-action="search-type" data-search-type="AND"><?= $Language->phrase("QuickSearchAll") ?></button>
                <button type="button" class="dropdown-item<?= $Page->BasicSearch->getType() == "OR" ? " active" : "" ?>" form="fstudent_detailssrch" data-ew-action="search-type" data-search-type="OR"><?= $Language->phrase("QuickSearchAny") ?></button>
            </div>
        </div>
    </div>
    <div class="col-sm-auto mb-3">
        <button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?= $Language->phrase("SearchBtn") ?></button>
    </div>
</div>
</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<main class="list<?= ($Page->TotalRecords == 0) ? " ew-no-record" : "" ?>">
<div id="ew-list">
<?php if ($Page->TotalRecords > 0 || $Page->CurrentAction) { ?>
<div class="card ew-card ew-grid<?= $Page->isAddOrEdit() ? " ew-grid-add-edit" : "" ?> <?= $Page->TableGridClass ?>">
<form name="<?= $Page->FormName ?>" id="<?= $Page->FormName ?>" class="ew-form ew-list-form" action="<?= $Page->PageAction ?>" method="post" novalidate autocomplete="on">
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="student_details">
<?php if ($Page->IsModal) { ?>
<input type="hidden" name="modal" value="1">
<?php } ?>
<div id="gmp_student_details" class="card-body ew-grid-middle-panel <?= $Page->TableContainerClass ?>" style="<?= $Page->TableContainerStyle ?>">
<?php if ($Page->TotalRecords > 0 || $Page->isAdd() || $Page->isCopy() || $Page->isGridEdit() || $Page->isMultiEdit()) { ?>
<table id="tbl_student_detailslist" class="<?= $Page->TableClass ?>"><!-- .ew-table -->
<thead>
    <tr class="ew-table-header">
<?php
// Header row
$Page->RowType = ROWTYPE_HEADER;

// Render list options
$Page->renderListOptions();

// Render list options (header, left)
$Page->ListOptions->render("header", "left");
?>
<?php if ($Page->AdmissionNo->Visible) { // Admission No ?>
        <th data-name="AdmissionNo" class="<?= $Page->AdmissionNo->headerCellClass() ?>"><div id="elh_student_details_AdmissionNo" class="student_details_AdmissionNo"><?= $Page->renderFieldHeader($Page->AdmissionNo) ?></div></th>
<?php } ?>
<?php if ($Page->FullName->Visible) { // Full Name ?>
        <th data-name="FullName" class="<?= $Page->FullName->headerCellClass() ?>"><div id="elh_student_details_FullName" class="student_details_FullName"><?= $Page->renderFieldHeader($Page->FullName) ?></div></th>
<?php } ?>
<?php if ($Page->NameWithInitials->Visible) { // Name With Initials ?>
        <th data-name="NameWithInitials" class="<?= $Page->NameWithInitials->headerCellClass() ?>"><div id="elh_student_details_NameWithInitials" class="student_details_NameWithInitials"><?= $Page->renderFieldHeader($Page->NameWithInitials) ?></div></th>
<?php } ?>
<?php if ($Page->FathersName->Visible) { // Father's Name ?>
        <th data-name="FathersName" class="<?= $Page->FathersName->headerCellClass() ?>"><div id="elh_student_details_FathersName" class="student_details_FathersName"><?= $Page->renderFieldHeader($Page->FathersName) ?></div></th>
<?php } ?>
<?php if ($Page->MothersName->Visible) { // Mother's Name ?>
        <th data-name="MothersName" class="<?= $Page->MothersName->headerCellClass() ?>"><div id="elh_student_details_MothersName" class="student_details_MothersName"><?= $Page->renderFieldHeader($Page->MothersName) ?></div></th>
<?php } ?>
<?php if ($Page->Address->Visible) { // Address ?>
        <th data-name="Address" class="<?= $Page->Address->headerCellClass() ?>"><div id="elh_student_details_Address" class="student_details_Address"><?= $Page->renderFieldHeader($Page->Address) ?></div></th>
<?php } ?>
<?php if ($Page->Occupation->Visible) { // Occupation ?>
        <th data-name="Occupation" class="<?= $Page->Occupation->headerCellClass() ?>"><div id="elh_student_details_Occupation" class="student_details_Occupation"><?= $Page->renderFieldHeader($Page->Occupation) ?></div></th>
<?php } ?>
<?php if ($Page->TravellingMethodtoschoo->Visible) { // Travelling Method to schoo ?>
        <th data-name="TravellingMethodtoschoo" class="<?= $Page->TravellingMethodtoschoo->headerCellClass() ?>"><div id="elh_student_details_TravellingMethodtoschoo" class="student_details_TravellingMethodtoschoo"><?= $Page->renderFieldHeader($Page->TravellingMethodtoschoo) ?></div></th>
<?php } ?>
<?php if ($Page->inEmergencycontactno->Visible) { // in Emergency contact no ?>
        <th data-name="inEmergencycontactno" class="<?= $Page->inEmergencycontactno->headerCellClass() ?>"><div id="elh_student_details_inEmergencycontactno" class="student_details_inEmergencycontactno"><?= $Page->renderFieldHeader($Page->inEmergencycontactno) ?></div></th>
<?php } ?>
<?php if ($Page->Specialneeds->Visible) { // Special needs ?>
        <th data-name="Specialneeds" class="<?= $Page->Specialneeds->headerCellClass() ?>"><div id="elh_student_details_Specialneeds" class="student_details_Specialneeds"><?= $Page->renderFieldHeader($Page->Specialneeds) ?></div></th>
<?php } ?>
<?php if ($Page->Grade->Visible) { // Grade ?>
        <th data-name="Grade" class="<?= $Page->Grade->headerCellClass() ?>"><div id="elh_student_details_Grade" class="student_details_Grade"><?= $Page->renderFieldHeader($Page->Grade) ?></div></th>
<?php } ?>
<?php if ($Page->prefect->Visible) { // prefect ?>
        <th data-name="prefect" class="<?= $Page->prefect->headerCellClass() ?>"><div id="elh_student_details_prefect" class="student_details_prefect"><?= $Page->renderFieldHeader($Page->prefect) ?></div></th>
<?php } ?>
<?php
// Render list options (header, right)
$Page->ListOptions->render("header", "right");
?>
    </tr>
</thead>
<tbody data-page="<?= $Page->getPageNumber() ?>">
<?php
$Page->setupGrid();
while ($Page->RecordCount < $Page->StopRecord) {
    $Page->RecordCount++;
    if ($Page->RecordCount >= $Page->StartRecord) {
        $Page->setupRow();

        // Skip 1) delete row / empty row for confirm page, 2) hidden row
        if (
            $Page->RowAction != "delete" &&
            $Page->RowAction != "insertdelete" &&
            !($Page->RowAction == "insert" && $Page->isConfirm() && $Page->emptyRow()) &&
            $Page->RowAction != "hide"
        ) {
?>
    <tr <?= $Page->rowAttributes() ?>>
<?php
// Render list options (body, left)
$Page->ListOptions->render("body", "left", $Page->RowCount);
?>
    <?php if ($Page->AdmissionNo->Visible) { // Admission No ?>
        <td data-name="AdmissionNo"<?= $Page->AdmissionNo->cellAttributes() ?>>
<?php if ($Page->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?= $Page->RowCount ?>_student_details_AdmissionNo" class="el_student_details_AdmissionNo">
<input type="<?= $Page->AdmissionNo->getInputTextType() ?>" name="x<?= $Page->RowIndex ?>_AdmissionNo" id="x<?= $Page->RowIndex ?>_AdmissionNo" data-table="student_details" data-field="x_AdmissionNo" value="<?= $Page->AdmissionNo->EditValue ?>" size="30" maxlength="100" placeholder="<?= HtmlEncode($Page->AdmissionNo->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->AdmissionNo->formatPattern()) ?>"<?= $Page->AdmissionNo->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->AdmissionNo->getErrorMessage() ?></div>
</span>
<input type="hidden" data-table="student_details" data-field="x_AdmissionNo" data-hidden="1" data-old name="o<?= $Page->RowIndex ?>_AdmissionNo" id="o<?= $Page->RowIndex ?>_AdmissionNo" value="<?= HtmlEncode($Page->AdmissionNo->OldValue) ?>">
<?php } ?>
<?php if ($Page->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?= $Page->RowCount ?>_student_details_AdmissionNo" class="el_student_details_AdmissionNo">
<input type="<?= $Page->AdmissionNo->getInputTextType() ?>" name="x<?= $Page->RowIndex ?>_AdmissionNo" id="x<?= $Page->RowIndex ?>_AdmissionNo" data-table="student_details" data-field="x_AdmissionNo" value="<?= $Page->AdmissionNo->EditValue ?>" size="30" maxlength="100" placeholder="<?= HtmlEncode($Page->AdmissionNo->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->AdmissionNo->formatPattern()) ?>"<?= $Page->AdmissionNo->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->AdmissionNo->getErrorMessage() ?></div>
<input type="hidden" data-table="student_details" data-field="x_AdmissionNo" data-hidden="1" data-old name="o<?= $Page->RowIndex ?>_AdmissionNo" id="o<?= $Page->RowIndex ?>_AdmissionNo" value="<?= HtmlEncode($Page->AdmissionNo->OldValue ?? $Page->AdmissionNo->CurrentValue) ?>">
</span>
<?php } ?>
<?php if ($Page->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?= $Page->RowCount ?>_student_details_AdmissionNo" class="el_student_details_AdmissionNo">
<span<?= $Page->AdmissionNo->viewAttributes() ?>>
<?= $Page->AdmissionNo->getViewValue() ?></span>
</span>
<?php } ?>
</td>
    <?php } else { ?>
            <input type="hidden" data-table="student_details" data-field="x_AdmissionNo" data-hidden="1" name="x<?= $Page->RowIndex ?>_AdmissionNo" id="x<?= $Page->RowIndex ?>_AdmissionNo" value="<?= HtmlEncode($Page->AdmissionNo->CurrentValue) ?>">
    <?php } ?>
    <?php if ($Page->FullName->Visible) { // Full Name ?>
        <td data-name="FullName"<?= $Page->FullName->cellAttributes() ?>>
<?php if ($Page->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?= $Page->RowCount ?>_student_details_FullName" class="el_student_details_FullName">
<textarea data-table="student_details" data-field="x_FullName" name="x<?= $Page->RowIndex ?>_FullName" id="x<?= $Page->RowIndex ?>_FullName" cols="35" rows="4" placeholder="<?= HtmlEncode($Page->FullName->getPlaceHolder()) ?>"<?= $Page->FullName->editAttributes() ?>><?= $Page->FullName->EditValue ?></textarea>
<div class="invalid-feedback"><?= $Page->FullName->getErrorMessage() ?></div>
</span>
<input type="hidden" data-table="student_details" data-field="x_FullName" data-hidden="1" data-old name="o<?= $Page->RowIndex ?>_FullName" id="o<?= $Page->RowIndex ?>_FullName" value="<?= HtmlEncode($Page->FullName->OldValue) ?>">
<?php } ?>
<?php if ($Page->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?= $Page->RowCount ?>_student_details_FullName" class="el_student_details_FullName">
<textarea data-table="student_details" data-field="x_FullName" name="x<?= $Page->RowIndex ?>_FullName" id="x<?= $Page->RowIndex ?>_FullName" cols="35" rows="4" placeholder="<?= HtmlEncode($Page->FullName->getPlaceHolder()) ?>"<?= $Page->FullName->editAttributes() ?>><?= $Page->FullName->EditValue ?></textarea>
<div class="invalid-feedback"><?= $Page->FullName->getErrorMessage() ?></div>
</span>
<?php } ?>
<?php if ($Page->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?= $Page->RowCount ?>_student_details_FullName" class="el_student_details_FullName">
<span<?= $Page->FullName->viewAttributes() ?>>
<?= $Page->FullName->getViewValue() ?></span>
</span>
<?php } ?>
</td>
    <?php } ?>
    <?php if ($Page->NameWithInitials->Visible) { // Name With Initials ?>
        <td data-name="NameWithInitials"<?= $Page->NameWithInitials->cellAttributes() ?>>
<?php if ($Page->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?= $Page->RowCount ?>_student_details_NameWithInitials" class="el_student_details_NameWithInitials">
<textarea data-table="student_details" data-field="x_NameWithInitials" name="x<?= $Page->RowIndex ?>_NameWithInitials" id="x<?= $Page->RowIndex ?>_NameWithInitials" cols="35" rows="4" placeholder="<?= HtmlEncode($Page->NameWithInitials->getPlaceHolder()) ?>"<?= $Page->NameWithInitials->editAttributes() ?>><?= $Page->NameWithInitials->EditValue ?></textarea>
<div class="invalid-feedback"><?= $Page->NameWithInitials->getErrorMessage() ?></div>
</span>
<input type="hidden" data-table="student_details" data-field="x_NameWithInitials" data-hidden="1" data-old name="o<?= $Page->RowIndex ?>_NameWithInitials" id="o<?= $Page->RowIndex ?>_NameWithInitials" value="<?= HtmlEncode($Page->NameWithInitials->OldValue) ?>">
<?php } ?>
<?php if ($Page->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?= $Page->RowCount ?>_student_details_NameWithInitials" class="el_student_details_NameWithInitials">
<textarea data-table="student_details" data-field="x_NameWithInitials" name="x<?= $Page->RowIndex ?>_NameWithInitials" id="x<?= $Page->RowIndex ?>_NameWithInitials" cols="35" rows="4" placeholder="<?= HtmlEncode($Page->NameWithInitials->getPlaceHolder()) ?>"<?= $Page->NameWithInitials->editAttributes() ?>><?= $Page->NameWithInitials->EditValue ?></textarea>
<div class="invalid-feedback"><?= $Page->NameWithInitials->getErrorMessage() ?></div>
</span>
<?php } ?>
<?php if ($Page->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?= $Page->RowCount ?>_student_details_NameWithInitials" class="el_student_details_NameWithInitials">
<span<?= $Page->NameWithInitials->viewAttributes() ?>>
<?= $Page->NameWithInitials->getViewValue() ?></span>
</span>
<?php } ?>
</td>
    <?php } ?>
    <?php if ($Page->FathersName->Visible) { // Father's Name ?>
        <td data-name="FathersName"<?= $Page->FathersName->cellAttributes() ?>>
<?php if ($Page->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?= $Page->RowCount ?>_student_details_FathersName" class="el_student_details_FathersName">
<textarea data-table="student_details" data-field="x_FathersName" name="x<?= $Page->RowIndex ?>_FathersName" id="x<?= $Page->RowIndex ?>_FathersName" cols="35" rows="4" placeholder="<?= HtmlEncode($Page->FathersName->getPlaceHolder()) ?>"<?= $Page->FathersName->editAttributes() ?>><?= $Page->FathersName->EditValue ?></textarea>
<div class="invalid-feedback"><?= $Page->FathersName->getErrorMessage() ?></div>
</span>
<input type="hidden" data-table="student_details" data-field="x_FathersName" data-hidden="1" data-old name="o<?= $Page->RowIndex ?>_FathersName" id="o<?= $Page->RowIndex ?>_FathersName" value="<?= HtmlEncode($Page->FathersName->OldValue) ?>">
<?php } ?>
<?php if ($Page->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?= $Page->RowCount ?>_student_details_FathersName" class="el_student_details_FathersName">
<textarea data-table="student_details" data-field="x_FathersName" name="x<?= $Page->RowIndex ?>_FathersName" id="x<?= $Page->RowIndex ?>_FathersName" cols="35" rows="4" placeholder="<?= HtmlEncode($Page->FathersName->getPlaceHolder()) ?>"<?= $Page->FathersName->editAttributes() ?>><?= $Page->FathersName->EditValue ?></textarea>
<div class="invalid-feedback"><?= $Page->FathersName->getErrorMessage() ?></div>
</span>
<?php } ?>
<?php if ($Page->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?= $Page->RowCount ?>_student_details_FathersName" class="el_student_details_FathersName">
<span<?= $Page->FathersName->viewAttributes() ?>>
<?= $Page->FathersName->getViewValue() ?></span>
</span>
<?php } ?>
</td>
    <?php } ?>
    <?php if ($Page->MothersName->Visible) { // Mother's Name ?>
        <td data-name="MothersName"<?= $Page->MothersName->cellAttributes() ?>>
<?php if ($Page->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?= $Page->RowCount ?>_student_details_MothersName" class="el_student_details_MothersName">
<textarea data-table="student_details" data-field="x_MothersName" name="x<?= $Page->RowIndex ?>_MothersName" id="x<?= $Page->RowIndex ?>_MothersName" cols="35" rows="4" placeholder="<?= HtmlEncode($Page->MothersName->getPlaceHolder()) ?>"<?= $Page->MothersName->editAttributes() ?>><?= $Page->MothersName->EditValue ?></textarea>
<div class="invalid-feedback"><?= $Page->MothersName->getErrorMessage() ?></div>
</span>
<input type="hidden" data-table="student_details" data-field="x_MothersName" data-hidden="1" data-old name="o<?= $Page->RowIndex ?>_MothersName" id="o<?= $Page->RowIndex ?>_MothersName" value="<?= HtmlEncode($Page->MothersName->OldValue) ?>">
<?php } ?>
<?php if ($Page->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?= $Page->RowCount ?>_student_details_MothersName" class="el_student_details_MothersName">
<textarea data-table="student_details" data-field="x_MothersName" name="x<?= $Page->RowIndex ?>_MothersName" id="x<?= $Page->RowIndex ?>_MothersName" cols="35" rows="4" placeholder="<?= HtmlEncode($Page->MothersName->getPlaceHolder()) ?>"<?= $Page->MothersName->editAttributes() ?>><?= $Page->MothersName->EditValue ?></textarea>
<div class="invalid-feedback"><?= $Page->MothersName->getErrorMessage() ?></div>
</span>
<?php } ?>
<?php if ($Page->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?= $Page->RowCount ?>_student_details_MothersName" class="el_student_details_MothersName">
<span<?= $Page->MothersName->viewAttributes() ?>>
<?= $Page->MothersName->getViewValue() ?></span>
</span>
<?php } ?>
</td>
    <?php } ?>
    <?php if ($Page->Address->Visible) { // Address ?>
        <td data-name="Address"<?= $Page->Address->cellAttributes() ?>>
<?php if ($Page->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?= $Page->RowCount ?>_student_details_Address" class="el_student_details_Address">
<textarea data-table="student_details" data-field="x_Address" name="x<?= $Page->RowIndex ?>_Address" id="x<?= $Page->RowIndex ?>_Address" cols="35" rows="4" placeholder="<?= HtmlEncode($Page->Address->getPlaceHolder()) ?>"<?= $Page->Address->editAttributes() ?>><?= $Page->Address->EditValue ?></textarea>
<div class="invalid-feedback"><?= $Page->Address->getErrorMessage() ?></div>
</span>
<input type="hidden" data-table="student_details" data-field="x_Address" data-hidden="1" data-old name="o<?= $Page->RowIndex ?>_Address" id="o<?= $Page->RowIndex ?>_Address" value="<?= HtmlEncode($Page->Address->OldValue) ?>">
<?php } ?>
<?php if ($Page->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?= $Page->RowCount ?>_student_details_Address" class="el_student_details_Address">
<textarea data-table="student_details" data-field="x_Address" name="x<?= $Page->RowIndex ?>_Address" id="x<?= $Page->RowIndex ?>_Address" cols="35" rows="4" placeholder="<?= HtmlEncode($Page->Address->getPlaceHolder()) ?>"<?= $Page->Address->editAttributes() ?>><?= $Page->Address->EditValue ?></textarea>
<div class="invalid-feedback"><?= $Page->Address->getErrorMessage() ?></div>
</span>
<?php } ?>
<?php if ($Page->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?= $Page->RowCount ?>_student_details_Address" class="el_student_details_Address">
<span<?= $Page->Address->viewAttributes() ?>>
<?= $Page->Address->getViewValue() ?></span>
</span>
<?php } ?>
</td>
    <?php } ?>
    <?php if ($Page->Occupation->Visible) { // Occupation ?>
        <td data-name="Occupation"<?= $Page->Occupation->cellAttributes() ?>>
<?php if ($Page->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?= $Page->RowCount ?>_student_details_Occupation" class="el_student_details_Occupation">
<textarea data-table="student_details" data-field="x_Occupation" name="x<?= $Page->RowIndex ?>_Occupation" id="x<?= $Page->RowIndex ?>_Occupation" cols="35" rows="4" placeholder="<?= HtmlEncode($Page->Occupation->getPlaceHolder()) ?>"<?= $Page->Occupation->editAttributes() ?>><?= $Page->Occupation->EditValue ?></textarea>
<div class="invalid-feedback"><?= $Page->Occupation->getErrorMessage() ?></div>
</span>
<input type="hidden" data-table="student_details" data-field="x_Occupation" data-hidden="1" data-old name="o<?= $Page->RowIndex ?>_Occupation" id="o<?= $Page->RowIndex ?>_Occupation" value="<?= HtmlEncode($Page->Occupation->OldValue) ?>">
<?php } ?>
<?php if ($Page->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?= $Page->RowCount ?>_student_details_Occupation" class="el_student_details_Occupation">
<textarea data-table="student_details" data-field="x_Occupation" name="x<?= $Page->RowIndex ?>_Occupation" id="x<?= $Page->RowIndex ?>_Occupation" cols="35" rows="4" placeholder="<?= HtmlEncode($Page->Occupation->getPlaceHolder()) ?>"<?= $Page->Occupation->editAttributes() ?>><?= $Page->Occupation->EditValue ?></textarea>
<div class="invalid-feedback"><?= $Page->Occupation->getErrorMessage() ?></div>
</span>
<?php } ?>
<?php if ($Page->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?= $Page->RowCount ?>_student_details_Occupation" class="el_student_details_Occupation">
<span<?= $Page->Occupation->viewAttributes() ?>>
<?= $Page->Occupation->getViewValue() ?></span>
</span>
<?php } ?>
</td>
    <?php } ?>
    <?php if ($Page->TravellingMethodtoschoo->Visible) { // Travelling Method to schoo ?>
        <td data-name="TravellingMethodtoschoo"<?= $Page->TravellingMethodtoschoo->cellAttributes() ?>>
<?php if ($Page->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?= $Page->RowCount ?>_student_details_TravellingMethodtoschoo" class="el_student_details_TravellingMethodtoschoo">
    <select
        id="x<?= $Page->RowIndex ?>_TravellingMethodtoschoo"
        name="x<?= $Page->RowIndex ?>_TravellingMethodtoschoo"
        class="form-select ew-select<?= $Page->TravellingMethodtoschoo->isInvalidClass() ?>"
        data-select2-id="<?= $Page->FormName ?>_x<?= $Page->RowIndex ?>_TravellingMethodtoschoo"
        data-table="student_details"
        data-field="x_TravellingMethodtoschoo"
        data-value-separator="<?= $Page->TravellingMethodtoschoo->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->TravellingMethodtoschoo->getPlaceHolder()) ?>"
        <?= $Page->TravellingMethodtoschoo->editAttributes() ?>>
        <?= $Page->TravellingMethodtoschoo->selectOptionListHtml("x{$Page->RowIndex}_TravellingMethodtoschoo") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->TravellingMethodtoschoo->getErrorMessage() ?></div>
<script>
loadjs.ready("<?= $Page->FormName ?>", function() {
    var options = { name: "x<?= $Page->RowIndex ?>_TravellingMethodtoschoo", selectId: "<?= $Page->FormName ?>_x<?= $Page->RowIndex ?>_TravellingMethodtoschoo" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (<?= $Page->FormName ?>.lists.TravellingMethodtoschoo?.lookupOptions.length) {
        options.data = { id: "x<?= $Page->RowIndex ?>_TravellingMethodtoschoo", form: "<?= $Page->FormName ?>" };
    } else {
        options.ajax = { id: "x<?= $Page->RowIndex ?>_TravellingMethodtoschoo", form: "<?= $Page->FormName ?>", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.student_details.fields.TravellingMethodtoschoo.selectOptions);
    ew.createSelect(options);
});
</script>
</span>
<input type="hidden" data-table="student_details" data-field="x_TravellingMethodtoschoo" data-hidden="1" data-old name="o<?= $Page->RowIndex ?>_TravellingMethodtoschoo" id="o<?= $Page->RowIndex ?>_TravellingMethodtoschoo" value="<?= HtmlEncode($Page->TravellingMethodtoschoo->OldValue) ?>">
<?php } ?>
<?php if ($Page->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?= $Page->RowCount ?>_student_details_TravellingMethodtoschoo" class="el_student_details_TravellingMethodtoschoo">
    <select
        id="x<?= $Page->RowIndex ?>_TravellingMethodtoschoo"
        name="x<?= $Page->RowIndex ?>_TravellingMethodtoschoo"
        class="form-select ew-select<?= $Page->TravellingMethodtoschoo->isInvalidClass() ?>"
        data-select2-id="<?= $Page->FormName ?>_x<?= $Page->RowIndex ?>_TravellingMethodtoschoo"
        data-table="student_details"
        data-field="x_TravellingMethodtoschoo"
        data-value-separator="<?= $Page->TravellingMethodtoschoo->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->TravellingMethodtoschoo->getPlaceHolder()) ?>"
        <?= $Page->TravellingMethodtoschoo->editAttributes() ?>>
        <?= $Page->TravellingMethodtoschoo->selectOptionListHtml("x{$Page->RowIndex}_TravellingMethodtoschoo") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->TravellingMethodtoschoo->getErrorMessage() ?></div>
<script>
loadjs.ready("<?= $Page->FormName ?>", function() {
    var options = { name: "x<?= $Page->RowIndex ?>_TravellingMethodtoschoo", selectId: "<?= $Page->FormName ?>_x<?= $Page->RowIndex ?>_TravellingMethodtoschoo" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (<?= $Page->FormName ?>.lists.TravellingMethodtoschoo?.lookupOptions.length) {
        options.data = { id: "x<?= $Page->RowIndex ?>_TravellingMethodtoschoo", form: "<?= $Page->FormName ?>" };
    } else {
        options.ajax = { id: "x<?= $Page->RowIndex ?>_TravellingMethodtoschoo", form: "<?= $Page->FormName ?>", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.student_details.fields.TravellingMethodtoschoo.selectOptions);
    ew.createSelect(options);
});
</script>
</span>
<?php } ?>
<?php if ($Page->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?= $Page->RowCount ?>_student_details_TravellingMethodtoschoo" class="el_student_details_TravellingMethodtoschoo">
<span<?= $Page->TravellingMethodtoschoo->viewAttributes() ?>>
<?= $Page->TravellingMethodtoschoo->getViewValue() ?></span>
</span>
<?php } ?>
</td>
    <?php } ?>
    <?php if ($Page->inEmergencycontactno->Visible) { // in Emergency contact no ?>
        <td data-name="inEmergencycontactno"<?= $Page->inEmergencycontactno->cellAttributes() ?>>
<?php if ($Page->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?= $Page->RowCount ?>_student_details_inEmergencycontactno" class="el_student_details_inEmergencycontactno">
<input type="<?= $Page->inEmergencycontactno->getInputTextType() ?>" name="x<?= $Page->RowIndex ?>_inEmergencycontactno" id="x<?= $Page->RowIndex ?>_inEmergencycontactno" data-table="student_details" data-field="x_inEmergencycontactno" value="<?= $Page->inEmergencycontactno->EditValue ?>" size="30" placeholder="<?= HtmlEncode($Page->inEmergencycontactno->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->inEmergencycontactno->formatPattern()) ?>"<?= $Page->inEmergencycontactno->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->inEmergencycontactno->getErrorMessage() ?></div>
</span>
<input type="hidden" data-table="student_details" data-field="x_inEmergencycontactno" data-hidden="1" data-old name="o<?= $Page->RowIndex ?>_inEmergencycontactno" id="o<?= $Page->RowIndex ?>_inEmergencycontactno" value="<?= HtmlEncode($Page->inEmergencycontactno->OldValue) ?>">
<?php } ?>
<?php if ($Page->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?= $Page->RowCount ?>_student_details_inEmergencycontactno" class="el_student_details_inEmergencycontactno">
<input type="<?= $Page->inEmergencycontactno->getInputTextType() ?>" name="x<?= $Page->RowIndex ?>_inEmergencycontactno" id="x<?= $Page->RowIndex ?>_inEmergencycontactno" data-table="student_details" data-field="x_inEmergencycontactno" value="<?= $Page->inEmergencycontactno->EditValue ?>" size="30" placeholder="<?= HtmlEncode($Page->inEmergencycontactno->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->inEmergencycontactno->formatPattern()) ?>"<?= $Page->inEmergencycontactno->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->inEmergencycontactno->getErrorMessage() ?></div>
</span>
<?php } ?>
<?php if ($Page->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?= $Page->RowCount ?>_student_details_inEmergencycontactno" class="el_student_details_inEmergencycontactno">
<span<?= $Page->inEmergencycontactno->viewAttributes() ?>>
<?= $Page->inEmergencycontactno->getViewValue() ?></span>
</span>
<?php } ?>
</td>
    <?php } ?>
    <?php if ($Page->Specialneeds->Visible) { // Special needs ?>
        <td data-name="Specialneeds"<?= $Page->Specialneeds->cellAttributes() ?>>
<?php if ($Page->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?= $Page->RowCount ?>_student_details_Specialneeds" class="el_student_details_Specialneeds">
<template id="tp_x<?= $Page->RowIndex ?>_Specialneeds">
    <div class="form-check">
        <input type="radio" class="form-check-input" data-table="student_details" data-field="x_Specialneeds" name="x<?= $Page->RowIndex ?>_Specialneeds" id="x<?= $Page->RowIndex ?>_Specialneeds"<?= $Page->Specialneeds->editAttributes() ?>>
        <label class="form-check-label"></label>
    </div>
</template>
<div id="dsl_x<?= $Page->RowIndex ?>_Specialneeds" class="ew-item-list"></div>
<selection-list hidden
    id="x<?= $Page->RowIndex ?>_Specialneeds"
    name="x<?= $Page->RowIndex ?>_Specialneeds"
    value="<?= HtmlEncode($Page->Specialneeds->CurrentValue) ?>"
    data-type="select-one"
    data-template="tp_x<?= $Page->RowIndex ?>_Specialneeds"
    data-target="dsl_x<?= $Page->RowIndex ?>_Specialneeds"
    data-repeatcolumn="5"
    class="form-control<?= $Page->Specialneeds->isInvalidClass() ?>"
    data-table="student_details"
    data-field="x_Specialneeds"
    data-value-separator="<?= $Page->Specialneeds->displayValueSeparatorAttribute() ?>"
    <?= $Page->Specialneeds->editAttributes() ?>></selection-list>
<div class="invalid-feedback"><?= $Page->Specialneeds->getErrorMessage() ?></div>
</span>
<input type="hidden" data-table="student_details" data-field="x_Specialneeds" data-hidden="1" data-old name="o<?= $Page->RowIndex ?>_Specialneeds" id="o<?= $Page->RowIndex ?>_Specialneeds" value="<?= HtmlEncode($Page->Specialneeds->OldValue) ?>">
<?php } ?>
<?php if ($Page->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?= $Page->RowCount ?>_student_details_Specialneeds" class="el_student_details_Specialneeds">
<template id="tp_x<?= $Page->RowIndex ?>_Specialneeds">
    <div class="form-check">
        <input type="radio" class="form-check-input" data-table="student_details" data-field="x_Specialneeds" name="x<?= $Page->RowIndex ?>_Specialneeds" id="x<?= $Page->RowIndex ?>_Specialneeds"<?= $Page->Specialneeds->editAttributes() ?>>
        <label class="form-check-label"></label>
    </div>
</template>
<div id="dsl_x<?= $Page->RowIndex ?>_Specialneeds" class="ew-item-list"></div>
<selection-list hidden
    id="x<?= $Page->RowIndex ?>_Specialneeds"
    name="x<?= $Page->RowIndex ?>_Specialneeds"
    value="<?= HtmlEncode($Page->Specialneeds->CurrentValue) ?>"
    data-type="select-one"
    data-template="tp_x<?= $Page->RowIndex ?>_Specialneeds"
    data-target="dsl_x<?= $Page->RowIndex ?>_Specialneeds"
    data-repeatcolumn="5"
    class="form-control<?= $Page->Specialneeds->isInvalidClass() ?>"
    data-table="student_details"
    data-field="x_Specialneeds"
    data-value-separator="<?= $Page->Specialneeds->displayValueSeparatorAttribute() ?>"
    <?= $Page->Specialneeds->editAttributes() ?>></selection-list>
<div class="invalid-feedback"><?= $Page->Specialneeds->getErrorMessage() ?></div>
</span>
<?php } ?>
<?php if ($Page->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?= $Page->RowCount ?>_student_details_Specialneeds" class="el_student_details_Specialneeds">
<span<?= $Page->Specialneeds->viewAttributes() ?>>
<?= $Page->Specialneeds->getViewValue() ?></span>
</span>
<?php } ?>
</td>
    <?php } ?>
    <?php if ($Page->Grade->Visible) { // Grade ?>
        <td data-name="Grade"<?= $Page->Grade->cellAttributes() ?>>
<?php if ($Page->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?= $Page->RowCount ?>_student_details_Grade" class="el_student_details_Grade">
    <select
        id="x<?= $Page->RowIndex ?>_Grade"
        name="x<?= $Page->RowIndex ?>_Grade"
        class="form-select ew-select<?= $Page->Grade->isInvalidClass() ?>"
        data-select2-id="<?= $Page->FormName ?>_x<?= $Page->RowIndex ?>_Grade"
        data-table="student_details"
        data-field="x_Grade"
        data-value-separator="<?= $Page->Grade->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->Grade->getPlaceHolder()) ?>"
        <?= $Page->Grade->editAttributes() ?>>
        <?= $Page->Grade->selectOptionListHtml("x{$Page->RowIndex}_Grade") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->Grade->getErrorMessage() ?></div>
<script>
loadjs.ready("<?= $Page->FormName ?>", function() {
    var options = { name: "x<?= $Page->RowIndex ?>_Grade", selectId: "<?= $Page->FormName ?>_x<?= $Page->RowIndex ?>_Grade" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (<?= $Page->FormName ?>.lists.Grade?.lookupOptions.length) {
        options.data = { id: "x<?= $Page->RowIndex ?>_Grade", form: "<?= $Page->FormName ?>" };
    } else {
        options.ajax = { id: "x<?= $Page->RowIndex ?>_Grade", form: "<?= $Page->FormName ?>", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.student_details.fields.Grade.selectOptions);
    ew.createSelect(options);
});
</script>
</span>
<input type="hidden" data-table="student_details" data-field="x_Grade" data-hidden="1" data-old name="o<?= $Page->RowIndex ?>_Grade" id="o<?= $Page->RowIndex ?>_Grade" value="<?= HtmlEncode($Page->Grade->OldValue) ?>">
<?php } ?>
<?php if ($Page->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?= $Page->RowCount ?>_student_details_Grade" class="el_student_details_Grade">
    <select
        id="x<?= $Page->RowIndex ?>_Grade"
        name="x<?= $Page->RowIndex ?>_Grade"
        class="form-select ew-select<?= $Page->Grade->isInvalidClass() ?>"
        data-select2-id="<?= $Page->FormName ?>_x<?= $Page->RowIndex ?>_Grade"
        data-table="student_details"
        data-field="x_Grade"
        data-value-separator="<?= $Page->Grade->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->Grade->getPlaceHolder()) ?>"
        <?= $Page->Grade->editAttributes() ?>>
        <?= $Page->Grade->selectOptionListHtml("x{$Page->RowIndex}_Grade") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->Grade->getErrorMessage() ?></div>
<script>
loadjs.ready("<?= $Page->FormName ?>", function() {
    var options = { name: "x<?= $Page->RowIndex ?>_Grade", selectId: "<?= $Page->FormName ?>_x<?= $Page->RowIndex ?>_Grade" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (<?= $Page->FormName ?>.lists.Grade?.lookupOptions.length) {
        options.data = { id: "x<?= $Page->RowIndex ?>_Grade", form: "<?= $Page->FormName ?>" };
    } else {
        options.ajax = { id: "x<?= $Page->RowIndex ?>_Grade", form: "<?= $Page->FormName ?>", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.student_details.fields.Grade.selectOptions);
    ew.createSelect(options);
});
</script>
</span>
<?php } ?>
<?php if ($Page->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?= $Page->RowCount ?>_student_details_Grade" class="el_student_details_Grade">
<span<?= $Page->Grade->viewAttributes() ?>>
<?= $Page->Grade->getViewValue() ?></span>
</span>
<?php } ?>
</td>
    <?php } ?>
    <?php if ($Page->prefect->Visible) { // prefect ?>
        <td data-name="prefect"<?= $Page->prefect->cellAttributes() ?>>
<?php if ($Page->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?= $Page->RowCount ?>_student_details_prefect" class="el_student_details_prefect">
<template id="tp_x<?= $Page->RowIndex ?>_prefect">
    <div class="form-check">
        <input type="radio" class="form-check-input" data-table="student_details" data-field="x_prefect" name="x<?= $Page->RowIndex ?>_prefect" id="x<?= $Page->RowIndex ?>_prefect"<?= $Page->prefect->editAttributes() ?>>
        <label class="form-check-label"></label>
    </div>
</template>
<div id="dsl_x<?= $Page->RowIndex ?>_prefect" class="ew-item-list"></div>
<selection-list hidden
    id="x<?= $Page->RowIndex ?>_prefect"
    name="x<?= $Page->RowIndex ?>_prefect"
    value="<?= HtmlEncode($Page->prefect->CurrentValue) ?>"
    data-type="select-one"
    data-template="tp_x<?= $Page->RowIndex ?>_prefect"
    data-target="dsl_x<?= $Page->RowIndex ?>_prefect"
    data-repeatcolumn="5"
    class="form-control<?= $Page->prefect->isInvalidClass() ?>"
    data-table="student_details"
    data-field="x_prefect"
    data-value-separator="<?= $Page->prefect->displayValueSeparatorAttribute() ?>"
    <?= $Page->prefect->editAttributes() ?>></selection-list>
<div class="invalid-feedback"><?= $Page->prefect->getErrorMessage() ?></div>
</span>
<input type="hidden" data-table="student_details" data-field="x_prefect" data-hidden="1" data-old name="o<?= $Page->RowIndex ?>_prefect" id="o<?= $Page->RowIndex ?>_prefect" value="<?= HtmlEncode($Page->prefect->OldValue) ?>">
<?php } ?>
<?php if ($Page->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?= $Page->RowCount ?>_student_details_prefect" class="el_student_details_prefect">
<template id="tp_x<?= $Page->RowIndex ?>_prefect">
    <div class="form-check">
        <input type="radio" class="form-check-input" data-table="student_details" data-field="x_prefect" name="x<?= $Page->RowIndex ?>_prefect" id="x<?= $Page->RowIndex ?>_prefect"<?= $Page->prefect->editAttributes() ?>>
        <label class="form-check-label"></label>
    </div>
</template>
<div id="dsl_x<?= $Page->RowIndex ?>_prefect" class="ew-item-list"></div>
<selection-list hidden
    id="x<?= $Page->RowIndex ?>_prefect"
    name="x<?= $Page->RowIndex ?>_prefect"
    value="<?= HtmlEncode($Page->prefect->CurrentValue) ?>"
    data-type="select-one"
    data-template="tp_x<?= $Page->RowIndex ?>_prefect"
    data-target="dsl_x<?= $Page->RowIndex ?>_prefect"
    data-repeatcolumn="5"
    class="form-control<?= $Page->prefect->isInvalidClass() ?>"
    data-table="student_details"
    data-field="x_prefect"
    data-value-separator="<?= $Page->prefect->displayValueSeparatorAttribute() ?>"
    <?= $Page->prefect->editAttributes() ?>></selection-list>
<div class="invalid-feedback"><?= $Page->prefect->getErrorMessage() ?></div>
</span>
<?php } ?>
<?php if ($Page->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?= $Page->RowCount ?>_student_details_prefect" class="el_student_details_prefect">
<span<?= $Page->prefect->viewAttributes() ?>>
<?= $Page->prefect->getViewValue() ?></span>
</span>
<?php } ?>
</td>
    <?php } ?>
<?php
// Render list options (body, right)
$Page->ListOptions->render("body", "right", $Page->RowCount);
?>
    </tr>
<?php if ($Page->RowType == ROWTYPE_ADD || $Page->RowType == ROWTYPE_EDIT) { ?>
<script data-rowindex="<?= $Page->RowIndex ?>">
loadjs.ready(["<?= $Page->FormName ?>","load"], () => <?= $Page->FormName ?>.updateLists(<?= $Page->RowIndex ?><?= $Page->RowIndex === '$rowindex$' ? ", true" : "" ?>));
</script>
<?php } ?>
<?php
    }
    } // End delete row checking
    if (
        $Page->Recordset &&
        !$Page->Recordset->EOF &&
        $Page->RowIndex !== '$rowindex$' &&
        (!$Page->isGridAdd() || $Page->CurrentMode == "copy") &&
        (!(($Page->isCopy() || $Page->isAdd()) && $Page->RowIndex == 0))
    ) {
        $Page->Recordset->moveNext();
    }
    // Reset for template row
    if ($Page->RowIndex === '$rowindex$') {
        $Page->RowIndex = 0;
    }
    // Reset inline add/copy row
    if (($Page->isCopy() || $Page->isAdd()) && $Page->RowIndex == 0) {
        $Page->RowIndex = 1;
    }
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
<?php if ($Page->isAdd() || $Page->isCopy()) { ?>
<input type="hidden" name="<?= $Page->FormKeyCountName ?>" id="<?= $Page->FormKeyCountName ?>" value="<?= $Page->KeyCount ?>">
<input type="hidden" name="<?= $Page->OldKeyName ?>" value="<?= $Page->OldKey ?>">
<?php } ?>
<?php if ($Page->isGridAdd()) { ?>
<input type="hidden" name="action" id="action" value="gridinsert">
<input type="hidden" name="<?= $Page->FormKeyCountName ?>" id="<?= $Page->FormKeyCountName ?>" value="<?= $Page->KeyCount ?>">
<?= $Page->MultiSelectKey ?>
<?php } ?>
<?php if ($Page->isEdit()) { ?>
<input type="hidden" name="<?= $Page->FormKeyCountName ?>" id="<?= $Page->FormKeyCountName ?>" value="<?= $Page->KeyCount ?>">
<?php } ?>
<?php if ($Page->isGridEdit() || $Page->isMultiEdit()) { ?>
<?php if ($Page->UpdateConflict == "U") { // Record already updated by other user ?>
<input type="hidden" name="action" id="action" value="gridoverwrite">
<?php } else { ?>
<?php if ($Page->isGridEdit()) { ?>
<input type="hidden" name="action" id="action" value="gridupdate">
<?php } elseif ($Page->isMultiEdit()) { ?>
<input type="hidden" name="action" id="action" value="multiupdate">
<?php } ?>
<?php } ?>
<input type="hidden" name="<?= $Page->FormKeyCountName ?>" id="<?= $Page->FormKeyCountName ?>" value="<?= $Page->KeyCount ?>">
<?= $Page->MultiSelectKey ?>
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$Page->CurrentAction && !$Page->UseAjaxActions) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php
// Close recordset
if ($Page->Recordset) {
    $Page->Recordset->close();
}
?>
<?php if (!$Page->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$Page->isGridAdd() && !($Page->isGridEdit() && $Page->ModalGridEdit) && !$Page->isMultiEdit()) { ?>
<?= $Page->Pager->render() ?>
<?php } ?>
<div class="ew-list-other-options">
<?php $Page->OtherOptions->render("body", "bottom") ?>
</div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } else { ?>
<div class="ew-list-other-options">
<?php $Page->OtherOptions->render("body") ?>
</div>
<?php } ?>
</div>
</main>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<?php if (!$Page->isExport()) { ?>
<script>
// Field event handlers
loadjs.ready("head", function() {
    ew.addEventHandlers("student_details");
});
</script>
<script>
loadjs.ready("load", function () {
    // Write your table-specific startup script here, no need to add script tags.
});
</script>
<?php } ?>
