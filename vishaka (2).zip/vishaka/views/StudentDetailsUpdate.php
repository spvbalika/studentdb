<?php

namespace PHPMaker2023\vishaka2;

// Page object
$StudentDetailsUpdate = &$Page;
?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { student_details: currentTable } });
var currentPageID = ew.PAGE_ID = "update";
var currentForm;
var fstudent_detailsupdate;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery;
    let fields = currentTable.fields;

    // Form object
    let form = new ew.FormBuilder()
        .setId("fstudent_detailsupdate")
        .setPageId("update")

        // Add fields
        .setFields([
            ["AdmissionNo", [fields.AdmissionNo.visible && fields.AdmissionNo.required ? ew.Validators.required(fields.AdmissionNo.caption) : null, ew.Validators.integer, ew.Validators.selected], fields.AdmissionNo.isInvalid],
            ["FullName", [fields.FullName.visible && fields.FullName.required ? ew.Validators.required(fields.FullName.caption) : null], fields.FullName.isInvalid],
            ["NameWithInitials", [fields.NameWithInitials.visible && fields.NameWithInitials.required ? ew.Validators.required(fields.NameWithInitials.caption) : null], fields.NameWithInitials.isInvalid],
            ["FathersName", [fields.FathersName.visible && fields.FathersName.required ? ew.Validators.required(fields.FathersName.caption) : null], fields.FathersName.isInvalid],
            ["MothersName", [fields.MothersName.visible && fields.MothersName.required ? ew.Validators.required(fields.MothersName.caption) : null], fields.MothersName.isInvalid],
            ["Address", [fields.Address.visible && fields.Address.required ? ew.Validators.required(fields.Address.caption) : null], fields.Address.isInvalid],
            ["Occupation", [fields.Occupation.visible && fields.Occupation.required ? ew.Validators.required(fields.Occupation.caption) : null], fields.Occupation.isInvalid],
            ["TravellingMethodtoschoo", [fields.TravellingMethodtoschoo.visible && fields.TravellingMethodtoschoo.required ? ew.Validators.required(fields.TravellingMethodtoschoo.caption) : null], fields.TravellingMethodtoschoo.isInvalid],
            ["inEmergencycontactno", [fields.inEmergencycontactno.visible && fields.inEmergencycontactno.required ? ew.Validators.required(fields.inEmergencycontactno.caption) : null, ew.Validators.integer, ew.Validators.selected], fields.inEmergencycontactno.isInvalid],
            ["Specialneeds", [fields.Specialneeds.visible && fields.Specialneeds.required ? ew.Validators.required(fields.Specialneeds.caption) : null], fields.Specialneeds.isInvalid],
            ["Grade", [fields.Grade.visible && fields.Grade.required ? ew.Validators.required(fields.Grade.caption) : null], fields.Grade.isInvalid],
            ["prefect", [fields.prefect.visible && fields.prefect.required ? ew.Validators.required(fields.prefect.caption) : null], fields.prefect.isInvalid]
        ])

        // Form_CustomValidate
        .setCustomValidate(
            function (fobj) { // DO NOT CHANGE THIS LINE! (except for adding "async" keyword)!
                    // Your custom validation code here, return false if invalid.
                    return true;
                }
        )

        // Use JavaScript validation or not
        .setValidateRequired(ew.CLIENT_VALIDATE)

        // Dynamic selection lists
        .setLists({
            "TravellingMethodtoschoo": <?= $Page->TravellingMethodtoschoo->toClientList($Page) ?>,
            "Specialneeds": <?= $Page->Specialneeds->toClientList($Page) ?>,
            "Grade": <?= $Page->Grade->toClientList($Page) ?>,
            "prefect": <?= $Page->prefect->toClientList($Page) ?>,
        })
        .build();
    window[form.id] = form;
    currentForm = form;
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<form name="fstudent_detailsupdate" id="fstudent_detailsupdate" class="<?= $Page->FormClassName ?>" action="<?= CurrentPageUrl(false) ?>" method="post" novalidate autocomplete="on">
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="student_details">
<?php if ($Page->isConfirm()) { // Confirm page ?>
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="confirm" id="confirm" value="confirm">
<?php } else { ?>
<input type="hidden" name="action" id="action" value="confirm">
<?php } ?>
<input type="hidden" name="modal" value="<?= (int)$Page->IsModal ?>">
<?php foreach ($Page->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?= HtmlEncode($keyvalue) ?>">
<?php } ?>
<div id="tbl_student_detailsupdate" class="ew-update-div"><!-- page -->
    <?php if (!$Page->isConfirm()) { // Confirm page ?>
    <div class="form-check">
        <input type="checkbox" class="form-check-input" name="u" id="u" data-ew-action="select-all"<?= $Page->Disabled ?>><label class="form-check-label" for="u"><?= $Language->phrase("SelectAll") ?></label>
    </div>
    <?php } ?>
<?php if ($Page->AdmissionNo->Visible && (!$Page->isConfirm() || $Page->AdmissionNo->multiUpdateSelected())) { // Admission No ?>
    <div id="r_AdmissionNo"<?= $Page->AdmissionNo->rowAttributes() ?>>
        <label for="x_AdmissionNo" class="<?= $Page->LeftColumnClass ?>">
            <?php if (!$Page->isConfirm()) { ?>
            <div class="form-check">
                <input type="checkbox" name="u_AdmissionNo" id="u_AdmissionNo" class="form-check-input ew-multi-select" value="1"<?= $Page->AdmissionNo->multiUpdateSelected() ? " checked" : "" ?>>
                <label class="form-check-label" for="u_AdmissionNo"><?= $Page->AdmissionNo->caption() ?></label>
            </div>
            <?php } else { ?>
            <input type="hidden" name="u_AdmissionNo" id="u_AdmissionNo" value="<?= $Page->AdmissionNo->MultiUpdate ?>">
            <?= $Page->AdmissionNo->caption() ?>
            <?php } ?>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->AdmissionNo->cellAttributes() ?>>
                <?php if (!$Page->isConfirm()) { ?>
                <span id="el_student_details_AdmissionNo">
                <input type="<?= $Page->AdmissionNo->getInputTextType() ?>" name="x_AdmissionNo" id="x_AdmissionNo" data-table="student_details" data-field="x_AdmissionNo" value="<?= $Page->AdmissionNo->EditValue ?>" size="30" maxlength="100" placeholder="<?= HtmlEncode($Page->AdmissionNo->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->AdmissionNo->formatPattern()) ?>"<?= $Page->AdmissionNo->editAttributes() ?> aria-describedby="x_AdmissionNo_help">
                <?= $Page->AdmissionNo->getCustomMessage() ?>
                <div class="invalid-feedback"><?= $Page->AdmissionNo->getErrorMessage() ?></div>
                <input type="hidden" data-table="student_details" data-field="x_AdmissionNo" data-hidden="1" data-old name="o_AdmissionNo" id="o_AdmissionNo" value="<?= HtmlEncode($Page->AdmissionNo->OldValue ?? $Page->AdmissionNo->CurrentValue) ?>">
                </span>
                <?php } else { ?>
                <span id="el_student_details_AdmissionNo">
                <span<?= $Page->AdmissionNo->viewAttributes() ?>>
                <input type="text" readonly class="form-control-plaintext" value="<?= HtmlEncode(RemoveHtml($Page->AdmissionNo->getDisplayValue($Page->AdmissionNo->ViewValue))) ?>"></span>
                <input type="hidden" data-table="student_details" data-field="x_AdmissionNo" data-hidden="1" name="x_AdmissionNo" id="x_AdmissionNo" value="<?= HtmlEncode($Page->AdmissionNo->FormValue) ?>">
                <input type="hidden" data-table="student_details" data-field="x_AdmissionNo" data-hidden="1" data-old name="o_AdmissionNo" id="o_AdmissionNo" value="<?= HtmlEncode($Page->AdmissionNo->OldValue ?? $Page->AdmissionNo->CurrentValue) ?>">
                </span>
                <?php } ?>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->FullName->Visible && (!$Page->isConfirm() || $Page->FullName->multiUpdateSelected())) { // Full Name ?>
    <div id="r_FullName"<?= $Page->FullName->rowAttributes() ?>>
        <label for="x_FullName" class="<?= $Page->LeftColumnClass ?>">
            <?php if (!$Page->isConfirm()) { ?>
            <div class="form-check">
                <input type="checkbox" name="u_FullName" id="u_FullName" class="form-check-input ew-multi-select" value="1"<?= $Page->FullName->multiUpdateSelected() ? " checked" : "" ?>>
                <label class="form-check-label" for="u_FullName"><?= $Page->FullName->caption() ?></label>
            </div>
            <?php } else { ?>
            <input type="hidden" name="u_FullName" id="u_FullName" value="<?= $Page->FullName->MultiUpdate ?>">
            <?= $Page->FullName->caption() ?>
            <?php } ?>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->FullName->cellAttributes() ?>>
                <?php if (!$Page->isConfirm()) { ?>
                <span id="el_student_details_FullName">
                <textarea data-table="student_details" data-field="x_FullName" name="x_FullName" id="x_FullName" cols="35" rows="4" placeholder="<?= HtmlEncode($Page->FullName->getPlaceHolder()) ?>"<?= $Page->FullName->editAttributes() ?> aria-describedby="x_FullName_help"><?= $Page->FullName->EditValue ?></textarea>
                <?= $Page->FullName->getCustomMessage() ?>
                <div class="invalid-feedback"><?= $Page->FullName->getErrorMessage() ?></div>
                </span>
                <?php } else { ?>
                <span id="el_student_details_FullName">
                <span<?= $Page->FullName->viewAttributes() ?>>
                <?= $Page->FullName->ViewValue ?></span>
                <input type="hidden" data-table="student_details" data-field="x_FullName" data-hidden="1" name="x_FullName" id="x_FullName" value="<?= HtmlEncode($Page->FullName->FormValue) ?>">
                </span>
                <?php } ?>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->NameWithInitials->Visible && (!$Page->isConfirm() || $Page->NameWithInitials->multiUpdateSelected())) { // Name With Initials ?>
    <div id="r_NameWithInitials"<?= $Page->NameWithInitials->rowAttributes() ?>>
        <label for="x_NameWithInitials" class="<?= $Page->LeftColumnClass ?>">
            <?php if (!$Page->isConfirm()) { ?>
            <div class="form-check">
                <input type="checkbox" name="u_NameWithInitials" id="u_NameWithInitials" class="form-check-input ew-multi-select" value="1"<?= $Page->NameWithInitials->multiUpdateSelected() ? " checked" : "" ?>>
                <label class="form-check-label" for="u_NameWithInitials"><?= $Page->NameWithInitials->caption() ?></label>
            </div>
            <?php } else { ?>
            <input type="hidden" name="u_NameWithInitials" id="u_NameWithInitials" value="<?= $Page->NameWithInitials->MultiUpdate ?>">
            <?= $Page->NameWithInitials->caption() ?>
            <?php } ?>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->NameWithInitials->cellAttributes() ?>>
                <?php if (!$Page->isConfirm()) { ?>
                <span id="el_student_details_NameWithInitials">
                <textarea data-table="student_details" data-field="x_NameWithInitials" name="x_NameWithInitials" id="x_NameWithInitials" cols="35" rows="4" placeholder="<?= HtmlEncode($Page->NameWithInitials->getPlaceHolder()) ?>"<?= $Page->NameWithInitials->editAttributes() ?> aria-describedby="x_NameWithInitials_help"><?= $Page->NameWithInitials->EditValue ?></textarea>
                <?= $Page->NameWithInitials->getCustomMessage() ?>
                <div class="invalid-feedback"><?= $Page->NameWithInitials->getErrorMessage() ?></div>
                </span>
                <?php } else { ?>
                <span id="el_student_details_NameWithInitials">
                <span<?= $Page->NameWithInitials->viewAttributes() ?>>
                <?= $Page->NameWithInitials->ViewValue ?></span>
                <input type="hidden" data-table="student_details" data-field="x_NameWithInitials" data-hidden="1" name="x_NameWithInitials" id="x_NameWithInitials" value="<?= HtmlEncode($Page->NameWithInitials->FormValue) ?>">
                </span>
                <?php } ?>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->FathersName->Visible && (!$Page->isConfirm() || $Page->FathersName->multiUpdateSelected())) { // Father's Name ?>
    <div id="r_FathersName"<?= $Page->FathersName->rowAttributes() ?>>
        <label for="x_FathersName" class="<?= $Page->LeftColumnClass ?>">
            <?php if (!$Page->isConfirm()) { ?>
            <div class="form-check">
                <input type="checkbox" name="u_FathersName" id="u_FathersName" class="form-check-input ew-multi-select" value="1"<?= $Page->FathersName->multiUpdateSelected() ? " checked" : "" ?>>
                <label class="form-check-label" for="u_FathersName"><?= $Page->FathersName->caption() ?></label>
            </div>
            <?php } else { ?>
            <input type="hidden" name="u_FathersName" id="u_FathersName" value="<?= $Page->FathersName->MultiUpdate ?>">
            <?= $Page->FathersName->caption() ?>
            <?php } ?>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->FathersName->cellAttributes() ?>>
                <?php if (!$Page->isConfirm()) { ?>
                <span id="el_student_details_FathersName">
                <textarea data-table="student_details" data-field="x_FathersName" name="x_FathersName" id="x_FathersName" cols="35" rows="4" placeholder="<?= HtmlEncode($Page->FathersName->getPlaceHolder()) ?>"<?= $Page->FathersName->editAttributes() ?> aria-describedby="x_FathersName_help"><?= $Page->FathersName->EditValue ?></textarea>
                <?= $Page->FathersName->getCustomMessage() ?>
                <div class="invalid-feedback"><?= $Page->FathersName->getErrorMessage() ?></div>
                </span>
                <?php } else { ?>
                <span id="el_student_details_FathersName">
                <span<?= $Page->FathersName->viewAttributes() ?>>
                <?= $Page->FathersName->ViewValue ?></span>
                <input type="hidden" data-table="student_details" data-field="x_FathersName" data-hidden="1" name="x_FathersName" id="x_FathersName" value="<?= HtmlEncode($Page->FathersName->FormValue) ?>">
                </span>
                <?php } ?>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->MothersName->Visible && (!$Page->isConfirm() || $Page->MothersName->multiUpdateSelected())) { // Mother's Name ?>
    <div id="r_MothersName"<?= $Page->MothersName->rowAttributes() ?>>
        <label for="x_MothersName" class="<?= $Page->LeftColumnClass ?>">
            <?php if (!$Page->isConfirm()) { ?>
            <div class="form-check">
                <input type="checkbox" name="u_MothersName" id="u_MothersName" class="form-check-input ew-multi-select" value="1"<?= $Page->MothersName->multiUpdateSelected() ? " checked" : "" ?>>
                <label class="form-check-label" for="u_MothersName"><?= $Page->MothersName->caption() ?></label>
            </div>
            <?php } else { ?>
            <input type="hidden" name="u_MothersName" id="u_MothersName" value="<?= $Page->MothersName->MultiUpdate ?>">
            <?= $Page->MothersName->caption() ?>
            <?php } ?>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->MothersName->cellAttributes() ?>>
                <?php if (!$Page->isConfirm()) { ?>
                <span id="el_student_details_MothersName">
                <textarea data-table="student_details" data-field="x_MothersName" name="x_MothersName" id="x_MothersName" cols="35" rows="4" placeholder="<?= HtmlEncode($Page->MothersName->getPlaceHolder()) ?>"<?= $Page->MothersName->editAttributes() ?> aria-describedby="x_MothersName_help"><?= $Page->MothersName->EditValue ?></textarea>
                <?= $Page->MothersName->getCustomMessage() ?>
                <div class="invalid-feedback"><?= $Page->MothersName->getErrorMessage() ?></div>
                </span>
                <?php } else { ?>
                <span id="el_student_details_MothersName">
                <span<?= $Page->MothersName->viewAttributes() ?>>
                <?= $Page->MothersName->ViewValue ?></span>
                <input type="hidden" data-table="student_details" data-field="x_MothersName" data-hidden="1" name="x_MothersName" id="x_MothersName" value="<?= HtmlEncode($Page->MothersName->FormValue) ?>">
                </span>
                <?php } ?>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->Address->Visible && (!$Page->isConfirm() || $Page->Address->multiUpdateSelected())) { // Address ?>
    <div id="r_Address"<?= $Page->Address->rowAttributes() ?>>
        <label for="x_Address" class="<?= $Page->LeftColumnClass ?>">
            <?php if (!$Page->isConfirm()) { ?>
            <div class="form-check">
                <input type="checkbox" name="u_Address" id="u_Address" class="form-check-input ew-multi-select" value="1"<?= $Page->Address->multiUpdateSelected() ? " checked" : "" ?>>
                <label class="form-check-label" for="u_Address"><?= $Page->Address->caption() ?></label>
            </div>
            <?php } else { ?>
            <input type="hidden" name="u_Address" id="u_Address" value="<?= $Page->Address->MultiUpdate ?>">
            <?= $Page->Address->caption() ?>
            <?php } ?>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->Address->cellAttributes() ?>>
                <?php if (!$Page->isConfirm()) { ?>
                <span id="el_student_details_Address">
                <textarea data-table="student_details" data-field="x_Address" name="x_Address" id="x_Address" cols="35" rows="4" placeholder="<?= HtmlEncode($Page->Address->getPlaceHolder()) ?>"<?= $Page->Address->editAttributes() ?> aria-describedby="x_Address_help"><?= $Page->Address->EditValue ?></textarea>
                <?= $Page->Address->getCustomMessage() ?>
                <div class="invalid-feedback"><?= $Page->Address->getErrorMessage() ?></div>
                </span>
                <?php } else { ?>
                <span id="el_student_details_Address">
                <span<?= $Page->Address->viewAttributes() ?>>
                <?= $Page->Address->ViewValue ?></span>
                <input type="hidden" data-table="student_details" data-field="x_Address" data-hidden="1" name="x_Address" id="x_Address" value="<?= HtmlEncode($Page->Address->FormValue) ?>">
                </span>
                <?php } ?>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->Occupation->Visible && (!$Page->isConfirm() || $Page->Occupation->multiUpdateSelected())) { // Occupation ?>
    <div id="r_Occupation"<?= $Page->Occupation->rowAttributes() ?>>
        <label for="x_Occupation" class="<?= $Page->LeftColumnClass ?>">
            <?php if (!$Page->isConfirm()) { ?>
            <div class="form-check">
                <input type="checkbox" name="u_Occupation" id="u_Occupation" class="form-check-input ew-multi-select" value="1"<?= $Page->Occupation->multiUpdateSelected() ? " checked" : "" ?>>
                <label class="form-check-label" for="u_Occupation"><?= $Page->Occupation->caption() ?></label>
            </div>
            <?php } else { ?>
            <input type="hidden" name="u_Occupation" id="u_Occupation" value="<?= $Page->Occupation->MultiUpdate ?>">
            <?= $Page->Occupation->caption() ?>
            <?php } ?>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->Occupation->cellAttributes() ?>>
                <?php if (!$Page->isConfirm()) { ?>
                <span id="el_student_details_Occupation">
                <textarea data-table="student_details" data-field="x_Occupation" name="x_Occupation" id="x_Occupation" cols="35" rows="4" placeholder="<?= HtmlEncode($Page->Occupation->getPlaceHolder()) ?>"<?= $Page->Occupation->editAttributes() ?> aria-describedby="x_Occupation_help"><?= $Page->Occupation->EditValue ?></textarea>
                <?= $Page->Occupation->getCustomMessage() ?>
                <div class="invalid-feedback"><?= $Page->Occupation->getErrorMessage() ?></div>
                </span>
                <?php } else { ?>
                <span id="el_student_details_Occupation">
                <span<?= $Page->Occupation->viewAttributes() ?>>
                <?= $Page->Occupation->ViewValue ?></span>
                <input type="hidden" data-table="student_details" data-field="x_Occupation" data-hidden="1" name="x_Occupation" id="x_Occupation" value="<?= HtmlEncode($Page->Occupation->FormValue) ?>">
                </span>
                <?php } ?>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->TravellingMethodtoschoo->Visible && (!$Page->isConfirm() || $Page->TravellingMethodtoschoo->multiUpdateSelected())) { // Travelling Method to schoo ?>
    <div id="r_TravellingMethodtoschoo"<?= $Page->TravellingMethodtoschoo->rowAttributes() ?>>
        <label for="x_TravellingMethodtoschoo" class="<?= $Page->LeftColumnClass ?>">
            <?php if (!$Page->isConfirm()) { ?>
            <div class="form-check">
                <input type="checkbox" name="u_TravellingMethodtoschoo" id="u_TravellingMethodtoschoo" class="form-check-input ew-multi-select" value="1"<?= $Page->TravellingMethodtoschoo->multiUpdateSelected() ? " checked" : "" ?>>
                <label class="form-check-label" for="u_TravellingMethodtoschoo"><?= $Page->TravellingMethodtoschoo->caption() ?></label>
            </div>
            <?php } else { ?>
            <input type="hidden" name="u_TravellingMethodtoschoo" id="u_TravellingMethodtoschoo" value="<?= $Page->TravellingMethodtoschoo->MultiUpdate ?>">
            <?= $Page->TravellingMethodtoschoo->caption() ?>
            <?php } ?>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->TravellingMethodtoschoo->cellAttributes() ?>>
                <?php if (!$Page->isConfirm()) { ?>
                <span id="el_student_details_TravellingMethodtoschoo">
                    <select
                        id="x_TravellingMethodtoschoo"
                        name="x_TravellingMethodtoschoo"
                        class="form-select ew-select<?= $Page->TravellingMethodtoschoo->isInvalidClass() ?>"
                        data-select2-id="fstudent_detailsupdate_x_TravellingMethodtoschoo"
                        data-table="student_details"
                        data-field="x_TravellingMethodtoschoo"
                        data-value-separator="<?= $Page->TravellingMethodtoschoo->displayValueSeparatorAttribute() ?>"
                        data-placeholder="<?= HtmlEncode($Page->TravellingMethodtoschoo->getPlaceHolder()) ?>"
                        <?= $Page->TravellingMethodtoschoo->editAttributes() ?>>
                        <?= $Page->TravellingMethodtoschoo->selectOptionListHtml("x_TravellingMethodtoschoo") ?>
                    </select>
                    <?= $Page->TravellingMethodtoschoo->getCustomMessage() ?>
                    <div class="invalid-feedback"><?= $Page->TravellingMethodtoschoo->getErrorMessage() ?></div>
                <script>
                loadjs.ready("fstudent_detailsupdate", function() {
                    var options = { name: "x_TravellingMethodtoschoo", selectId: "fstudent_detailsupdate_x_TravellingMethodtoschoo" },
                        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
                    options.closeOnSelect = !options.multiple;
                    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
                    if (fstudent_detailsupdate.lists.TravellingMethodtoschoo?.lookupOptions.length) {
                        options.data = { id: "x_TravellingMethodtoschoo", form: "fstudent_detailsupdate" };
                    } else {
                        options.ajax = { id: "x_TravellingMethodtoschoo", form: "fstudent_detailsupdate", limit: ew.LOOKUP_PAGE_SIZE };
                    }
                    options.minimumResultsForSearch = Infinity;
                    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.student_details.fields.TravellingMethodtoschoo.selectOptions);
                    ew.createSelect(options);
                });
                </script>
                </span>
                <?php } else { ?>
                <span id="el_student_details_TravellingMethodtoschoo">
                <span<?= $Page->TravellingMethodtoschoo->viewAttributes() ?>>
                <span class="form-control-plaintext"><?= $Page->TravellingMethodtoschoo->getDisplayValue($Page->TravellingMethodtoschoo->ViewValue) ?></span></span>
                <input type="hidden" data-table="student_details" data-field="x_TravellingMethodtoschoo" data-hidden="1" name="x_TravellingMethodtoschoo" id="x_TravellingMethodtoschoo" value="<?= HtmlEncode($Page->TravellingMethodtoschoo->FormValue) ?>">
                </span>
                <?php } ?>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->inEmergencycontactno->Visible && (!$Page->isConfirm() || $Page->inEmergencycontactno->multiUpdateSelected())) { // in Emergency contact no ?>
    <div id="r_inEmergencycontactno"<?= $Page->inEmergencycontactno->rowAttributes() ?>>
        <label for="x_inEmergencycontactno" class="<?= $Page->LeftColumnClass ?>">
            <?php if (!$Page->isConfirm()) { ?>
            <div class="form-check">
                <input type="checkbox" name="u_inEmergencycontactno" id="u_inEmergencycontactno" class="form-check-input ew-multi-select" value="1"<?= $Page->inEmergencycontactno->multiUpdateSelected() ? " checked" : "" ?>>
                <label class="form-check-label" for="u_inEmergencycontactno"><?= $Page->inEmergencycontactno->caption() ?></label>
            </div>
            <?php } else { ?>
            <input type="hidden" name="u_inEmergencycontactno" id="u_inEmergencycontactno" value="<?= $Page->inEmergencycontactno->MultiUpdate ?>">
            <?= $Page->inEmergencycontactno->caption() ?>
            <?php } ?>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->inEmergencycontactno->cellAttributes() ?>>
                <?php if (!$Page->isConfirm()) { ?>
                <span id="el_student_details_inEmergencycontactno">
                <input type="<?= $Page->inEmergencycontactno->getInputTextType() ?>" name="x_inEmergencycontactno" id="x_inEmergencycontactno" data-table="student_details" data-field="x_inEmergencycontactno" value="<?= $Page->inEmergencycontactno->EditValue ?>" size="30" placeholder="<?= HtmlEncode($Page->inEmergencycontactno->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->inEmergencycontactno->formatPattern()) ?>"<?= $Page->inEmergencycontactno->editAttributes() ?> aria-describedby="x_inEmergencycontactno_help">
                <?= $Page->inEmergencycontactno->getCustomMessage() ?>
                <div class="invalid-feedback"><?= $Page->inEmergencycontactno->getErrorMessage() ?></div>
                </span>
                <?php } else { ?>
                <span id="el_student_details_inEmergencycontactno">
                <span<?= $Page->inEmergencycontactno->viewAttributes() ?>>
                <input type="text" readonly class="form-control-plaintext" value="<?= HtmlEncode(RemoveHtml($Page->inEmergencycontactno->getDisplayValue($Page->inEmergencycontactno->ViewValue))) ?>"></span>
                <input type="hidden" data-table="student_details" data-field="x_inEmergencycontactno" data-hidden="1" name="x_inEmergencycontactno" id="x_inEmergencycontactno" value="<?= HtmlEncode($Page->inEmergencycontactno->FormValue) ?>">
                </span>
                <?php } ?>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->Specialneeds->Visible && (!$Page->isConfirm() || $Page->Specialneeds->multiUpdateSelected())) { // Special needs ?>
    <div id="r_Specialneeds"<?= $Page->Specialneeds->rowAttributes() ?>>
        <label class="<?= $Page->LeftColumnClass ?>">
            <?php if (!$Page->isConfirm()) { ?>
            <div class="form-check">
                <input type="checkbox" name="u_Specialneeds" id="u_Specialneeds" class="form-check-input ew-multi-select" value="1"<?= $Page->Specialneeds->multiUpdateSelected() ? " checked" : "" ?>>
                <label class="form-check-label" for="u_Specialneeds"><?= $Page->Specialneeds->caption() ?></label>
            </div>
            <?php } else { ?>
            <input type="hidden" name="u_Specialneeds" id="u_Specialneeds" value="<?= $Page->Specialneeds->MultiUpdate ?>">
            <?= $Page->Specialneeds->caption() ?>
            <?php } ?>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->Specialneeds->cellAttributes() ?>>
                <?php if (!$Page->isConfirm()) { ?>
                <span id="el_student_details_Specialneeds">
                <template id="tp_x_Specialneeds">
                    <div class="form-check">
                        <input type="radio" class="form-check-input" data-table="student_details" data-field="x_Specialneeds" name="x_Specialneeds" id="x_Specialneeds"<?= $Page->Specialneeds->editAttributes() ?>>
                        <label class="form-check-label"></label>
                    </div>
                </template>
                <div id="dsl_x_Specialneeds" class="ew-item-list"></div>
                <selection-list hidden
                    id="x_Specialneeds"
                    name="x_Specialneeds"
                    value="<?= HtmlEncode($Page->Specialneeds->CurrentValue) ?>"
                    data-type="select-one"
                    data-template="tp_x_Specialneeds"
                    data-target="dsl_x_Specialneeds"
                    data-repeatcolumn="5"
                    class="form-control<?= $Page->Specialneeds->isInvalidClass() ?>"
                    data-table="student_details"
                    data-field="x_Specialneeds"
                    data-value-separator="<?= $Page->Specialneeds->displayValueSeparatorAttribute() ?>"
                    <?= $Page->Specialneeds->editAttributes() ?>></selection-list>
                <?= $Page->Specialneeds->getCustomMessage() ?>
                <div class="invalid-feedback"><?= $Page->Specialneeds->getErrorMessage() ?></div>
                </span>
                <?php } else { ?>
                <span id="el_student_details_Specialneeds">
                <span<?= $Page->Specialneeds->viewAttributes() ?>>
                <span class="form-control-plaintext"><?= $Page->Specialneeds->getDisplayValue($Page->Specialneeds->ViewValue) ?></span></span>
                <input type="hidden" data-table="student_details" data-field="x_Specialneeds" data-hidden="1" name="x_Specialneeds" id="x_Specialneeds" value="<?= HtmlEncode($Page->Specialneeds->FormValue) ?>">
                </span>
                <?php } ?>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->Grade->Visible && (!$Page->isConfirm() || $Page->Grade->multiUpdateSelected())) { // Grade ?>
    <div id="r_Grade"<?= $Page->Grade->rowAttributes() ?>>
        <label for="x_Grade" class="<?= $Page->LeftColumnClass ?>">
            <?php if (!$Page->isConfirm()) { ?>
            <div class="form-check">
                <input type="checkbox" name="u_Grade" id="u_Grade" class="form-check-input ew-multi-select" value="1"<?= $Page->Grade->multiUpdateSelected() ? " checked" : "" ?>>
                <label class="form-check-label" for="u_Grade"><?= $Page->Grade->caption() ?></label>
            </div>
            <?php } else { ?>
            <input type="hidden" name="u_Grade" id="u_Grade" value="<?= $Page->Grade->MultiUpdate ?>">
            <?= $Page->Grade->caption() ?>
            <?php } ?>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->Grade->cellAttributes() ?>>
                <?php if (!$Page->isConfirm()) { ?>
                <span id="el_student_details_Grade">
                    <select
                        id="x_Grade"
                        name="x_Grade"
                        class="form-select ew-select<?= $Page->Grade->isInvalidClass() ?>"
                        data-select2-id="fstudent_detailsupdate_x_Grade"
                        data-table="student_details"
                        data-field="x_Grade"
                        data-value-separator="<?= $Page->Grade->displayValueSeparatorAttribute() ?>"
                        data-placeholder="<?= HtmlEncode($Page->Grade->getPlaceHolder()) ?>"
                        <?= $Page->Grade->editAttributes() ?>>
                        <?= $Page->Grade->selectOptionListHtml("x_Grade") ?>
                    </select>
                    <?= $Page->Grade->getCustomMessage() ?>
                    <div class="invalid-feedback"><?= $Page->Grade->getErrorMessage() ?></div>
                <script>
                loadjs.ready("fstudent_detailsupdate", function() {
                    var options = { name: "x_Grade", selectId: "fstudent_detailsupdate_x_Grade" },
                        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
                    options.closeOnSelect = !options.multiple;
                    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
                    if (fstudent_detailsupdate.lists.Grade?.lookupOptions.length) {
                        options.data = { id: "x_Grade", form: "fstudent_detailsupdate" };
                    } else {
                        options.ajax = { id: "x_Grade", form: "fstudent_detailsupdate", limit: ew.LOOKUP_PAGE_SIZE };
                    }
                    options.minimumResultsForSearch = Infinity;
                    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.student_details.fields.Grade.selectOptions);
                    ew.createSelect(options);
                });
                </script>
                </span>
                <?php } else { ?>
                <span id="el_student_details_Grade">
                <span<?= $Page->Grade->viewAttributes() ?>>
                <span class="form-control-plaintext"><?= $Page->Grade->getDisplayValue($Page->Grade->ViewValue) ?></span></span>
                <input type="hidden" data-table="student_details" data-field="x_Grade" data-hidden="1" name="x_Grade" id="x_Grade" value="<?= HtmlEncode($Page->Grade->FormValue) ?>">
                </span>
                <?php } ?>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->prefect->Visible && (!$Page->isConfirm() || $Page->prefect->multiUpdateSelected())) { // prefect ?>
    <div id="r_prefect"<?= $Page->prefect->rowAttributes() ?>>
        <label class="<?= $Page->LeftColumnClass ?>">
            <?php if (!$Page->isConfirm()) { ?>
            <div class="form-check">
                <input type="checkbox" name="u_prefect" id="u_prefect" class="form-check-input ew-multi-select" value="1"<?= $Page->prefect->multiUpdateSelected() ? " checked" : "" ?>>
                <label class="form-check-label" for="u_prefect"><?= $Page->prefect->caption() ?></label>
            </div>
            <?php } else { ?>
            <input type="hidden" name="u_prefect" id="u_prefect" value="<?= $Page->prefect->MultiUpdate ?>">
            <?= $Page->prefect->caption() ?>
            <?php } ?>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->prefect->cellAttributes() ?>>
                <?php if (!$Page->isConfirm()) { ?>
                <span id="el_student_details_prefect">
                <template id="tp_x_prefect">
                    <div class="form-check">
                        <input type="radio" class="form-check-input" data-table="student_details" data-field="x_prefect" name="x_prefect" id="x_prefect"<?= $Page->prefect->editAttributes() ?>>
                        <label class="form-check-label"></label>
                    </div>
                </template>
                <div id="dsl_x_prefect" class="ew-item-list"></div>
                <selection-list hidden
                    id="x_prefect"
                    name="x_prefect"
                    value="<?= HtmlEncode($Page->prefect->CurrentValue) ?>"
                    data-type="select-one"
                    data-template="tp_x_prefect"
                    data-target="dsl_x_prefect"
                    data-repeatcolumn="5"
                    class="form-control<?= $Page->prefect->isInvalidClass() ?>"
                    data-table="student_details"
                    data-field="x_prefect"
                    data-value-separator="<?= $Page->prefect->displayValueSeparatorAttribute() ?>"
                    <?= $Page->prefect->editAttributes() ?>></selection-list>
                <?= $Page->prefect->getCustomMessage() ?>
                <div class="invalid-feedback"><?= $Page->prefect->getErrorMessage() ?></div>
                </span>
                <?php } else { ?>
                <span id="el_student_details_prefect">
                <span<?= $Page->prefect->viewAttributes() ?>>
                <span class="form-control-plaintext"><?= $Page->prefect->getDisplayValue($Page->prefect->ViewValue) ?></span></span>
                <input type="hidden" data-table="student_details" data-field="x_prefect" data-hidden="1" name="x_prefect" id="x_prefect" value="<?= HtmlEncode($Page->prefect->FormValue) ?>">
                </span>
                <?php } ?>
            </div>
        </div>
    </div>
<?php } ?>
</div><!-- /page -->
<?= $Page->IsModal ? '<template class="ew-modal-buttons">' : '<div class="row ew-buttons">' ?><!-- buttons .row -->
    <div class="<?= $Page->OffsetColumnClass ?>"><!-- buttons offset -->
<?php if (!$Page->isConfirm()) { // Confirm page ?>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit" form="fstudent_detailsupdate" data-ew-action="set-action" data-value="confirm"><?= $Language->phrase("UpdateBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" form="fstudent_detailsupdate" data-href="<?= HtmlEncode(GetUrl($Page->getReturnUrl())) ?>"><?= $Language->phrase("CancelBtn") ?></button>
<?php } else { ?>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit" form="fstudent_detailsupdate"><?= $Language->phrase("ConfirmBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="submit" form="fstudent_detailsupdate" data-ew-action="set-action" data-value="cancel"><?= $Language->phrase("CancelBtn") ?></button>
<?php } ?>
    </div><!-- /buttons offset -->
<?= $Page->IsModal ? "</template>" : "</div>" ?><!-- /buttons .row -->
</form>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<script>
// Field event handlers
loadjs.ready("head", function() {
    ew.addEventHandlers("student_details");
});
</script>
<script>
loadjs.ready("load", function () {
    // Write your table-specific startup script here, no need to add script tags.
});
</script>
