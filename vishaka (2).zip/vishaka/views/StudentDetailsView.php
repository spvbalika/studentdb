<?php

namespace PHPMaker2023\vishaka2;

// Page object
$StudentDetailsView = &$Page;
?>
<?php if (!$Page->isExport()) { ?>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php } ?>
<?php if (!$Page->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $Page->ExportOptions->render("body") ?>
<?php $Page->OtherOptions->render("body") ?>
</div>
<?php } ?>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<main class="view">
<form name="fstudent_detailsview" id="fstudent_detailsview" class="ew-form ew-view-form overlay-wrapper" action="<?= CurrentPageUrl(false) ?>" method="post" novalidate autocomplete="on">
<?php if (!$Page->isExport()) { ?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { student_details: currentTable } });
var currentPageID = ew.PAGE_ID = "view";
var currentForm;
var fstudent_detailsview;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery;
    let fields = currentTable.fields;

    // Form object
    let form = new ew.FormBuilder()
        .setId("fstudent_detailsview")
        .setPageId("view")
        .build();
    window[form.id] = form;
    currentForm = form;
    loadjs.done(form.id);
});
</script>
<?php } ?>
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="student_details">
<input type="hidden" name="modal" value="<?= (int)$Page->IsModal ?>">
<table class="<?= $Page->TableClass ?>">
<?php if ($Page->AdmissionNo->Visible) { // Admission No ?>
    <tr id="r_AdmissionNo"<?= $Page->AdmissionNo->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_student_details_AdmissionNo"><?= $Page->AdmissionNo->caption() ?></span></td>
        <td data-name="AdmissionNo"<?= $Page->AdmissionNo->cellAttributes() ?>>
<span id="el_student_details_AdmissionNo">
<span<?= $Page->AdmissionNo->viewAttributes() ?>>
<?= $Page->AdmissionNo->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->FullName->Visible) { // Full Name ?>
    <tr id="r_FullName"<?= $Page->FullName->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_student_details_FullName"><?= $Page->FullName->caption() ?></span></td>
        <td data-name="FullName"<?= $Page->FullName->cellAttributes() ?>>
<span id="el_student_details_FullName">
<span<?= $Page->FullName->viewAttributes() ?>>
<?= $Page->FullName->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->NameWithInitials->Visible) { // Name With Initials ?>
    <tr id="r_NameWithInitials"<?= $Page->NameWithInitials->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_student_details_NameWithInitials"><?= $Page->NameWithInitials->caption() ?></span></td>
        <td data-name="NameWithInitials"<?= $Page->NameWithInitials->cellAttributes() ?>>
<span id="el_student_details_NameWithInitials">
<span<?= $Page->NameWithInitials->viewAttributes() ?>>
<?= $Page->NameWithInitials->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->FathersName->Visible) { // Father's Name ?>
    <tr id="r_FathersName"<?= $Page->FathersName->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_student_details_FathersName"><?= $Page->FathersName->caption() ?></span></td>
        <td data-name="FathersName"<?= $Page->FathersName->cellAttributes() ?>>
<span id="el_student_details_FathersName">
<span<?= $Page->FathersName->viewAttributes() ?>>
<?= $Page->FathersName->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->MothersName->Visible) { // Mother's Name ?>
    <tr id="r_MothersName"<?= $Page->MothersName->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_student_details_MothersName"><?= $Page->MothersName->caption() ?></span></td>
        <td data-name="MothersName"<?= $Page->MothersName->cellAttributes() ?>>
<span id="el_student_details_MothersName">
<span<?= $Page->MothersName->viewAttributes() ?>>
<?= $Page->MothersName->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->Address->Visible) { // Address ?>
    <tr id="r_Address"<?= $Page->Address->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_student_details_Address"><?= $Page->Address->caption() ?></span></td>
        <td data-name="Address"<?= $Page->Address->cellAttributes() ?>>
<span id="el_student_details_Address">
<span<?= $Page->Address->viewAttributes() ?>>
<?= $Page->Address->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->Occupation->Visible) { // Occupation ?>
    <tr id="r_Occupation"<?= $Page->Occupation->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_student_details_Occupation"><?= $Page->Occupation->caption() ?></span></td>
        <td data-name="Occupation"<?= $Page->Occupation->cellAttributes() ?>>
<span id="el_student_details_Occupation">
<span<?= $Page->Occupation->viewAttributes() ?>>
<?= $Page->Occupation->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->TravellingMethodtoschoo->Visible) { // Travelling Method to schoo ?>
    <tr id="r_TravellingMethodtoschoo"<?= $Page->TravellingMethodtoschoo->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_student_details_TravellingMethodtoschoo"><?= $Page->TravellingMethodtoschoo->caption() ?></span></td>
        <td data-name="TravellingMethodtoschoo"<?= $Page->TravellingMethodtoschoo->cellAttributes() ?>>
<span id="el_student_details_TravellingMethodtoschoo">
<span<?= $Page->TravellingMethodtoschoo->viewAttributes() ?>>
<?= $Page->TravellingMethodtoschoo->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->inEmergencycontactno->Visible) { // in Emergency contact no ?>
    <tr id="r_inEmergencycontactno"<?= $Page->inEmergencycontactno->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_student_details_inEmergencycontactno"><?= $Page->inEmergencycontactno->caption() ?></span></td>
        <td data-name="inEmergencycontactno"<?= $Page->inEmergencycontactno->cellAttributes() ?>>
<span id="el_student_details_inEmergencycontactno">
<span<?= $Page->inEmergencycontactno->viewAttributes() ?>>
<?= $Page->inEmergencycontactno->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->Specialneeds->Visible) { // Special needs ?>
    <tr id="r_Specialneeds"<?= $Page->Specialneeds->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_student_details_Specialneeds"><?= $Page->Specialneeds->caption() ?></span></td>
        <td data-name="Specialneeds"<?= $Page->Specialneeds->cellAttributes() ?>>
<span id="el_student_details_Specialneeds">
<span<?= $Page->Specialneeds->viewAttributes() ?>>
<?= $Page->Specialneeds->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->Grade->Visible) { // Grade ?>
    <tr id="r_Grade"<?= $Page->Grade->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_student_details_Grade"><?= $Page->Grade->caption() ?></span></td>
        <td data-name="Grade"<?= $Page->Grade->cellAttributes() ?>>
<span id="el_student_details_Grade">
<span<?= $Page->Grade->viewAttributes() ?>>
<?= $Page->Grade->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->prefect->Visible) { // prefect ?>
    <tr id="r_prefect"<?= $Page->prefect->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_student_details_prefect"><?= $Page->prefect->caption() ?></span></td>
        <td data-name="prefect"<?= $Page->prefect->cellAttributes() ?>>
<span id="el_student_details_prefect">
<span<?= $Page->prefect->viewAttributes() ?>>
<?= $Page->prefect->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
</table>
</form>
</main>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<?php if (!$Page->isExport()) { ?>
<script>
loadjs.ready("load", function () {
    // Write your table-specific startup script here, no need to add script tags.
});
</script>
<?php } ?>
