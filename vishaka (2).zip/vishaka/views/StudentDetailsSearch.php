<?php

namespace PHPMaker2023\vishaka2;

// Page object
$StudentDetailsSearch = &$Page;
?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { student_details: currentTable } });
var currentPageID = ew.PAGE_ID = "search";
var currentForm;
var fstudent_detailssearch, currentSearchForm, currentAdvancedSearchForm;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery,
        fields = currentTable.fields;

    // Form object for search
    let form = new ew.FormBuilder()
        .setId("fstudent_detailssearch")
        .setPageId("search")
<?php if ($Page->IsModal && $Page->UseAjaxActions) { ?>
        .setSubmitWithFetch(true)
<?php } ?>

        // Add fields
        .addFields([
            ["AdmissionNo", [ew.Validators.integer], fields.AdmissionNo.isInvalid],
            ["FullName", [], fields.FullName.isInvalid],
            ["NameWithInitials", [], fields.NameWithInitials.isInvalid],
            ["FathersName", [], fields.FathersName.isInvalid],
            ["MothersName", [], fields.MothersName.isInvalid],
            ["Address", [], fields.Address.isInvalid],
            ["Occupation", [], fields.Occupation.isInvalid],
            ["TravellingMethodtoschoo", [], fields.TravellingMethodtoschoo.isInvalid],
            ["inEmergencycontactno", [ew.Validators.integer], fields.inEmergencycontactno.isInvalid],
            ["Specialneeds", [], fields.Specialneeds.isInvalid],
            ["Grade", [], fields.Grade.isInvalid],
            ["prefect", [], fields.prefect.isInvalid]
        ])
        // Validate form
        .setValidate(
            async function () {
                if (!this.validateRequired)
                    return true; // Ignore validation
                let fobj = this.getForm();

                // Validate fields
                if (!this.validateFields())
                    return false;

                // Call Form_CustomValidate event
                if (!(await this.customValidate?.(fobj) ?? true)) {
                    this.focus();
                    return false;
                }
                return true;
            }
        )

        // Form_CustomValidate
        .setCustomValidate(
            function (fobj) { // DO NOT CHANGE THIS LINE! (except for adding "async" keyword)!
                    // Your custom validation code here, return false if invalid.
                    return true;
                }
        )

        // Use JavaScript validation or not
        .setValidateRequired(ew.CLIENT_VALIDATE)

        // Dynamic selection lists
        .setLists({
            "TravellingMethodtoschoo": <?= $Page->TravellingMethodtoschoo->toClientList($Page) ?>,
            "Specialneeds": <?= $Page->Specialneeds->toClientList($Page) ?>,
            "Grade": <?= $Page->Grade->toClientList($Page) ?>,
            "prefect": <?= $Page->prefect->toClientList($Page) ?>,
        })
        .build();
    window[form.id] = form;
<?php if ($Page->IsModal) { ?>
    currentAdvancedSearchForm = form;
<?php } else { ?>
    currentForm = form;
<?php } ?>
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<form name="fstudent_detailssearch" id="fstudent_detailssearch" class="<?= $Page->FormClassName ?>" action="<?= CurrentPageUrl(false) ?>" method="post" novalidate autocomplete="on">
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="student_details">
<input type="hidden" name="action" id="action" value="search">
<?php if ($Page->IsModal) { ?>
<input type="hidden" name="modal" value="1">
<?php } ?>
<div class="ew-search-div"><!-- page* -->
<?php if ($Page->AdmissionNo->Visible) { // Admission No ?>
    <div id="r_AdmissionNo" class="row"<?= $Page->AdmissionNo->rowAttributes() ?>>
        <label for="x_AdmissionNo" class="<?= $Page->LeftColumnClass ?>"><span id="elh_student_details_AdmissionNo"><?= $Page->AdmissionNo->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("=") ?>
<input type="hidden" name="z_AdmissionNo" id="z_AdmissionNo" value="=">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->AdmissionNo->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_student_details_AdmissionNo" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->AdmissionNo->getInputTextType() ?>" name="x_AdmissionNo" id="x_AdmissionNo" data-table="student_details" data-field="x_AdmissionNo" value="<?= $Page->AdmissionNo->EditValue ?>" size="30" maxlength="100" placeholder="<?= HtmlEncode($Page->AdmissionNo->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->AdmissionNo->formatPattern()) ?>"<?= $Page->AdmissionNo->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->AdmissionNo->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->FullName->Visible) { // Full Name ?>
    <div id="r_FullName" class="row"<?= $Page->FullName->rowAttributes() ?>>
        <label for="x_FullName" class="<?= $Page->LeftColumnClass ?>"><span id="elh_student_details_FullName"><?= $Page->FullName->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("LIKE") ?>
<input type="hidden" name="z_FullName" id="z_FullName" value="LIKE">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->FullName->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_student_details_FullName" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->FullName->getInputTextType() ?>" name="x_FullName" id="x_FullName" data-table="student_details" data-field="x_FullName" value="<?= $Page->FullName->EditValue ?>" size="35" placeholder="<?= HtmlEncode($Page->FullName->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->FullName->formatPattern()) ?>"<?= $Page->FullName->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->FullName->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->NameWithInitials->Visible) { // Name With Initials ?>
    <div id="r_NameWithInitials" class="row"<?= $Page->NameWithInitials->rowAttributes() ?>>
        <label for="x_NameWithInitials" class="<?= $Page->LeftColumnClass ?>"><span id="elh_student_details_NameWithInitials"><?= $Page->NameWithInitials->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("LIKE") ?>
<input type="hidden" name="z_NameWithInitials" id="z_NameWithInitials" value="LIKE">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->NameWithInitials->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_student_details_NameWithInitials" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->NameWithInitials->getInputTextType() ?>" name="x_NameWithInitials" id="x_NameWithInitials" data-table="student_details" data-field="x_NameWithInitials" value="<?= $Page->NameWithInitials->EditValue ?>" size="35" placeholder="<?= HtmlEncode($Page->NameWithInitials->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->NameWithInitials->formatPattern()) ?>"<?= $Page->NameWithInitials->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->NameWithInitials->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->FathersName->Visible) { // Father's Name ?>
    <div id="r_FathersName" class="row"<?= $Page->FathersName->rowAttributes() ?>>
        <label for="x_FathersName" class="<?= $Page->LeftColumnClass ?>"><span id="elh_student_details_FathersName"><?= $Page->FathersName->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("LIKE") ?>
<input type="hidden" name="z_FathersName" id="z_FathersName" value="LIKE">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->FathersName->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_student_details_FathersName" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->FathersName->getInputTextType() ?>" name="x_FathersName" id="x_FathersName" data-table="student_details" data-field="x_FathersName" value="<?= $Page->FathersName->EditValue ?>" size="35" placeholder="<?= HtmlEncode($Page->FathersName->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->FathersName->formatPattern()) ?>"<?= $Page->FathersName->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->FathersName->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->MothersName->Visible) { // Mother's Name ?>
    <div id="r_MothersName" class="row"<?= $Page->MothersName->rowAttributes() ?>>
        <label for="x_MothersName" class="<?= $Page->LeftColumnClass ?>"><span id="elh_student_details_MothersName"><?= $Page->MothersName->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("LIKE") ?>
<input type="hidden" name="z_MothersName" id="z_MothersName" value="LIKE">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->MothersName->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_student_details_MothersName" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->MothersName->getInputTextType() ?>" name="x_MothersName" id="x_MothersName" data-table="student_details" data-field="x_MothersName" value="<?= $Page->MothersName->EditValue ?>" size="35" placeholder="<?= HtmlEncode($Page->MothersName->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->MothersName->formatPattern()) ?>"<?= $Page->MothersName->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->MothersName->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->Address->Visible) { // Address ?>
    <div id="r_Address" class="row"<?= $Page->Address->rowAttributes() ?>>
        <label for="x_Address" class="<?= $Page->LeftColumnClass ?>"><span id="elh_student_details_Address"><?= $Page->Address->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("LIKE") ?>
<input type="hidden" name="z_Address" id="z_Address" value="LIKE">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->Address->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_student_details_Address" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->Address->getInputTextType() ?>" name="x_Address" id="x_Address" data-table="student_details" data-field="x_Address" value="<?= $Page->Address->EditValue ?>" size="35" placeholder="<?= HtmlEncode($Page->Address->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->Address->formatPattern()) ?>"<?= $Page->Address->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->Address->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->Occupation->Visible) { // Occupation ?>
    <div id="r_Occupation" class="row"<?= $Page->Occupation->rowAttributes() ?>>
        <label for="x_Occupation" class="<?= $Page->LeftColumnClass ?>"><span id="elh_student_details_Occupation"><?= $Page->Occupation->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("LIKE") ?>
<input type="hidden" name="z_Occupation" id="z_Occupation" value="LIKE">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->Occupation->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_student_details_Occupation" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->Occupation->getInputTextType() ?>" name="x_Occupation" id="x_Occupation" data-table="student_details" data-field="x_Occupation" value="<?= $Page->Occupation->EditValue ?>" size="35" placeholder="<?= HtmlEncode($Page->Occupation->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->Occupation->formatPattern()) ?>"<?= $Page->Occupation->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->Occupation->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->TravellingMethodtoschoo->Visible) { // Travelling Method to schoo ?>
    <div id="r_TravellingMethodtoschoo" class="row"<?= $Page->TravellingMethodtoschoo->rowAttributes() ?>>
        <label for="x_TravellingMethodtoschoo" class="<?= $Page->LeftColumnClass ?>"><span id="elh_student_details_TravellingMethodtoschoo"><?= $Page->TravellingMethodtoschoo->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("LIKE") ?>
<input type="hidden" name="z_TravellingMethodtoschoo" id="z_TravellingMethodtoschoo" value="LIKE">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->TravellingMethodtoschoo->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_student_details_TravellingMethodtoschoo" class="ew-search-field ew-search-field-single">
    <select
        id="x_TravellingMethodtoschoo"
        name="x_TravellingMethodtoschoo"
        class="form-select ew-select<?= $Page->TravellingMethodtoschoo->isInvalidClass() ?>"
        data-select2-id="fstudent_detailssearch_x_TravellingMethodtoschoo"
        data-table="student_details"
        data-field="x_TravellingMethodtoschoo"
        data-value-separator="<?= $Page->TravellingMethodtoschoo->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->TravellingMethodtoschoo->getPlaceHolder()) ?>"
        <?= $Page->TravellingMethodtoschoo->editAttributes() ?>>
        <?= $Page->TravellingMethodtoschoo->selectOptionListHtml("x_TravellingMethodtoschoo") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->TravellingMethodtoschoo->getErrorMessage(false) ?></div>
<script>
loadjs.ready("fstudent_detailssearch", function() {
    var options = { name: "x_TravellingMethodtoschoo", selectId: "fstudent_detailssearch_x_TravellingMethodtoschoo" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (fstudent_detailssearch.lists.TravellingMethodtoschoo?.lookupOptions.length) {
        options.data = { id: "x_TravellingMethodtoschoo", form: "fstudent_detailssearch" };
    } else {
        options.ajax = { id: "x_TravellingMethodtoschoo", form: "fstudent_detailssearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.student_details.fields.TravellingMethodtoschoo.selectOptions);
    ew.createSelect(options);
});
</script>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->inEmergencycontactno->Visible) { // in Emergency contact no ?>
    <div id="r_inEmergencycontactno" class="row"<?= $Page->inEmergencycontactno->rowAttributes() ?>>
        <label for="x_inEmergencycontactno" class="<?= $Page->LeftColumnClass ?>"><span id="elh_student_details_inEmergencycontactno"><?= $Page->inEmergencycontactno->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("=") ?>
<input type="hidden" name="z_inEmergencycontactno" id="z_inEmergencycontactno" value="=">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->inEmergencycontactno->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_student_details_inEmergencycontactno" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->inEmergencycontactno->getInputTextType() ?>" name="x_inEmergencycontactno" id="x_inEmergencycontactno" data-table="student_details" data-field="x_inEmergencycontactno" value="<?= $Page->inEmergencycontactno->EditValue ?>" size="30" placeholder="<?= HtmlEncode($Page->inEmergencycontactno->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->inEmergencycontactno->formatPattern()) ?>"<?= $Page->inEmergencycontactno->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->inEmergencycontactno->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->Specialneeds->Visible) { // Special needs ?>
    <div id="r_Specialneeds" class="row"<?= $Page->Specialneeds->rowAttributes() ?>>
        <label class="<?= $Page->LeftColumnClass ?>"><span id="elh_student_details_Specialneeds"><?= $Page->Specialneeds->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("=") ?>
<input type="hidden" name="z_Specialneeds" id="z_Specialneeds" value="=">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->Specialneeds->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_student_details_Specialneeds" class="ew-search-field ew-search-field-single">
<template id="tp_x_Specialneeds">
    <div class="form-check">
        <input type="radio" class="form-check-input" data-table="student_details" data-field="x_Specialneeds" name="x_Specialneeds" id="x_Specialneeds"<?= $Page->Specialneeds->editAttributes() ?>>
        <label class="form-check-label"></label>
    </div>
</template>
<div id="dsl_x_Specialneeds" class="ew-item-list"></div>
<selection-list hidden
    id="x_Specialneeds"
    name="x_Specialneeds"
    value="<?= HtmlEncode($Page->Specialneeds->AdvancedSearch->SearchValue) ?>"
    data-type="select-one"
    data-template="tp_x_Specialneeds"
    data-target="dsl_x_Specialneeds"
    data-repeatcolumn="5"
    class="form-control<?= $Page->Specialneeds->isInvalidClass() ?>"
    data-table="student_details"
    data-field="x_Specialneeds"
    data-value-separator="<?= $Page->Specialneeds->displayValueSeparatorAttribute() ?>"
    <?= $Page->Specialneeds->editAttributes() ?>></selection-list>
<div class="invalid-feedback"><?= $Page->Specialneeds->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->Grade->Visible) { // Grade ?>
    <div id="r_Grade" class="row"<?= $Page->Grade->rowAttributes() ?>>
        <label for="x_Grade" class="<?= $Page->LeftColumnClass ?>"><span id="elh_student_details_Grade"><?= $Page->Grade->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("LIKE") ?>
<input type="hidden" name="z_Grade" id="z_Grade" value="LIKE">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->Grade->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_student_details_Grade" class="ew-search-field ew-search-field-single">
    <select
        id="x_Grade"
        name="x_Grade"
        class="form-select ew-select<?= $Page->Grade->isInvalidClass() ?>"
        data-select2-id="fstudent_detailssearch_x_Grade"
        data-table="student_details"
        data-field="x_Grade"
        data-value-separator="<?= $Page->Grade->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->Grade->getPlaceHolder()) ?>"
        <?= $Page->Grade->editAttributes() ?>>
        <?= $Page->Grade->selectOptionListHtml("x_Grade") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->Grade->getErrorMessage(false) ?></div>
<script>
loadjs.ready("fstudent_detailssearch", function() {
    var options = { name: "x_Grade", selectId: "fstudent_detailssearch_x_Grade" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (fstudent_detailssearch.lists.Grade?.lookupOptions.length) {
        options.data = { id: "x_Grade", form: "fstudent_detailssearch" };
    } else {
        options.ajax = { id: "x_Grade", form: "fstudent_detailssearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.student_details.fields.Grade.selectOptions);
    ew.createSelect(options);
});
</script>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->prefect->Visible) { // prefect ?>
    <div id="r_prefect" class="row"<?= $Page->prefect->rowAttributes() ?>>
        <label class="<?= $Page->LeftColumnClass ?>"><span id="elh_student_details_prefect"><?= $Page->prefect->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("=") ?>
<input type="hidden" name="z_prefect" id="z_prefect" value="=">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->prefect->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_student_details_prefect" class="ew-search-field ew-search-field-single">
<template id="tp_x_prefect">
    <div class="form-check">
        <input type="radio" class="form-check-input" data-table="student_details" data-field="x_prefect" name="x_prefect" id="x_prefect"<?= $Page->prefect->editAttributes() ?>>
        <label class="form-check-label"></label>
    </div>
</template>
<div id="dsl_x_prefect" class="ew-item-list"></div>
<selection-list hidden
    id="x_prefect"
    name="x_prefect"
    value="<?= HtmlEncode($Page->prefect->AdvancedSearch->SearchValue) ?>"
    data-type="select-one"
    data-template="tp_x_prefect"
    data-target="dsl_x_prefect"
    data-repeatcolumn="5"
    class="form-control<?= $Page->prefect->isInvalidClass() ?>"
    data-table="student_details"
    data-field="x_prefect"
    data-value-separator="<?= $Page->prefect->displayValueSeparatorAttribute() ?>"
    <?= $Page->prefect->editAttributes() ?>></selection-list>
<div class="invalid-feedback"><?= $Page->prefect->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
</div><!-- /page* -->
<?= $Page->IsModal ? '<template class="ew-modal-buttons">' : '<div class="row ew-buttons">' ?><!-- buttons .row -->
    <div class="<?= $Page->OffsetColumnClass ?>"><!-- buttons offset -->
        <button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit" form="fstudent_detailssearch"><?= $Language->phrase("Search") ?></button>
        <?php if ($Page->IsModal) { ?>
        <button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" form="fstudent_detailssearch"><?= $Language->phrase("Cancel") ?></button>
        <?php } else { ?>
        <button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" form="fstudent_detailssearch" data-ew-action="reload"><?= $Language->phrase("Reset") ?></button>
        <?php } ?>
    </div><!-- /buttons offset -->
<?= $Page->IsModal ? "</template>" : "</div>" ?><!-- /buttons .row -->
</form>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<script>
// Field event handlers
loadjs.ready("head", function() {
    ew.addEventHandlers("student_details");
});
</script>
<script>
loadjs.ready("load", function () {
    // Write your table-specific startup script here, no need to add script tags.
});
</script>
