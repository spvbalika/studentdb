<?php

namespace PHPMaker2023\vishaka2;

// Menu Language
if ($Language && function_exists(PROJECT_NAMESPACE . "Config") && $Language->LanguageFolder == Config("LANGUAGE_FOLDER")) {
    $MenuRelativePath = "";
    $MenuLanguage = &$Language;
} else { // Compat reports
    $LANGUAGE_FOLDER = "../lang/";
    $MenuRelativePath = "../";
    $MenuLanguage = Container("language");
}

// Navbar menu
$topMenu = new Menu("navbar", true, true);
echo $topMenu->toScript();

// Sidebar menu
$sideMenu = new Menu("menu", true, false);
$sideMenu->addMenuItem(1, "mi_student_details", $MenuLanguage->MenuPhrase("1", "MenuText"), $MenuRelativePath . "StudentDetailsList", -1, "", IsLoggedIn() || AllowListMenu('{B17D5AA5-09A0-41E8-A88F-1DA4272EA098}student details'), false, false, "", "", false, true);
echo $sideMenu->toScript();
