<?php

namespace PHPMaker2023\vishaka2;

use Slim\App;
use Slim\Routing\RouteCollectorProxy;
use Slim\Exception\HttpNotFoundException;

// Handle Routes
return function (App $app) {
    // student_details
    $app->map(["GET","POST","OPTIONS"], '/StudentDetailsList[/{AdmissionNo}]', StudentDetailsController::class . ':list')->add(PermissionMiddleware::class)->setName('StudentDetailsList-student_details-list'); // list
    $app->map(["GET","POST","OPTIONS"], '/StudentDetailsAdd[/{AdmissionNo}]', StudentDetailsController::class . ':add')->add(PermissionMiddleware::class)->setName('StudentDetailsAdd-student_details-add'); // add
    $app->map(["GET","POST","OPTIONS"], '/StudentDetailsView[/{AdmissionNo}]', StudentDetailsController::class . ':view')->add(PermissionMiddleware::class)->setName('StudentDetailsView-student_details-view'); // view
    $app->map(["GET","POST","OPTIONS"], '/StudentDetailsEdit[/{AdmissionNo}]', StudentDetailsController::class . ':edit')->add(PermissionMiddleware::class)->setName('StudentDetailsEdit-student_details-edit'); // edit
    $app->map(["GET","POST","OPTIONS"], '/StudentDetailsUpdate', StudentDetailsController::class . ':update')->add(PermissionMiddleware::class)->setName('StudentDetailsUpdate-student_details-update'); // update
    $app->map(["GET","POST","OPTIONS"], '/StudentDetailsDelete[/{AdmissionNo}]', StudentDetailsController::class . ':delete')->add(PermissionMiddleware::class)->setName('StudentDetailsDelete-student_details-delete'); // delete
    $app->map(["GET","POST","OPTIONS"], '/StudentDetailsSearch', StudentDetailsController::class . ':search')->add(PermissionMiddleware::class)->setName('StudentDetailsSearch-student_details-search'); // search
    $app->group(
        '/student_details',
        function (RouteCollectorProxy $group) {
            $group->map(["GET","POST","OPTIONS"], '/' . Config('LIST_ACTION') . '[/{AdmissionNo}]', StudentDetailsController::class . ':list')->add(PermissionMiddleware::class)->setName('student_details/list-student_details-list-2'); // list
            $group->map(["GET","POST","OPTIONS"], '/' . Config('ADD_ACTION') . '[/{AdmissionNo}]', StudentDetailsController::class . ':add')->add(PermissionMiddleware::class)->setName('student_details/add-student_details-add-2'); // add
            $group->map(["GET","POST","OPTIONS"], '/' . Config('VIEW_ACTION') . '[/{AdmissionNo}]', StudentDetailsController::class . ':view')->add(PermissionMiddleware::class)->setName('student_details/view-student_details-view-2'); // view
            $group->map(["GET","POST","OPTIONS"], '/' . Config('EDIT_ACTION') . '[/{AdmissionNo}]', StudentDetailsController::class . ':edit')->add(PermissionMiddleware::class)->setName('student_details/edit-student_details-edit-2'); // edit
            $group->map(["GET","POST","OPTIONS"], '/' . Config('UPDATE_ACTION') . '', StudentDetailsController::class . ':update')->add(PermissionMiddleware::class)->setName('student_details/update-student_details-update-2'); // update
            $group->map(["GET","POST","OPTIONS"], '/' . Config('DELETE_ACTION') . '[/{AdmissionNo}]', StudentDetailsController::class . ':delete')->add(PermissionMiddleware::class)->setName('student_details/delete-student_details-delete-2'); // delete
            $group->map(["GET","POST","OPTIONS"], '/' . Config('SEARCH_ACTION') . '', StudentDetailsController::class . ':search')->add(PermissionMiddleware::class)->setName('student_details/search-student_details-search-2'); // search
        }
    );

    // login
    $app->map(["GET","POST","OPTIONS"], '/login[/{provider}]', OthersController::class . ':login')->add(PermissionMiddleware::class)->setName('login');

    // logout
    $app->map(["GET","POST","OPTIONS"], '/logout', OthersController::class . ':logout')->add(PermissionMiddleware::class)->setName('logout');

    // Swagger
    $app->get('/' . Config("SWAGGER_ACTION"), OthersController::class . ':swagger')->setName(Config("SWAGGER_ACTION")); // Swagger

    // Index
    $app->get('/[index]', OthersController::class . ':index')->add(PermissionMiddleware::class)->setName('index');

    // Route Action event
    if (function_exists(PROJECT_NAMESPACE . "Route_Action")) {
        if (Route_Action($app) === false) {
            return;
        }
    }

    /**
     * Catch-all route to serve a 404 Not Found page if none of the routes match
     * NOTE: Make sure this route is defined last.
     */
    $app->map(
        ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
        '/{routes:.+}',
        function ($request, $response, $params) {
            throw new HttpNotFoundException($request, str_replace("%p", $params["routes"], Container("language")->phrase("PageNotFound")));
        }
    );
};
