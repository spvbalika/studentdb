<?php
/**
 * PHPMaker 2023 user level settings
 */
namespace PHPMaker2023\vishaka2;

// User level info
$USER_LEVELS = [["-2","Anonymous"]];
// User level priv info
$USER_LEVEL_PRIVS = [["{B17D5AA5-09A0-41E8-A88F-1DA4272EA098}student details","-2","0"]];
// User level table info
$USER_LEVEL_TABLES = [["student details","student_details","student details",true,"{B17D5AA5-09A0-41E8-A88F-1DA4272EA098}","StudentDetailsList"]];
