<?php

namespace PHPMaker2023\vishaka2;

use Doctrine\DBAL\ParameterType;
use Doctrine\DBAL\FetchMode;
use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Query\QueryBuilder;

/**
 * Page class
 */
class StudentDetailsSearch extends StudentDetails
{
    use MessagesTrait;

    // Page ID
    public $PageID = "search";

    // Project ID
    public $ProjectID = PROJECT_ID;

    // Page object name
    public $PageObjName = "StudentDetailsSearch";

    // View file path
    public $View = null;

    // Title
    public $Title = null; // Title for <title> tag

    // Rendering View
    public $RenderingView = false;

    // CSS class/style
    public $CurrentPageName = "StudentDetailsSearch";

    // Page headings
    public $Heading = "";
    public $Subheading = "";
    public $PageHeader;
    public $PageFooter;

    // Page layout
    public $UseLayout = true;

    // Page terminated
    private $terminated = false;

    // Page heading
    public function pageHeading()
    {
        global $Language;
        if ($this->Heading != "") {
            return $this->Heading;
        }
        if (method_exists($this, "tableCaption")) {
            return $this->tableCaption();
        }
        return "";
    }

    // Page subheading
    public function pageSubheading()
    {
        global $Language;
        if ($this->Subheading != "") {
            return $this->Subheading;
        }
        if ($this->TableName) {
            return $Language->phrase($this->PageID);
        }
        return "";
    }

    // Page name
    public function pageName()
    {
        return CurrentPageName();
    }

    // Page URL
    public function pageUrl($withArgs = true)
    {
        $route = GetRoute();
        $args = RemoveXss($route->getArguments());
        if (!$withArgs) {
            foreach ($args as $key => &$val) {
                $val = "";
            }
            unset($val);
        }
        return rtrim(UrlFor($route->getName(), $args), "/") . "?";
    }

    // Show Page Header
    public function showPageHeader()
    {
        $header = $this->PageHeader;
        $this->pageDataRendering($header);
        if ($header != "") { // Header exists, display
            echo '<p id="ew-page-header">' . $header . '</p>';
        }
    }

    // Show Page Footer
    public function showPageFooter()
    {
        $footer = $this->PageFooter;
        $this->pageDataRendered($footer);
        if ($footer != "") { // Footer exists, display
            echo '<p id="ew-page-footer">' . $footer . '</p>';
        }
    }

    // Constructor
    public function __construct()
    {
        parent::__construct();
        global $Language, $DashboardReport, $DebugTimer;
        $this->TableVar = 'student_details';
        $this->TableName = 'student details';

        // Table CSS class
        $this->TableClass = "table table-striped table-bordered table-hover table-sm ew-desktop-table ew-search-table";

        // Initialize
        $GLOBALS["Page"] = &$this;

        // Language object
        $Language = Container("language");

        // Table object (student_details)
        if (!isset($GLOBALS["student_details"]) || get_class($GLOBALS["student_details"]) == PROJECT_NAMESPACE . "student_details") {
            $GLOBALS["student_details"] = &$this;
        }

        // Table name (for backward compatibility only)
        if (!defined(PROJECT_NAMESPACE . "TABLE_NAME")) {
            define(PROJECT_NAMESPACE . "TABLE_NAME", 'student details');
        }

        // Start timer
        $DebugTimer = Container("timer");

        // Debug message
        LoadDebugMessage();

        // Open connection
        $GLOBALS["Conn"] ??= $this->getConnection();
    }

    // Get content from stream
    public function getContents(): string
    {
        global $Response;
        return is_object($Response) ? $Response->getBody() : ob_get_clean();
    }

    // Is lookup
    public function isLookup()
    {
        return SameText(Route(0), Config("API_LOOKUP_ACTION"));
    }

    // Is AutoFill
    public function isAutoFill()
    {
        return $this->isLookup() && SameText(Post("ajax"), "autofill");
    }

    // Is AutoSuggest
    public function isAutoSuggest()
    {
        return $this->isLookup() && SameText(Post("ajax"), "autosuggest");
    }

    // Is modal lookup
    public function isModalLookup()
    {
        return $this->isLookup() && SameText(Post("ajax"), "modal");
    }

    // Is terminated
    public function isTerminated()
    {
        return $this->terminated;
    }

    /**
     * Terminate page
     *
     * @param string $url URL for direction
     * @return void
     */
    public function terminate($url = "")
    {
        if ($this->terminated) {
            return;
        }
        global $TempImages, $DashboardReport, $Response;

        // Page is terminated
        $this->terminated = true;

         // Page Unload event
        if (method_exists($this, "pageUnload")) {
            $this->pageUnload();
        }

        // Global Page Unloaded event (in userfn*.php)
        Page_Unloaded();
        if (!IsApi() && method_exists($this, "pageRedirecting")) {
            $this->pageRedirecting($url);
        }

        // Close connection
        CloseConnections();

        // Return for API
        if (IsApi()) {
            $res = $url === true;
            if (!$res) { // Show response for API
                $ar = array_merge($this->getMessages(), $url ? ["url" => GetUrl($url)] : []);
                WriteJson($ar);
            }
            $this->clearMessages(); // Clear messages for API request
            return;
        } else { // Check if response is JSON
            if (StartsString("application/json", $Response->getHeaderLine("Content-type")) && $Response->getBody()->getSize()) { // With JSON response
                $this->clearMessages();
                return;
            }
        }

        // Go to URL if specified
        if ($url != "") {
            if (!Config("DEBUG") && ob_get_length()) {
                ob_end_clean();
            }

            // Handle modal response
            if ($this->IsModal) { // Show as modal
                $result = ["url" => GetUrl($url), "modal" => "1"];
                $pageName = GetPageName($url);
                if ($pageName != $this->getListUrl()) { // Not List page => View page
                    $result["caption"] = $this->getModalCaption($pageName);
                    $result["view"] = $pageName == "StudentDetailsView";
                } else { // List page
                    // $result["list"] = $this->PageID == "search"; // Refresh List page if current page is Search page
                    $result["error"] = $this->getFailureMessage(); // List page should not be shown as modal => error
                    $this->clearFailureMessage();
                }
                WriteJson($result);
            } else {
                SaveDebugMessage();
                Redirect(GetUrl($url));
            }
        }
        return; // Return to controller
    }

    // Get records from recordset
    protected function getRecordsFromRecordset($rs, $current = false)
    {
        $rows = [];
        if (is_object($rs)) { // Recordset
            while ($rs && !$rs->EOF) {
                $this->loadRowValues($rs); // Set up DbValue/CurrentValue
                $row = $this->getRecordFromArray($rs->fields);
                if ($current) {
                    return $row;
                } else {
                    $rows[] = $row;
                }
                $rs->moveNext();
            }
        } elseif (is_array($rs)) {
            foreach ($rs as $ar) {
                $row = $this->getRecordFromArray($ar);
                if ($current) {
                    return $row;
                } else {
                    $rows[] = $row;
                }
            }
        }
        return $rows;
    }

    // Get record from array
    protected function getRecordFromArray($ar)
    {
        $row = [];
        if (is_array($ar)) {
            foreach ($ar as $fldname => $val) {
                if (array_key_exists($fldname, $this->Fields) && ($this->Fields[$fldname]->Visible || $this->Fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
                    $fld = &$this->Fields[$fldname];
                    if ($fld->HtmlTag == "FILE") { // Upload field
                        if (EmptyValue($val)) {
                            $row[$fldname] = null;
                        } else {
                            if ($fld->DataType == DATATYPE_BLOB) {
                                $url = FullUrl(GetApiUrl(Config("API_FILE_ACTION") .
                                    "/" . $fld->TableVar . "/" . $fld->Param . "/" . rawurlencode($this->getRecordKeyValue($ar))));
                                $row[$fldname] = ["type" => ContentType($val), "url" => $url, "name" => $fld->Param . ContentExtension($val)];
                            } elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
                                $url = FullUrl(GetApiUrl(Config("API_FILE_ACTION") .
                                    "/" . $fld->TableVar . "/" . Encrypt($fld->physicalUploadPath() . $val)));
                                $row[$fldname] = ["type" => MimeContentType($val), "url" => $url, "name" => $val];
                            } else { // Multiple files
                                $files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
                                $ar = [];
                                foreach ($files as $file) {
                                    $url = FullUrl(GetApiUrl(Config("API_FILE_ACTION") .
                                        "/" . $fld->TableVar . "/" . Encrypt($fld->physicalUploadPath() . $file)));
                                    if (!EmptyValue($file)) {
                                        $ar[] = ["type" => MimeContentType($file), "url" => $url, "name" => $file];
                                    }
                                }
                                $row[$fldname] = $ar;
                            }
                        }
                    } else {
                        $row[$fldname] = $val;
                    }
                }
            }
        }
        return $row;
    }

    // Get record key value from array
    protected function getRecordKeyValue($ar)
    {
        $key = "";
        if (is_array($ar)) {
            $key .= @$ar['Admission No'];
        }
        return $key;
    }

    /**
     * Hide fields for add/edit
     *
     * @return void
     */
    protected function hideFieldsForAddEdit()
    {
    }

    // Lookup data
    public function lookup($ar = null)
    {
        global $Language, $Security;

        // Get lookup object
        $fieldName = $ar["field"] ?? Post("field");
        $lookup = $this->Fields[$fieldName]->Lookup;
        $name = $ar["name"] ?? Post("name");
        $isQuery = ContainsString($name, "query_builder_rule");
        if ($isQuery) {
            $lookup->FilterFields = []; // Skip parent fields if any
        }

        // Get lookup parameters
        $lookupType = $ar["ajax"] ?? Post("ajax", "unknown");
        $pageSize = -1;
        $offset = -1;
        $searchValue = "";
        if (SameText($lookupType, "modal") || SameText($lookupType, "filter")) {
            $searchValue = $ar["q"] ?? Param("q") ?? $ar["sv"] ?? Post("sv", "");
            $pageSize = $ar["n"] ?? Param("n") ?? $ar["recperpage"] ?? Post("recperpage", 10);
        } elseif (SameText($lookupType, "autosuggest")) {
            $searchValue = $ar["q"] ?? Param("q", "");
            $pageSize = $ar["n"] ?? Param("n", -1);
            $pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
            if ($pageSize <= 0) {
                $pageSize = Config("AUTO_SUGGEST_MAX_ENTRIES");
            }
        }
        $start = $ar["start"] ?? Param("start", -1);
        $start = is_numeric($start) ? (int)$start : -1;
        $page = $ar["page"] ?? Param("page", -1);
        $page = is_numeric($page) ? (int)$page : -1;
        $offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
        $userSelect = Decrypt($ar["s"] ?? Post("s", ""));
        $userFilter = Decrypt($ar["f"] ?? Post("f", ""));
        $userOrderBy = Decrypt($ar["o"] ?? Post("o", ""));
        $keys = $ar["keys"] ?? Post("keys");
        $lookup->LookupType = $lookupType; // Lookup type
        $lookup->FilterValues = []; // Clear filter values first
        if ($keys !== null) { // Selected records from modal
            if (is_array($keys)) {
                $keys = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $keys);
            }
            $lookup->FilterFields = []; // Skip parent fields if any
            $lookup->FilterValues[] = $keys; // Lookup values
            $pageSize = -1; // Show all records
        } else { // Lookup values
            $lookup->FilterValues[] = $ar["v0"] ?? $ar["lookupValue"] ?? Post("v0", Post("lookupValue", ""));
        }
        $cnt = is_array($lookup->FilterFields) ? count($lookup->FilterFields) : 0;
        for ($i = 1; $i <= $cnt; $i++) {
            $lookup->FilterValues[] = $ar["v" . $i] ?? Post("v" . $i, "");
        }
        $lookup->SearchValue = $searchValue;
        $lookup->PageSize = $pageSize;
        $lookup->Offset = $offset;
        if ($userSelect != "") {
            $lookup->UserSelect = $userSelect;
        }
        if ($userFilter != "") {
            $lookup->UserFilter = $userFilter;
        }
        if ($userOrderBy != "") {
            $lookup->UserOrderBy = $userOrderBy;
        }
        return $lookup->toJson($this, !is_array($ar)); // Use settings from current page
    }
    public $FormClassName = "ew-form ew-search-form";
    public $IsModal = false;
    public $IsMobileOrModal = false;

    /**
     * Page run
     *
     * @return void
     */
    public function run()
    {
        global $ExportType, $UserProfile, $Language, $Security, $CurrentForm, $SkipHeaderFooter;

        // Is modal
        $this->IsModal = ConvertToBool(Param("modal"));
        $this->UseLayout = $this->UseLayout && !$this->IsModal;

        // Use layout
        $this->UseLayout = $this->UseLayout && ConvertToBool(Param(Config("PAGE_LAYOUT"), true));

        // View
        $this->View = Get(Config("VIEW"));

        // Create form object
        $CurrentForm = new HttpForm();
        $this->CurrentAction = Param("action"); // Set up current action
        $this->AdmissionNo->setVisibility();
        $this->FullName->setVisibility();
        $this->NameWithInitials->setVisibility();
        $this->FathersName->setVisibility();
        $this->MothersName->setVisibility();
        $this->Address->setVisibility();
        $this->Occupation->setVisibility();
        $this->TravellingMethodtoschoo->setVisibility();
        $this->inEmergencycontactno->setVisibility();
        $this->Specialneeds->setVisibility();
        $this->Grade->setVisibility();
        $this->prefect->setVisibility();

        // Set lookup cache
        if (!in_array($this->PageID, Config("LOOKUP_CACHE_PAGE_IDS"))) {
            $this->setUseLookupCache(false);
        }

        // Global Page Loading event (in userfn*.php)
        Page_Loading();

        // Page Load event
        if (method_exists($this, "pageLoad")) {
            $this->pageLoad();
        }

        // Hide fields for add/edit
        if (!$this->UseAjaxActions) {
            $this->hideFieldsForAddEdit();
        }
        // Use inline delete
        if ($this->UseAjaxActions) {
            $this->InlineDelete = true;
        }

        // Set up lookup cache
        $this->setupLookupOptions($this->TravellingMethodtoschoo);
        $this->setupLookupOptions($this->Specialneeds);
        $this->setupLookupOptions($this->Grade);
        $this->setupLookupOptions($this->prefect);

        // Set up Breadcrumb
        $this->setupBreadcrumb();

        // Check modal
        if ($this->IsModal) {
            $SkipHeaderFooter = true;
        }
        $this->IsMobileOrModal = IsMobile() || $this->IsModal;

        // Get action
        $this->CurrentAction = Post("action");
        if ($this->isSearch()) {
            // Build search string for advanced search, remove blank field
            $this->loadSearchValues(); // Get search values
            $srchStr = $this->validateSearch() ? $this->buildAdvancedSearch() : "";
            if ($srchStr != "") {
                $srchStr = "StudentDetailsList" . "?" . $srchStr;
                // Do not return Json for UseAjaxActions
                if ($this->IsModal && $this->UseAjaxActions) {
                    $this->IsModal = false;
                }
                $this->terminate($srchStr); // Go to list page
                return;
            }
        }

        // Restore search settings from Session
        if (!$this->hasInvalidFields()) {
            $this->loadAdvancedSearch();
        }

        // Render row for search
        $this->RowType = ROWTYPE_SEARCH;
        $this->resetAttributes();
        $this->renderRow();

        // Set LoginStatus / Page_Rendering / Page_Render
        if (!IsApi() && !$this->isTerminated()) {
            // Setup login status
            SetupLoginStatus();

            // Pass login status to client side
            SetClientVar("login", LoginStatus());

            // Global Page Rendering event (in userfn*.php)
            Page_Rendering();

            // Page Render event
            if (method_exists($this, "pageRender")) {
                $this->pageRender();
            }

            // Render search option
            if (method_exists($this, "renderSearchOptions")) {
                $this->renderSearchOptions();
            }
        }
    }

    // Build advanced search
    protected function buildAdvancedSearch()
    {
        $srchUrl = "";
        $this->buildSearchUrl($srchUrl, $this->AdmissionNo); // Admission No
        $this->buildSearchUrl($srchUrl, $this->FullName); // Full Name
        $this->buildSearchUrl($srchUrl, $this->NameWithInitials); // Name With Initials
        $this->buildSearchUrl($srchUrl, $this->FathersName); // Father's Name
        $this->buildSearchUrl($srchUrl, $this->MothersName); // Mother's Name
        $this->buildSearchUrl($srchUrl, $this->Address); // Address
        $this->buildSearchUrl($srchUrl, $this->Occupation); // Occupation
        $this->buildSearchUrl($srchUrl, $this->TravellingMethodtoschoo); // Travelling Method to schoo
        $this->buildSearchUrl($srchUrl, $this->inEmergencycontactno); // in Emergency contact no
        $this->buildSearchUrl($srchUrl, $this->Specialneeds); // Special needs
        $this->buildSearchUrl($srchUrl, $this->Grade); // Grade
        $this->buildSearchUrl($srchUrl, $this->prefect); // prefect
        if ($srchUrl != "") {
            $srchUrl .= "&";
        }
        $srchUrl .= "cmd=search";
        return $srchUrl;
    }

    // Build search URL
    protected function buildSearchUrl(&$url, $fld, $oprOnly = false)
    {
        global $CurrentForm;
        $wrk = "";
        $fldParm = $fld->Param;
        [
            "value" => $fldVal,
            "operator" => $fldOpr,
            "condition" => $fldCond,
            "value2" => $fldVal2,
            "operator2" => $fldOpr2
        ] = $CurrentForm->getSearchValues($fldParm);
        if (is_array($fldVal)) {
            $fldVal = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $fldVal);
        }
        if (is_array($fldVal2)) {
            $fldVal2 = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $fldVal2);
        }
        $fldDataType = $fld->DataType;
        $value = ConvertSearchValue($fldVal, $fldOpr, $fld); // For testing if numeric only
        $value2 = ConvertSearchValue($fldVal2, $fldOpr2, $fld); // For testing if numeric only
        $fldOpr = ConvertSearchOperator($fldOpr, $fld, $value);
        $fldOpr2 = ConvertSearchOperator($fldOpr2, $fld, $value2);
        if (in_array($fldOpr, ["BETWEEN", "NOT BETWEEN"])) {
            $isValidValue = $fldDataType != DATATYPE_NUMBER || $fld->VirtualSearch || IsNumericSearchValue($value, $fldOpr, $fld) && IsNumericSearchValue($value2, $fldOpr2, $fld);
            if ($fldVal != "" && $fldVal2 != "" && $isValidValue) {
                $wrk = "x_" . $fldParm . "=" . urlencode($fldVal) . "&y_" . $fldParm . "=" . urlencode($fldVal2) . "&z_" . $fldParm . "=" . urlencode($fldOpr);
            }
        } else {
            $isValidValue = $fldDataType != DATATYPE_NUMBER || $fld->VirtualSearch || IsNumericSearchValue($value, $fldOpr, $fld);
            if ($fldVal != "" && $isValidValue && IsValidOperator($fldOpr)) {
                $wrk = "x_" . $fldParm . "=" . urlencode($fldVal) . "&z_" . $fldParm . "=" . urlencode($fldOpr);
            } elseif (in_array($fldOpr, ["IS NULL", "IS NOT NULL", "IS EMPTY", "IS NOT EMPTY"]) || ($fldOpr != "" && $oprOnly && IsValidOperator($fldOpr))) {
                $wrk = "z_" . $fldParm . "=" . urlencode($fldOpr);
            }
            $isValidValue = $fldDataType != DATATYPE_NUMBER || $fld->VirtualSearch || IsNumericSearchValue($value2, $fldOpr2, $fld);
            if ($fldVal2 != "" && $isValidValue && IsValidOperator($fldOpr2)) {
                if ($wrk != "") {
                    $wrk .= "&v_" . $fldParm . "=" . urlencode($fldCond) . "&";
                }
                $wrk .= "y_" . $fldParm . "=" . urlencode($fldVal2) . "&w_" . $fldParm . "=" . urlencode($fldOpr2);
            } elseif (in_array($fldOpr2, ["IS NULL", "IS NOT NULL", "IS EMPTY", "IS NOT EMPTY"]) || ($fldOpr2 != "" && $oprOnly && IsValidOperator($fldOpr2))) {
                if ($wrk != "") {
                    $wrk .= "&v_" . $fldParm . "=" . urlencode($fldCond) . "&";
                }
                $wrk .= "w_" . $fldParm . "=" . urlencode($fldOpr2);
            }
        }
        if ($wrk != "") {
            if ($url != "") {
                $url .= "&";
            }
            $url .= $wrk;
        }
    }

    // Load search values for validation
    protected function loadSearchValues()
    {
        // Load search values
        $hasValue = false;

        // Admission No
        if ($this->AdmissionNo->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // Full Name
        if ($this->FullName->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // Name With Initials
        if ($this->NameWithInitials->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // Father's Name
        if ($this->FathersName->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // Mother's Name
        if ($this->MothersName->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // Address
        if ($this->Address->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // Occupation
        if ($this->Occupation->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // Travelling Method to schoo
        if ($this->TravellingMethodtoschoo->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // in Emergency contact no
        if ($this->inEmergencycontactno->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // Special needs
        if ($this->Specialneeds->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // Grade
        if ($this->Grade->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // prefect
        if ($this->prefect->AdvancedSearch->get()) {
            $hasValue = true;
        }
        return $hasValue;
    }

    // Render row values based on field settings
    public function renderRow()
    {
        global $Security, $Language, $CurrentLanguage;

        // Initialize URLs

        // Call Row_Rendering event
        $this->rowRendering();

        // Common render codes for all row types

        // Admission No
        $this->AdmissionNo->RowCssClass = "row";

        // Full Name
        $this->FullName->RowCssClass = "row";

        // Name With Initials
        $this->NameWithInitials->RowCssClass = "row";

        // Father's Name
        $this->FathersName->RowCssClass = "row";

        // Mother's Name
        $this->MothersName->RowCssClass = "row";

        // Address
        $this->Address->RowCssClass = "row";

        // Occupation
        $this->Occupation->RowCssClass = "row";

        // Travelling Method to schoo
        $this->TravellingMethodtoschoo->RowCssClass = "row";

        // in Emergency contact no
        $this->inEmergencycontactno->RowCssClass = "row";

        // Special needs
        $this->Specialneeds->RowCssClass = "row";

        // Grade
        $this->Grade->RowCssClass = "row";

        // prefect
        $this->prefect->RowCssClass = "row";

        // View row
        if ($this->RowType == ROWTYPE_VIEW) {
            // Admission No
            $this->AdmissionNo->ViewValue = $this->AdmissionNo->CurrentValue;
            $this->AdmissionNo->ViewValue = FormatNumber($this->AdmissionNo->ViewValue, $this->AdmissionNo->formatPattern());

            // Full Name
            $this->FullName->ViewValue = $this->FullName->CurrentValue;

            // Name With Initials
            $this->NameWithInitials->ViewValue = $this->NameWithInitials->CurrentValue;

            // Father's Name
            $this->FathersName->ViewValue = $this->FathersName->CurrentValue;

            // Mother's Name
            $this->MothersName->ViewValue = $this->MothersName->CurrentValue;

            // Address
            $this->Address->ViewValue = $this->Address->CurrentValue;

            // Occupation
            $this->Occupation->ViewValue = $this->Occupation->CurrentValue;

            // Travelling Method to schoo
            if (strval($this->TravellingMethodtoschoo->CurrentValue) != "") {
                $this->TravellingMethodtoschoo->ViewValue = $this->TravellingMethodtoschoo->optionCaption($this->TravellingMethodtoschoo->CurrentValue);
            } else {
                $this->TravellingMethodtoschoo->ViewValue = null;
            }

            // in Emergency contact no
            $this->inEmergencycontactno->ViewValue = $this->inEmergencycontactno->CurrentValue;
            $this->inEmergencycontactno->ViewValue = FormatNumber($this->inEmergencycontactno->ViewValue, $this->inEmergencycontactno->formatPattern());

            // Special needs
            if (ConvertToBool($this->Specialneeds->CurrentValue)) {
                $this->Specialneeds->ViewValue = $this->Specialneeds->tagCaption(1) != "" ? $this->Specialneeds->tagCaption(1) : "Yes";
            } else {
                $this->Specialneeds->ViewValue = $this->Specialneeds->tagCaption(2) != "" ? $this->Specialneeds->tagCaption(2) : "No";
            }

            // Grade
            if (strval($this->Grade->CurrentValue) != "") {
                $this->Grade->ViewValue = $this->Grade->optionCaption($this->Grade->CurrentValue);
            } else {
                $this->Grade->ViewValue = null;
            }

            // prefect
            if (ConvertToBool($this->prefect->CurrentValue)) {
                $this->prefect->ViewValue = $this->prefect->tagCaption(1) != "" ? $this->prefect->tagCaption(1) : "Y";
            } else {
                $this->prefect->ViewValue = $this->prefect->tagCaption(2) != "" ? $this->prefect->tagCaption(2) : "N";
            }

            // Admission No
            $this->AdmissionNo->HrefValue = "";
            $this->AdmissionNo->TooltipValue = "";

            // Full Name
            $this->FullName->HrefValue = "";
            $this->FullName->TooltipValue = "";

            // Name With Initials
            $this->NameWithInitials->HrefValue = "";
            $this->NameWithInitials->TooltipValue = "";

            // Father's Name
            $this->FathersName->HrefValue = "";
            $this->FathersName->TooltipValue = "";

            // Mother's Name
            $this->MothersName->HrefValue = "";
            $this->MothersName->TooltipValue = "";

            // Address
            $this->Address->HrefValue = "";
            $this->Address->TooltipValue = "";

            // Occupation
            $this->Occupation->HrefValue = "";
            $this->Occupation->TooltipValue = "";

            // Travelling Method to schoo
            $this->TravellingMethodtoschoo->HrefValue = "";
            $this->TravellingMethodtoschoo->TooltipValue = "";

            // in Emergency contact no
            $this->inEmergencycontactno->HrefValue = "";
            $this->inEmergencycontactno->TooltipValue = "";

            // Special needs
            $this->Specialneeds->HrefValue = "";
            $this->Specialneeds->TooltipValue = "";

            // Grade
            $this->Grade->HrefValue = "";
            $this->Grade->TooltipValue = "";

            // prefect
            $this->prefect->HrefValue = "";
            $this->prefect->TooltipValue = "";
        } elseif ($this->RowType == ROWTYPE_SEARCH) {
            // Admission No
            $this->AdmissionNo->setupEditAttributes();
            $this->AdmissionNo->EditValue = HtmlEncode($this->AdmissionNo->AdvancedSearch->SearchValue);
            $this->AdmissionNo->PlaceHolder = RemoveHtml($this->AdmissionNo->caption());

            // Full Name
            $this->FullName->setupEditAttributes();
            $this->FullName->EditValue = HtmlEncode($this->FullName->AdvancedSearch->SearchValue);
            $this->FullName->PlaceHolder = RemoveHtml($this->FullName->caption());

            // Name With Initials
            $this->NameWithInitials->setupEditAttributes();
            $this->NameWithInitials->EditValue = HtmlEncode($this->NameWithInitials->AdvancedSearch->SearchValue);
            $this->NameWithInitials->PlaceHolder = RemoveHtml($this->NameWithInitials->caption());

            // Father's Name
            $this->FathersName->setupEditAttributes();
            $this->FathersName->EditValue = HtmlEncode($this->FathersName->AdvancedSearch->SearchValue);
            $this->FathersName->PlaceHolder = RemoveHtml($this->FathersName->caption());

            // Mother's Name
            $this->MothersName->setupEditAttributes();
            $this->MothersName->EditValue = HtmlEncode($this->MothersName->AdvancedSearch->SearchValue);
            $this->MothersName->PlaceHolder = RemoveHtml($this->MothersName->caption());

            // Address
            $this->Address->setupEditAttributes();
            $this->Address->EditValue = HtmlEncode($this->Address->AdvancedSearch->SearchValue);
            $this->Address->PlaceHolder = RemoveHtml($this->Address->caption());

            // Occupation
            $this->Occupation->setupEditAttributes();
            $this->Occupation->EditValue = HtmlEncode($this->Occupation->AdvancedSearch->SearchValue);
            $this->Occupation->PlaceHolder = RemoveHtml($this->Occupation->caption());

            // Travelling Method to schoo
            $this->TravellingMethodtoschoo->setupEditAttributes();
            $this->TravellingMethodtoschoo->EditValue = $this->TravellingMethodtoschoo->options(true);
            $this->TravellingMethodtoschoo->PlaceHolder = RemoveHtml($this->TravellingMethodtoschoo->caption());

            // in Emergency contact no
            $this->inEmergencycontactno->setupEditAttributes();
            $this->inEmergencycontactno->EditValue = HtmlEncode($this->inEmergencycontactno->AdvancedSearch->SearchValue);
            $this->inEmergencycontactno->PlaceHolder = RemoveHtml($this->inEmergencycontactno->caption());

            // Special needs
            $this->Specialneeds->EditValue = $this->Specialneeds->options(false);
            $this->Specialneeds->PlaceHolder = RemoveHtml($this->Specialneeds->caption());

            // Grade
            $this->Grade->setupEditAttributes();
            $this->Grade->EditValue = $this->Grade->options(true);
            $this->Grade->PlaceHolder = RemoveHtml($this->Grade->caption());

            // prefect
            $this->prefect->EditValue = $this->prefect->options(false);
            $this->prefect->PlaceHolder = RemoveHtml($this->prefect->caption());
        }
        if ($this->RowType == ROWTYPE_ADD || $this->RowType == ROWTYPE_EDIT || $this->RowType == ROWTYPE_SEARCH) { // Add/Edit/Search row
            $this->setupFieldTitles();
        }

        // Call Row Rendered event
        if ($this->RowType != ROWTYPE_AGGREGATEINIT) {
            $this->rowRendered();
        }
    }

    // Validate search
    protected function validateSearch()
    {
        // Check if validation required
        if (!Config("SERVER_VALIDATE")) {
            return true;
        }
        if (!CheckInteger($this->AdmissionNo->AdvancedSearch->SearchValue)) {
            $this->AdmissionNo->addErrorMessage($this->AdmissionNo->getErrorMessage(false));
        }
        if (!CheckInteger($this->inEmergencycontactno->AdvancedSearch->SearchValue)) {
            $this->inEmergencycontactno->addErrorMessage($this->inEmergencycontactno->getErrorMessage(false));
        }

        // Return validate result
        $validateSearch = !$this->hasInvalidFields();

        // Call Form_CustomValidate event
        $formCustomError = "";
        $validateSearch = $validateSearch && $this->formCustomValidate($formCustomError);
        if ($formCustomError != "") {
            $this->setFailureMessage($formCustomError);
        }
        return $validateSearch;
    }

    // Load advanced search
    public function loadAdvancedSearch()
    {
        $this->AdmissionNo->AdvancedSearch->load();
        $this->FullName->AdvancedSearch->load();
        $this->NameWithInitials->AdvancedSearch->load();
        $this->FathersName->AdvancedSearch->load();
        $this->MothersName->AdvancedSearch->load();
        $this->Address->AdvancedSearch->load();
        $this->Occupation->AdvancedSearch->load();
        $this->TravellingMethodtoschoo->AdvancedSearch->load();
        $this->inEmergencycontactno->AdvancedSearch->load();
        $this->Specialneeds->AdvancedSearch->load();
        $this->Grade->AdvancedSearch->load();
        $this->prefect->AdvancedSearch->load();
    }

    // Set up Breadcrumb
    protected function setupBreadcrumb()
    {
        global $Breadcrumb, $Language;
        $Breadcrumb = new Breadcrumb("index");
        $url = CurrentUrl();
        $Breadcrumb->add("list", $this->TableVar, $this->addMasterUrl("StudentDetailsList"), "", $this->TableVar, true);
        $pageId = "search";
        $Breadcrumb->add("search", $pageId, $url);
    }

    // Setup lookup options
    public function setupLookupOptions($fld)
    {
        if ($fld->Lookup !== null && $fld->Lookup->Options === null) {
            // Get default connection and filter
            $conn = $this->getConnection();
            $lookupFilter = "";

            // No need to check any more
            $fld->Lookup->Options = [];

            // Set up lookup SQL and connection
            switch ($fld->FieldVar) {
                case "x_TravellingMethodtoschoo":
                    break;
                case "x_Specialneeds":
                    break;
                case "x_Grade":
                    break;
                case "x_prefect":
                    break;
                default:
                    $lookupFilter = "";
                    break;
            }

            // Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
            $sql = $fld->Lookup->getSql(false, "", $lookupFilter, $this);

            // Set up lookup cache
            if (!$fld->hasLookupOptions() && $fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0) {
                $totalCnt = $this->getRecordCount($sql, $conn);
                if ($totalCnt > $fld->LookupCacheCount) { // Total count > cache count, do not cache
                    return;
                }
                $rows = $conn->executeQuery($sql)->fetchAll();
                $ar = [];
                foreach ($rows as $row) {
                    $row = $fld->Lookup->renderViewRow($row, Container($fld->Lookup->LinkTable));
                    $key = $row["lf"];
                    if (IsFloatType($fld->Type)) { // Handle float field
                        $key = (float)$key;
                    }
                    $ar[strval($key)] = $row;
                }
                $fld->Lookup->Options = $ar;
            }
        }
    }

    // Page Load event
    public function pageLoad()
    {
        //Log("Page Load");
    }

    // Page Unload event
    public function pageUnload()
    {
        //Log("Page Unload");
    }

    // Page Redirecting event
    public function pageRedirecting(&$url)
    {
        // Example:
        //$url = "your URL";
    }

    // Message Showing event
    // $type = ''|'success'|'failure'|'warning'
    public function messageShowing(&$msg, $type)
    {
        if ($type == 'success') {
            //$msg = "your success message";
        } elseif ($type == 'failure') {
            //$msg = "your failure message";
        } elseif ($type == 'warning') {
            //$msg = "your warning message";
        } else {
            //$msg = "your message";
        }
    }

    // Page Render event
    public function pageRender()
    {
        //Log("Page Render");
    }

    // Page Data Rendering event
    public function pageDataRendering(&$header)
    {
        // Example:
        //$header = "your header";
    }

    // Page Data Rendered event
    public function pageDataRendered(&$footer)
    {
        // Example:
        //$footer = "your footer";
    }

    // Page Breaking event
    public function pageBreaking(&$break, &$content)
    {
        // Example:
        //$break = false; // Skip page break, or
        //$content = "<div style=\"break-after:page;\"></div>"; // Modify page break content
    }

    // Form Custom Validate event
    public function formCustomValidate(&$customError)
    {
        // Return error message in $customError
        return true;
    }
}
