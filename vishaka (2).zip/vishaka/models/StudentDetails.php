<?php

namespace PHPMaker2023\vishaka2;

use Doctrine\DBAL\ParameterType;
use Doctrine\DBAL\FetchMode;
use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Query\QueryBuilder;

/**
 * Table class for student details
 */
class StudentDetails extends DbTable
{
    protected $SqlFrom = "";
    protected $SqlSelect = null;
    protected $SqlSelectList = null;
    protected $SqlWhere = "";
    protected $SqlGroupBy = "";
    protected $SqlHaving = "";
    protected $SqlOrderBy = "";
    public $DbErrorMessage = "";
    public $UseSessionForListSql = true;

    // Column CSS classes
    public $LeftColumnClass = "col-sm-2 col-form-label ew-label";
    public $RightColumnClass = "col-sm-10";
    public $OffsetColumnClass = "col-sm-10 offset-sm-2";
    public $TableLeftColumnClass = "w-col-2";

    // Export
    public $UseAjaxActions = false;
    public $ModalSearch = true;
    public $ModalView = true;
    public $ModalAdd = true;
    public $ModalEdit = true;
    public $ModalUpdate = false;
    public $InlineDelete = true;
    public $ModalGridAdd = false;
    public $ModalGridEdit = false;
    public $ModalMultiEdit = false;

    // Fields
    public $AdmissionNo;
    public $FullName;
    public $NameWithInitials;
    public $FathersName;
    public $MothersName;
    public $Address;
    public $Occupation;
    public $TravellingMethodtoschoo;
    public $inEmergencycontactno;
    public $Specialneeds;
    public $Grade;
    public $prefect;

    // Page ID
    public $PageID = ""; // To be overridden by subclass

    // Constructor
    public function __construct()
    {
        parent::__construct();
        global $Language, $CurrentLanguage, $CurrentLocale;

        // Language object
        $Language = Container("language");
        $this->TableVar = "student_details";
        $this->TableName = 'student details';
        $this->TableType = "TABLE";
        $this->ImportUseTransaction = $this->supportsTransaction() && Config("IMPORT_USE_TRANSACTION");
        $this->UseTransaction = $this->supportsTransaction() && Config("USE_TRANSACTION");

        // Update Table
        $this->UpdateTable = "`student details`";
        $this->Dbid = 'DB';
        $this->ExportAll = true;
        $this->ExportPageBreakCount = 0; // Page break per every n record (PDF only)

        // PDF
        $this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
        $this->ExportPageSize = "a4"; // Page size (PDF only)

        // PhpSpreadsheet
        $this->ExportExcelPageOrientation = null; // Page orientation (PhpSpreadsheet only)
        $this->ExportExcelPageSize = null; // Page size (PhpSpreadsheet only)

        // PHPWord
        $this->ExportWordPageOrientation = ""; // Page orientation (PHPWord only)
        $this->ExportWordPageSize = ""; // Page orientation (PHPWord only)
        $this->ExportWordColumnWidth = null; // Cell width (PHPWord only)
        $this->DetailAdd = true; // Allow detail add
        $this->DetailEdit = true; // Allow detail edit
        $this->DetailView = true; // Allow detail view
        $this->ShowMultipleDetails = false; // Show multiple details
        $this->GridAddRowCount = 5;
        $this->AllowAddDeleteRow = true; // Allow add/delete row
        $this->UseAjaxActions = $this->UseAjaxActions || Config("USE_AJAX_ACTIONS");
        $this->UseColumnVisibility = true;
        $this->UserIDAllowSecurity = Config("DEFAULT_USER_ID_ALLOW_SECURITY"); // Default User ID allowed permissions
        $this->BasicSearch = new BasicSearch($this);

        // Admission No $tbl, $fldvar, $fldname, $fldexp, $fldbsexp, $fldtype, $fldsize, $flddtfmt, $upload, $fldvirtualexp, $fldvirtual, $forceselect, $fldvirtualsrch, $fldviewtag = "", $fldhtmltag
        $this->AdmissionNo = new DbField(
            $this, // Table
            'x_AdmissionNo', // Variable name
            'Admission No', // Name
            '`Admission No`', // Expression
            '`Admission No`', // Basic search expression
            3, // Type
            6, // Size
            -1, // Date/Time format
            false, // Is upload field
            '`Admission No`', // Virtual expression
            false, // Is virtual
            false, // Force selection
            false, // Is Virtual search
            'FORMATTED TEXT', // View Tag
            'TEXT' // Edit Tag
        );
        $this->AdmissionNo->InputTextType = "text";
        $this->AdmissionNo->IsPrimaryKey = true; // Primary key field
        $this->AdmissionNo->Nullable = false; // NOT NULL field
        $this->AdmissionNo->Required = true; // Required field
        $this->AdmissionNo->UseFilter = true; // Table header filter
        switch ($CurrentLanguage) {
            case "en-US":
                $this->AdmissionNo->Lookup = new Lookup('Admission No', 'student_details', true, 'Admission No', ["Admission No","","",""], '', '', [], [], [], [], [], [], '', '', "");
                break;
            default:
                $this->AdmissionNo->Lookup = new Lookup('Admission No', 'student_details', true, 'Admission No', ["Admission No","","",""], '', '', [], [], [], [], [], [], '', '', "");
                break;
        }
        $this->AdmissionNo->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
        $this->AdmissionNo->SearchOperators = ["=", "<>", "IN", "NOT IN", "<", "<=", ">", ">=", "BETWEEN", "NOT BETWEEN"];
        $this->Fields['Admission No'] = &$this->AdmissionNo;

        // Full Name $tbl, $fldvar, $fldname, $fldexp, $fldbsexp, $fldtype, $fldsize, $flddtfmt, $upload, $fldvirtualexp, $fldvirtual, $forceselect, $fldvirtualsrch, $fldviewtag = "", $fldhtmltag
        $this->FullName = new DbField(
            $this, // Table
            'x_FullName', // Variable name
            'Full Name', // Name
            '`Full Name`', // Expression
            '`Full Name`', // Basic search expression
            201, // Type
            65535, // Size
            -1, // Date/Time format
            false, // Is upload field
            '`Full Name`', // Virtual expression
            false, // Is virtual
            false, // Force selection
            false, // Is Virtual search
            'FORMATTED TEXT', // View Tag
            'TEXTAREA' // Edit Tag
        );
        $this->FullName->InputTextType = "text";
        $this->FullName->Nullable = false; // NOT NULL field
        $this->FullName->Required = true; // Required field
        $this->FullName->UseFilter = true; // Table header filter
        switch ($CurrentLanguage) {
            case "en-US":
                $this->FullName->Lookup = new Lookup('Full Name', 'student_details', true, 'Full Name', ["Full Name","","",""], '', '', [], [], [], [], [], [], '', '', "");
                break;
            default:
                $this->FullName->Lookup = new Lookup('Full Name', 'student_details', true, 'Full Name', ["Full Name","","",""], '', '', [], [], [], [], [], [], '', '', "");
                break;
        }
        $this->FullName->SearchOperators = ["=", "<>", "IN", "NOT IN", "STARTS WITH", "NOT STARTS WITH", "LIKE", "NOT LIKE", "ENDS WITH", "NOT ENDS WITH", "IS EMPTY", "IS NOT EMPTY"];
        $this->Fields['Full Name'] = &$this->FullName;

        // Name With Initials $tbl, $fldvar, $fldname, $fldexp, $fldbsexp, $fldtype, $fldsize, $flddtfmt, $upload, $fldvirtualexp, $fldvirtual, $forceselect, $fldvirtualsrch, $fldviewtag = "", $fldhtmltag
        $this->NameWithInitials = new DbField(
            $this, // Table
            'x_NameWithInitials', // Variable name
            'Name With Initials', // Name
            '`Name With Initials`', // Expression
            '`Name With Initials`', // Basic search expression
            201, // Type
            65535, // Size
            -1, // Date/Time format
            false, // Is upload field
            '`Name With Initials`', // Virtual expression
            false, // Is virtual
            false, // Force selection
            false, // Is Virtual search
            'FORMATTED TEXT', // View Tag
            'TEXTAREA' // Edit Tag
        );
        $this->NameWithInitials->InputTextType = "text";
        $this->NameWithInitials->Nullable = false; // NOT NULL field
        $this->NameWithInitials->Required = true; // Required field
        $this->NameWithInitials->UseFilter = true; // Table header filter
        switch ($CurrentLanguage) {
            case "en-US":
                $this->NameWithInitials->Lookup = new Lookup('Name With Initials', 'student_details', true, 'Name With Initials', ["Name With Initials","","",""], '', '', [], [], [], [], [], [], '', '', "");
                break;
            default:
                $this->NameWithInitials->Lookup = new Lookup('Name With Initials', 'student_details', true, 'Name With Initials', ["Name With Initials","","",""], '', '', [], [], [], [], [], [], '', '', "");
                break;
        }
        $this->NameWithInitials->SearchOperators = ["=", "<>", "IN", "NOT IN", "STARTS WITH", "NOT STARTS WITH", "LIKE", "NOT LIKE", "ENDS WITH", "NOT ENDS WITH", "IS EMPTY", "IS NOT EMPTY"];
        $this->Fields['Name With Initials'] = &$this->NameWithInitials;

        // Father's Name $tbl, $fldvar, $fldname, $fldexp, $fldbsexp, $fldtype, $fldsize, $flddtfmt, $upload, $fldvirtualexp, $fldvirtual, $forceselect, $fldvirtualsrch, $fldviewtag = "", $fldhtmltag
        $this->FathersName = new DbField(
            $this, // Table
            'x_FathersName', // Variable name
            'Father\'s Name', // Name
            '`Father\'s Name`', // Expression
            '`Father\'s Name`', // Basic search expression
            201, // Type
            65535, // Size
            -1, // Date/Time format
            false, // Is upload field
            '`Father\'s Name`', // Virtual expression
            false, // Is virtual
            false, // Force selection
            false, // Is Virtual search
            'FORMATTED TEXT', // View Tag
            'TEXTAREA' // Edit Tag
        );
        $this->FathersName->InputTextType = "text";
        $this->FathersName->Nullable = false; // NOT NULL field
        $this->FathersName->Required = true; // Required field
        $this->FathersName->UseFilter = true; // Table header filter
        switch ($CurrentLanguage) {
            case "en-US":
                $this->FathersName->Lookup = new Lookup('Father\'s Name', 'student_details', true, 'Father\'s Name', ["Father's Name","","",""], '', '', [], [], [], [], [], [], '', '', "");
                break;
            default:
                $this->FathersName->Lookup = new Lookup('Father\'s Name', 'student_details', true, 'Father\'s Name', ["Father's Name","","",""], '', '', [], [], [], [], [], [], '', '', "");
                break;
        }
        $this->FathersName->SearchOperators = ["=", "<>", "IN", "NOT IN", "STARTS WITH", "NOT STARTS WITH", "LIKE", "NOT LIKE", "ENDS WITH", "NOT ENDS WITH", "IS EMPTY", "IS NOT EMPTY"];
        $this->Fields['Father\'s Name'] = &$this->FathersName;

        // Mother's Name $tbl, $fldvar, $fldname, $fldexp, $fldbsexp, $fldtype, $fldsize, $flddtfmt, $upload, $fldvirtualexp, $fldvirtual, $forceselect, $fldvirtualsrch, $fldviewtag = "", $fldhtmltag
        $this->MothersName = new DbField(
            $this, // Table
            'x_MothersName', // Variable name
            'Mother\'s Name', // Name
            '`Mother\'s Name`', // Expression
            '`Mother\'s Name`', // Basic search expression
            201, // Type
            65535, // Size
            -1, // Date/Time format
            false, // Is upload field
            '`Mother\'s Name`', // Virtual expression
            false, // Is virtual
            false, // Force selection
            false, // Is Virtual search
            'FORMATTED TEXT', // View Tag
            'TEXTAREA' // Edit Tag
        );
        $this->MothersName->InputTextType = "text";
        $this->MothersName->Nullable = false; // NOT NULL field
        $this->MothersName->Required = true; // Required field
        $this->MothersName->UseFilter = true; // Table header filter
        switch ($CurrentLanguage) {
            case "en-US":
                $this->MothersName->Lookup = new Lookup('Mother\'s Name', 'student_details', true, 'Mother\'s Name', ["Mother's Name","","",""], '', '', [], [], [], [], [], [], '', '', "");
                break;
            default:
                $this->MothersName->Lookup = new Lookup('Mother\'s Name', 'student_details', true, 'Mother\'s Name', ["Mother's Name","","",""], '', '', [], [], [], [], [], [], '', '', "");
                break;
        }
        $this->MothersName->SearchOperators = ["=", "<>", "IN", "NOT IN", "STARTS WITH", "NOT STARTS WITH", "LIKE", "NOT LIKE", "ENDS WITH", "NOT ENDS WITH", "IS EMPTY", "IS NOT EMPTY"];
        $this->Fields['Mother\'s Name'] = &$this->MothersName;

        // Address $tbl, $fldvar, $fldname, $fldexp, $fldbsexp, $fldtype, $fldsize, $flddtfmt, $upload, $fldvirtualexp, $fldvirtual, $forceselect, $fldvirtualsrch, $fldviewtag = "", $fldhtmltag
        $this->Address = new DbField(
            $this, // Table
            'x_Address', // Variable name
            'Address', // Name
            '`Address`', // Expression
            '`Address`', // Basic search expression
            201, // Type
            65535, // Size
            -1, // Date/Time format
            false, // Is upload field
            '`Address`', // Virtual expression
            false, // Is virtual
            false, // Force selection
            false, // Is Virtual search
            'FORMATTED TEXT', // View Tag
            'TEXTAREA' // Edit Tag
        );
        $this->Address->InputTextType = "text";
        $this->Address->Nullable = false; // NOT NULL field
        $this->Address->Required = true; // Required field
        $this->Address->UseFilter = true; // Table header filter
        switch ($CurrentLanguage) {
            case "en-US":
                $this->Address->Lookup = new Lookup('Address', 'student_details', true, 'Address', ["Address","","",""], '', '', [], [], [], [], [], [], '', '', "");
                break;
            default:
                $this->Address->Lookup = new Lookup('Address', 'student_details', true, 'Address', ["Address","","",""], '', '', [], [], [], [], [], [], '', '', "");
                break;
        }
        $this->Address->SearchOperators = ["=", "<>", "IN", "NOT IN", "STARTS WITH", "NOT STARTS WITH", "LIKE", "NOT LIKE", "ENDS WITH", "NOT ENDS WITH", "IS EMPTY", "IS NOT EMPTY"];
        $this->Fields['Address'] = &$this->Address;

        // Occupation $tbl, $fldvar, $fldname, $fldexp, $fldbsexp, $fldtype, $fldsize, $flddtfmt, $upload, $fldvirtualexp, $fldvirtual, $forceselect, $fldvirtualsrch, $fldviewtag = "", $fldhtmltag
        $this->Occupation = new DbField(
            $this, // Table
            'x_Occupation', // Variable name
            'Occupation', // Name
            '`Occupation`', // Expression
            '`Occupation`', // Basic search expression
            201, // Type
            65535, // Size
            -1, // Date/Time format
            false, // Is upload field
            '`Occupation`', // Virtual expression
            false, // Is virtual
            false, // Force selection
            false, // Is Virtual search
            'FORMATTED TEXT', // View Tag
            'TEXTAREA' // Edit Tag
        );
        $this->Occupation->InputTextType = "text";
        $this->Occupation->Nullable = false; // NOT NULL field
        $this->Occupation->Required = true; // Required field
        $this->Occupation->UseFilter = true; // Table header filter
        switch ($CurrentLanguage) {
            case "en-US":
                $this->Occupation->Lookup = new Lookup('Occupation', 'student_details', true, 'Occupation', ["Occupation","","",""], '', '', [], [], [], [], [], [], '', '', "");
                break;
            default:
                $this->Occupation->Lookup = new Lookup('Occupation', 'student_details', true, 'Occupation', ["Occupation","","",""], '', '', [], [], [], [], [], [], '', '', "");
                break;
        }
        $this->Occupation->SearchOperators = ["=", "<>", "IN", "NOT IN", "STARTS WITH", "NOT STARTS WITH", "LIKE", "NOT LIKE", "ENDS WITH", "NOT ENDS WITH", "IS EMPTY", "IS NOT EMPTY"];
        $this->Fields['Occupation'] = &$this->Occupation;

        // Travelling Method to schoo $tbl, $fldvar, $fldname, $fldexp, $fldbsexp, $fldtype, $fldsize, $flddtfmt, $upload, $fldvirtualexp, $fldvirtual, $forceselect, $fldvirtualsrch, $fldviewtag = "", $fldhtmltag
        $this->TravellingMethodtoschoo = new DbField(
            $this, // Table
            'x_TravellingMethodtoschoo', // Variable name
            'Travelling Method to schoo', // Name
            '`Travelling Method to schoo`', // Expression
            '`Travelling Method to schoo`', // Basic search expression
            201, // Type
            65535, // Size
            -1, // Date/Time format
            false, // Is upload field
            '`Travelling Method to schoo`', // Virtual expression
            false, // Is virtual
            false, // Force selection
            false, // Is Virtual search
            'FORMATTED TEXT', // View Tag
            'SELECT' // Edit Tag
        );
        $this->TravellingMethodtoschoo->InputTextType = "text";
        $this->TravellingMethodtoschoo->Nullable = false; // NOT NULL field
        $this->TravellingMethodtoschoo->Required = true; // Required field
        $this->TravellingMethodtoschoo->UsePleaseSelect = true; // Use PleaseSelect by default
        $this->TravellingMethodtoschoo->PleaseSelectText = $Language->phrase("PleaseSelect"); // "PleaseSelect" text
        $this->TravellingMethodtoschoo->UseFilter = true; // Table header filter
        switch ($CurrentLanguage) {
            case "en-US":
                $this->TravellingMethodtoschoo->Lookup = new Lookup('Travelling Method to schoo', 'student_details', true, 'Travelling Method to schoo', ["Travelling Method to schoo","","",""], '', '', [], [], [], [], [], [], '', '', "");
                break;
            default:
                $this->TravellingMethodtoschoo->Lookup = new Lookup('Travelling Method to schoo', 'student_details', true, 'Travelling Method to schoo', ["Travelling Method to schoo","","",""], '', '', [], [], [], [], [], [], '', '', "");
                break;
        }
        $this->TravellingMethodtoschoo->OptionCount = 7;
        $this->TravellingMethodtoschoo->SearchOperators = ["=", "<>"];
        $this->Fields['Travelling Method to schoo'] = &$this->TravellingMethodtoschoo;

        // in Emergency contact no $tbl, $fldvar, $fldname, $fldexp, $fldbsexp, $fldtype, $fldsize, $flddtfmt, $upload, $fldvirtualexp, $fldvirtual, $forceselect, $fldvirtualsrch, $fldviewtag = "", $fldhtmltag
        $this->inEmergencycontactno = new DbField(
            $this, // Table
            'x_inEmergencycontactno', // Variable name
            'in Emergency contact no', // Name
            '`in Emergency contact no`', // Expression
            '`in Emergency contact no`', // Basic search expression
            3, // Type
            10, // Size
            -1, // Date/Time format
            false, // Is upload field
            '`in Emergency contact no`', // Virtual expression
            false, // Is virtual
            false, // Force selection
            false, // Is Virtual search
            'FORMATTED TEXT', // View Tag
            'TEXT' // Edit Tag
        );
        $this->inEmergencycontactno->InputTextType = "text";
        $this->inEmergencycontactno->Nullable = false; // NOT NULL field
        $this->inEmergencycontactno->Required = true; // Required field
        $this->inEmergencycontactno->UseFilter = true; // Table header filter
        switch ($CurrentLanguage) {
            case "en-US":
                $this->inEmergencycontactno->Lookup = new Lookup('in Emergency contact no', 'student_details', true, 'in Emergency contact no', ["in Emergency contact no","","",""], '', '', [], [], [], [], [], [], '', '', "");
                break;
            default:
                $this->inEmergencycontactno->Lookup = new Lookup('in Emergency contact no', 'student_details', true, 'in Emergency contact no', ["in Emergency contact no","","",""], '', '', [], [], [], [], [], [], '', '', "");
                break;
        }
        $this->inEmergencycontactno->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
        $this->inEmergencycontactno->SearchOperators = ["=", "<>", "IN", "NOT IN", "<", "<=", ">", ">=", "BETWEEN", "NOT BETWEEN"];
        $this->Fields['in Emergency contact no'] = &$this->inEmergencycontactno;

        // Special needs $tbl, $fldvar, $fldname, $fldexp, $fldbsexp, $fldtype, $fldsize, $flddtfmt, $upload, $fldvirtualexp, $fldvirtual, $forceselect, $fldvirtualsrch, $fldviewtag = "", $fldhtmltag
        $this->Specialneeds = new DbField(
            $this, // Table
            'x_Specialneeds', // Variable name
            'Special needs', // Name
            '`Special needs`', // Expression
            '`Special needs`', // Basic search expression
            16, // Type
            1, // Size
            -1, // Date/Time format
            false, // Is upload field
            '`Special needs`', // Virtual expression
            false, // Is virtual
            false, // Force selection
            false, // Is Virtual search
            'FORMATTED TEXT', // View Tag
            'RADIO' // Edit Tag
        );
        $this->Specialneeds->InputTextType = "text";
        $this->Specialneeds->Nullable = false; // NOT NULL field
        $this->Specialneeds->Required = true; // Required field
        $this->Specialneeds->DataType = DATATYPE_BOOLEAN;
        $this->Specialneeds->UseFilter = true; // Table header filter
        switch ($CurrentLanguage) {
            case "en-US":
                $this->Specialneeds->Lookup = new Lookup('Special needs', 'student_details', true, 'Special needs', ["Special needs","","",""], '', '', [], [], [], [], [], [], '', '', "");
                break;
            default:
                $this->Specialneeds->Lookup = new Lookup('Special needs', 'student_details', true, 'Special needs', ["Special needs","","",""], '', '', [], [], [], [], [], [], '', '', "");
                break;
        }
        $this->Specialneeds->OptionCount = 2;
        $this->Specialneeds->DefaultErrorMessage = $Language->phrase("IncorrectField");
        $this->Specialneeds->SearchOperators = ["=", "<>"];
        $this->Fields['Special needs'] = &$this->Specialneeds;

        // Grade $tbl, $fldvar, $fldname, $fldexp, $fldbsexp, $fldtype, $fldsize, $flddtfmt, $upload, $fldvirtualexp, $fldvirtual, $forceselect, $fldvirtualsrch, $fldviewtag = "", $fldhtmltag
        $this->Grade = new DbField(
            $this, // Table
            'x_Grade', // Variable name
            'Grade', // Name
            '`Grade`', // Expression
            '`Grade`', // Basic search expression
            201, // Type
            65535, // Size
            -1, // Date/Time format
            false, // Is upload field
            '`Grade`', // Virtual expression
            false, // Is virtual
            false, // Force selection
            false, // Is Virtual search
            'FORMATTED TEXT', // View Tag
            'SELECT' // Edit Tag
        );
        $this->Grade->InputTextType = "text";
        $this->Grade->Nullable = false; // NOT NULL field
        $this->Grade->Required = true; // Required field
        $this->Grade->UsePleaseSelect = true; // Use PleaseSelect by default
        $this->Grade->PleaseSelectText = $Language->phrase("PleaseSelect"); // "PleaseSelect" text
        $this->Grade->UseFilter = true; // Table header filter
        switch ($CurrentLanguage) {
            case "en-US":
                $this->Grade->Lookup = new Lookup('Grade', 'student_details', true, 'Grade', ["Grade","","",""], '', '', [], [], [], [], [], [], '', '', "");
                break;
            default:
                $this->Grade->Lookup = new Lookup('Grade', 'student_details', true, 'Grade', ["Grade","","",""], '', '', [], [], [], [], [], [], '', '', "");
                break;
        }
        $this->Grade->OptionCount = 14;
        $this->Grade->SearchOperators = ["=", "<>"];
        $this->Fields['Grade'] = &$this->Grade;

        // prefect $tbl, $fldvar, $fldname, $fldexp, $fldbsexp, $fldtype, $fldsize, $flddtfmt, $upload, $fldvirtualexp, $fldvirtual, $forceselect, $fldvirtualsrch, $fldviewtag = "", $fldhtmltag
        $this->prefect = new DbField(
            $this, // Table
            'x_prefect', // Variable name
            'prefect', // Name
            '`prefect`', // Expression
            '`prefect`', // Basic search expression
            16, // Type
            1, // Size
            -1, // Date/Time format
            false, // Is upload field
            '`prefect`', // Virtual expression
            false, // Is virtual
            false, // Force selection
            false, // Is Virtual search
            'FORMATTED TEXT', // View Tag
            'RADIO' // Edit Tag
        );
        $this->prefect->InputTextType = "text";
        $this->prefect->Nullable = false; // NOT NULL field
        $this->prefect->Required = true; // Required field
        $this->prefect->DataType = DATATYPE_BOOLEAN;
        $this->prefect->UseFilter = true; // Table header filter
        switch ($CurrentLanguage) {
            case "en-US":
                $this->prefect->Lookup = new Lookup('prefect', 'student_details', true, 'prefect', ["prefect","","",""], '', '', [], [], [], [], [], [], '', '', "");
                break;
            default:
                $this->prefect->Lookup = new Lookup('prefect', 'student_details', true, 'prefect', ["prefect","","",""], '', '', [], [], [], [], [], [], '', '', "");
                break;
        }
        $this->prefect->OptionCount = 2;
        $this->prefect->DefaultErrorMessage = $Language->phrase("IncorrectField");
        $this->prefect->SearchOperators = ["=", "<>"];
        $this->Fields['prefect'] = &$this->prefect;

        // Add Doctrine Cache
        $this->Cache = new ArrayCache();
        $this->CacheProfile = new \Doctrine\DBAL\Cache\QueryCacheProfile(0, $this->TableVar);

        // Call Table Load event
        $this->tableLoad();
    }

    // Field Visibility
    public function getFieldVisibility($fldParm)
    {
        global $Security;
        return $this->$fldParm->Visible; // Returns original value
    }

    // Set left column class (must be predefined col-*-* classes of Bootstrap grid system)
    public function setLeftColumnClass($class)
    {
        if (preg_match('/^col\-(\w+)\-(\d+)$/', $class, $match)) {
            $this->LeftColumnClass = $class . " col-form-label ew-label";
            $this->RightColumnClass = "col-" . $match[1] . "-" . strval(12 - (int)$match[2]);
            $this->OffsetColumnClass = $this->RightColumnClass . " " . str_replace("col-", "offset-", $class);
            $this->TableLeftColumnClass = preg_replace('/^col-\w+-(\d+)$/', "w-col-$1", $class); // Change to w-col-*
        }
    }

    // Single column sort
    public function updateSort(&$fld)
    {
        if ($this->CurrentOrder == $fld->Name) {
            $sortField = $fld->Expression;
            $lastSort = $fld->getSort();
            if (in_array($this->CurrentOrderType, ["ASC", "DESC", "NO"])) {
                $curSort = $this->CurrentOrderType;
            } else {
                $curSort = $lastSort;
            }
            $orderBy = in_array($curSort, ["ASC", "DESC"]) ? $sortField . " " . $curSort : "";
            $this->setSessionOrderBy($orderBy); // Save to Session
        }
    }

    // Update field sort
    public function updateFieldSort()
    {
        $orderBy = $this->getSessionOrderBy(); // Get ORDER BY from Session
        $flds = GetSortFields($orderBy);
        foreach ($this->Fields as $field) {
            $fldSort = "";
            foreach ($flds as $fld) {
                if ($fld[0] == $field->Expression || $fld[0] == $field->VirtualExpression) {
                    $fldSort = $fld[1];
                }
            }
            $field->setSort($fldSort);
        }
    }

    // Render X Axis for chart
    public function renderChartXAxis($chartVar, $chartRow)
    {
        return $chartRow;
    }

    // Table level SQL
    public function getSqlFrom() // From
    {
        return ($this->SqlFrom != "") ? $this->SqlFrom : "`student details`";
    }

    public function sqlFrom() // For backward compatibility
    {
        return $this->getSqlFrom();
    }

    public function setSqlFrom($v)
    {
        $this->SqlFrom = $v;
    }

    public function getSqlSelect() // Select
    {
        return $this->SqlSelect ?? $this->getQueryBuilder()->select("*");
    }

    public function sqlSelect() // For backward compatibility
    {
        return $this->getSqlSelect();
    }

    public function setSqlSelect($v)
    {
        $this->SqlSelect = $v;
    }

    public function getSqlWhere() // Where
    {
        $where = ($this->SqlWhere != "") ? $this->SqlWhere : "";
        $this->DefaultFilter = "";
        AddFilter($where, $this->DefaultFilter);
        return $where;
    }

    public function sqlWhere() // For backward compatibility
    {
        return $this->getSqlWhere();
    }

    public function setSqlWhere($v)
    {
        $this->SqlWhere = $v;
    }

    public function getSqlGroupBy() // Group By
    {
        return ($this->SqlGroupBy != "") ? $this->SqlGroupBy : "";
    }

    public function sqlGroupBy() // For backward compatibility
    {
        return $this->getSqlGroupBy();
    }

    public function setSqlGroupBy($v)
    {
        $this->SqlGroupBy = $v;
    }

    public function getSqlHaving() // Having
    {
        return ($this->SqlHaving != "") ? $this->SqlHaving : "";
    }

    public function sqlHaving() // For backward compatibility
    {
        return $this->getSqlHaving();
    }

    public function setSqlHaving($v)
    {
        $this->SqlHaving = $v;
    }

    public function getSqlOrderBy() // Order By
    {
        return ($this->SqlOrderBy != "") ? $this->SqlOrderBy : "";
    }

    public function sqlOrderBy() // For backward compatibility
    {
        return $this->getSqlOrderBy();
    }

    public function setSqlOrderBy($v)
    {
        $this->SqlOrderBy = $v;
    }

    // Apply User ID filters
    public function applyUserIDFilters($filter, $id = "")
    {
        return $filter;
    }

    // Check if User ID security allows view all
    public function userIDAllow($id = "")
    {
        $allow = $this->UserIDAllowSecurity;
        switch ($id) {
            case "add":
            case "copy":
            case "gridadd":
            case "register":
            case "addopt":
                return (($allow & 1) == 1);
            case "edit":
            case "gridedit":
            case "update":
            case "changepassword":
            case "resetpassword":
                return (($allow & 4) == 4);
            case "delete":
                return (($allow & 2) == 2);
            case "view":
                return (($allow & 32) == 32);
            case "search":
                return (($allow & 64) == 64);
            case "lookup":
                return (($allow & 256) == 256);
            default:
                return (($allow & 8) == 8);
        }
    }

    /**
     * Get record count
     *
     * @param string|QueryBuilder $sql SQL or QueryBuilder
     * @param mixed $c Connection
     * @return int
     */
    public function getRecordCount($sql, $c = null)
    {
        $cnt = -1;
        $rs = null;
        if ($sql instanceof QueryBuilder) { // Query builder
            $sqlwrk = clone $sql;
            $sqlwrk = $sqlwrk->resetQueryPart("orderBy")->getSQL();
        } else {
            $sqlwrk = $sql;
        }
        $pattern = '/^SELECT\s([\s\S]+)\sFROM\s/i';
        // Skip Custom View / SubQuery / SELECT DISTINCT / ORDER BY
        if (
            ($this->TableType == 'TABLE' || $this->TableType == 'VIEW' || $this->TableType == 'LINKTABLE') &&
            preg_match($pattern, $sqlwrk) && !preg_match('/\(\s*(SELECT[^)]+)\)/i', $sqlwrk) &&
            !preg_match('/^\s*select\s+distinct\s+/i', $sqlwrk) && !preg_match('/\s+order\s+by\s+/i', $sqlwrk)
        ) {
            $sqlwrk = "SELECT COUNT(*) FROM " . preg_replace($pattern, "", $sqlwrk);
        } else {
            $sqlwrk = "SELECT COUNT(*) FROM (" . $sqlwrk . ") COUNT_TABLE";
        }
        $conn = $c ?? $this->getConnection();
        $cnt = $conn->fetchOne($sqlwrk);
        if ($cnt !== false) {
            return (int)$cnt;
        }

        // Unable to get count by SELECT COUNT(*), execute the SQL to get record count directly
        return ExecuteRecordCount($sql, $conn);
    }

    // Get SQL
    public function getSql($where, $orderBy = "")
    {
        return $this->getSqlAsQueryBuilder($where, $orderBy)->getSQL();
    }

    // Get QueryBuilder
    public function getSqlAsQueryBuilder($where, $orderBy = "")
    {
        return $this->buildSelectSql(
            $this->getSqlSelect(),
            $this->getSqlFrom(),
            $this->getSqlWhere(),
            $this->getSqlGroupBy(),
            $this->getSqlHaving(),
            $this->getSqlOrderBy(),
            $where,
            $orderBy
        );
    }

    // Table SQL
    public function getCurrentSql()
    {
        $filter = $this->CurrentFilter;
        $filter = $this->applyUserIDFilters($filter);
        $sort = $this->getSessionOrderBy();
        return $this->getSql($filter, $sort);
    }

    /**
     * Table SQL with List page filter
     *
     * @return QueryBuilder
     */
    public function getListSql()
    {
        $filter = $this->UseSessionForListSql ? $this->getSessionWhere() : "";
        AddFilter($filter, $this->CurrentFilter);
        $filter = $this->applyUserIDFilters($filter);
        $this->recordsetSelecting($filter);
        $select = $this->getSqlSelect();
        $from = $this->getSqlFrom();
        $sort = $this->UseSessionForListSql ? $this->getSessionOrderBy() : "";
        $this->Sort = $sort;
        return $this->buildSelectSql(
            $select,
            $from,
            $this->getSqlWhere(),
            $this->getSqlGroupBy(),
            $this->getSqlHaving(),
            $this->getSqlOrderBy(),
            $filter,
            $sort
        );
    }

    // Get ORDER BY clause
    public function getOrderBy()
    {
        $orderBy = $this->getSqlOrderBy();
        $sort = $this->getSessionOrderBy();
        if ($orderBy != "" && $sort != "") {
            $orderBy .= ", " . $sort;
        } elseif ($sort != "") {
            $orderBy = $sort;
        }
        return $orderBy;
    }

    // Get record count based on filter (for detail record count in master table pages)
    public function loadRecordCount($filter)
    {
        $origFilter = $this->CurrentFilter;
        $this->CurrentFilter = $filter;
        $this->recordsetSelecting($this->CurrentFilter);
        $select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : $this->getQueryBuilder()->select("*");
        $groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
        $having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
        $sql = $this->buildSelectSql($select, $this->getSqlFrom(), $this->getSqlWhere(), $groupBy, $having, "", $this->CurrentFilter, "");
        $cnt = $this->getRecordCount($sql);
        $this->CurrentFilter = $origFilter;
        return $cnt;
    }

    // Get record count (for current List page)
    public function listRecordCount()
    {
        $filter = $this->getSessionWhere();
        AddFilter($filter, $this->CurrentFilter);
        $filter = $this->applyUserIDFilters($filter);
        $this->recordsetSelecting($filter);
        $select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : $this->getQueryBuilder()->select("*");
        $groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
        $having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
        $sql = $this->buildSelectSql($select, $this->getSqlFrom(), $this->getSqlWhere(), $groupBy, $having, "", $filter, "");
        $cnt = $this->getRecordCount($sql);
        return $cnt;
    }

    /**
     * INSERT statement
     *
     * @param mixed $rs
     * @return QueryBuilder
     */
    public function insertSql(&$rs)
    {
        $queryBuilder = $this->getQueryBuilder();
        $queryBuilder->insert($this->UpdateTable);
        foreach ($rs as $name => $value) {
            if (!isset($this->Fields[$name]) || $this->Fields[$name]->IsCustom) {
                continue;
            }
            $type = GetParameterType($this->Fields[$name], $value, $this->Dbid);
            $queryBuilder->setValue($this->Fields[$name]->Expression, $queryBuilder->createPositionalParameter($value, $type));
        }
        return $queryBuilder;
    }

    // Insert
    public function insert(&$rs)
    {
        $conn = $this->getConnection();
        try {
            $success = $this->insertSql($rs)->execute();
            $this->DbErrorMessage = "";
        } catch (\Exception $e) {
            $success = false;
            $this->DbErrorMessage = $e->getMessage();
        }
        if ($success) {
        }
        return $success;
    }

    /**
     * UPDATE statement
     *
     * @param array $rs Data to be updated
     * @param string|array $where WHERE clause
     * @param string $curfilter Filter
     * @return QueryBuilder
     */
    public function updateSql(&$rs, $where = "", $curfilter = true)
    {
        $queryBuilder = $this->getQueryBuilder();
        $queryBuilder->update($this->UpdateTable);
        foreach ($rs as $name => $value) {
            if (!isset($this->Fields[$name]) || $this->Fields[$name]->IsCustom || $this->Fields[$name]->IsAutoIncrement) {
                continue;
            }
            $type = GetParameterType($this->Fields[$name], $value, $this->Dbid);
            $queryBuilder->set($this->Fields[$name]->Expression, $queryBuilder->createPositionalParameter($value, $type));
        }
        $filter = ($curfilter) ? $this->CurrentFilter : "";
        if (is_array($where)) {
            $where = $this->arrayToFilter($where);
        }
        AddFilter($filter, $where);
        if ($filter != "") {
            $queryBuilder->where($filter);
        }
        return $queryBuilder;
    }

    // Update
    public function update(&$rs, $where = "", $rsold = null, $curfilter = true)
    {
        // If no field is updated, execute may return 0. Treat as success
        try {
            $success = $this->updateSql($rs, $where, $curfilter)->execute();
            $success = ($success > 0) ? $success : true;
            $this->DbErrorMessage = "";
        } catch (\Exception $e) {
            $success = false;
            $this->DbErrorMessage = $e->getMessage();
        }
        return $success;
    }

    /**
     * DELETE statement
     *
     * @param array $rs Key values
     * @param string|array $where WHERE clause
     * @param string $curfilter Filter
     * @return QueryBuilder
     */
    public function deleteSql(&$rs, $where = "", $curfilter = true)
    {
        $queryBuilder = $this->getQueryBuilder();
        $queryBuilder->delete($this->UpdateTable);
        if (is_array($where)) {
            $where = $this->arrayToFilter($where);
        }
        if ($rs) {
            if (array_key_exists('Admission No', $rs)) {
                AddFilter($where, QuotedName('Admission No', $this->Dbid) . '=' . QuotedValue($rs['Admission No'], $this->AdmissionNo->DataType, $this->Dbid));
            }
        }
        $filter = ($curfilter) ? $this->CurrentFilter : "";
        AddFilter($filter, $where);
        return $queryBuilder->where($filter != "" ? $filter : "0=1");
    }

    // Delete
    public function delete(&$rs, $where = "", $curfilter = false)
    {
        $success = true;
        if ($success) {
            try {
                $success = $this->deleteSql($rs, $where, $curfilter)->execute();
                $this->DbErrorMessage = "";
            } catch (\Exception $e) {
                $success = false;
                $this->DbErrorMessage = $e->getMessage();
            }
        }
        return $success;
    }

    // Load DbValue from recordset or array
    protected function loadDbValues($row)
    {
        if (!is_array($row)) {
            return;
        }
        $this->AdmissionNo->DbValue = $row['Admission No'];
        $this->FullName->DbValue = $row['Full Name'];
        $this->NameWithInitials->DbValue = $row['Name With Initials'];
        $this->FathersName->DbValue = $row['Father\'s Name'];
        $this->MothersName->DbValue = $row['Mother\'s Name'];
        $this->Address->DbValue = $row['Address'];
        $this->Occupation->DbValue = $row['Occupation'];
        $this->TravellingMethodtoschoo->DbValue = $row['Travelling Method to schoo'];
        $this->inEmergencycontactno->DbValue = $row['in Emergency contact no'];
        $this->Specialneeds->DbValue = $row['Special needs'];
        $this->Grade->DbValue = $row['Grade'];
        $this->prefect->DbValue = $row['prefect'];
    }

    // Delete uploaded files
    public function deleteUploadedFiles($row)
    {
        $this->loadDbValues($row);
    }

    // Record filter WHERE clause
    protected function sqlKeyFilter()
    {
        return "`Admission No` = @AdmissionNo@";
    }

    // Get Key
    public function getKey($current = false)
    {
        $keys = [];
        $val = $current ? $this->AdmissionNo->CurrentValue : $this->AdmissionNo->OldValue;
        if (EmptyValue($val)) {
            return "";
        } else {
            $keys[] = $val;
        }
        return implode(Config("COMPOSITE_KEY_SEPARATOR"), $keys);
    }

    // Set Key
    public function setKey($key, $current = false)
    {
        $this->OldKey = strval($key);
        $keys = explode(Config("COMPOSITE_KEY_SEPARATOR"), $this->OldKey);
        if (count($keys) == 1) {
            if ($current) {
                $this->AdmissionNo->CurrentValue = $keys[0];
            } else {
                $this->AdmissionNo->OldValue = $keys[0];
            }
        }
    }

    // Get record filter
    public function getRecordFilter($row = null, $current = false)
    {
        $keyFilter = $this->sqlKeyFilter();
        if (is_array($row)) {
            $val = array_key_exists('Admission No', $row) ? $row['Admission No'] : null;
        } else {
            $val = !EmptyValue($this->AdmissionNo->OldValue) && !$current ? $this->AdmissionNo->OldValue : $this->AdmissionNo->CurrentValue;
        }
        if (!is_numeric($val)) {
            return "0=1"; // Invalid key
        }
        if ($val === null) {
            return "0=1"; // Invalid key
        } else {
            $keyFilter = str_replace("@AdmissionNo@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
        }
        return $keyFilter;
    }

    // Return page URL
    public function getReturnUrl()
    {
        $referUrl = ReferUrl();
        $referPageName = ReferPageName();
        $name = PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL");
        // Get referer URL automatically
        if ($referUrl != "" && $referPageName != CurrentPageName() && $referPageName != "login") { // Referer not same page or login page
            $_SESSION[$name] = $referUrl; // Save to Session
        }
        return $_SESSION[$name] ?? GetUrl("StudentDetailsList");
    }

    // Set return page URL
    public function setReturnUrl($v)
    {
        $_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL")] = $v;
    }

    // Get modal caption
    public function getModalCaption($pageName)
    {
        global $Language;
        if ($pageName == "StudentDetailsView") {
            return $Language->phrase("View");
        } elseif ($pageName == "StudentDetailsEdit") {
            return $Language->phrase("Edit");
        } elseif ($pageName == "StudentDetailsAdd") {
            return $Language->phrase("Add");
        }
        return "";
    }

    // API page name
    public function getApiPageName($action)
    {
        switch (strtolower($action)) {
            case Config("API_VIEW_ACTION"):
                return "StudentDetailsView";
            case Config("API_ADD_ACTION"):
                return "StudentDetailsAdd";
            case Config("API_EDIT_ACTION"):
                return "StudentDetailsEdit";
            case Config("API_DELETE_ACTION"):
                return "StudentDetailsDelete";
            case Config("API_LIST_ACTION"):
                return "StudentDetailsList";
            default:
                return "";
        }
    }

    // Current URL
    public function getCurrentUrl($parm = "")
    {
        $url = CurrentPageUrl(false);
        if ($parm != "") {
            $url = $this->keyUrl($url, $parm);
        } else {
            $url = $this->keyUrl($url, Config("TABLE_SHOW_DETAIL") . "=");
        }
        return $this->addMasterUrl($url);
    }

    // List URL
    public function getListUrl()
    {
        return "StudentDetailsList";
    }

    // View URL
    public function getViewUrl($parm = "")
    {
        if ($parm != "") {
            $url = $this->keyUrl("StudentDetailsView", $parm);
        } else {
            $url = $this->keyUrl("StudentDetailsView", Config("TABLE_SHOW_DETAIL") . "=");
        }
        return $this->addMasterUrl($url);
    }

    // Add URL
    public function getAddUrl($parm = "")
    {
        if ($parm != "") {
            $url = "StudentDetailsAdd?" . $parm;
        } else {
            $url = "StudentDetailsAdd";
        }
        return $this->addMasterUrl($url);
    }

    // Edit URL
    public function getEditUrl($parm = "")
    {
        $url = $this->keyUrl("StudentDetailsEdit", $parm);
        return $this->addMasterUrl($url);
    }

    // Inline edit URL
    public function getInlineEditUrl()
    {
        $url = $this->keyUrl("StudentDetailsList", "action=edit");
        return $this->addMasterUrl($url);
    }

    // Copy URL
    public function getCopyUrl($parm = "")
    {
        $url = $this->keyUrl("StudentDetailsAdd", $parm);
        return $this->addMasterUrl($url);
    }

    // Inline copy URL
    public function getInlineCopyUrl()
    {
        $url = $this->keyUrl("StudentDetailsList", "action=copy");
        return $this->addMasterUrl($url);
    }

    // Delete URL
    public function getDeleteUrl()
    {
        if ($this->UseAjaxActions && ConvertToBool(Param("infinitescroll")) && CurrentPageID() == "list") {
            return $this->keyUrl(GetApiUrl(Config("API_DELETE_ACTION") . "/" . $this->TableVar));
        } else {
            return $this->keyUrl("StudentDetailsDelete");
        }
    }

    // Add master url
    public function addMasterUrl($url)
    {
        return $url;
    }

    public function keyToJson($htmlEncode = false)
    {
        $json = "";
        $json .= "\"AdmissionNo\":" . JsonEncode($this->AdmissionNo->CurrentValue, "number");
        $json = "{" . $json . "}";
        if ($htmlEncode) {
            $json = HtmlEncode($json);
        }
        return $json;
    }

    // Add key value to URL
    public function keyUrl($url, $parm = "")
    {
        if ($this->AdmissionNo->CurrentValue !== null) {
            $url .= "/" . $this->encodeKeyValue($this->AdmissionNo->CurrentValue);
        } else {
            return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
        }
        if ($parm != "") {
            $url .= "?" . $parm;
        }
        return $url;
    }

    // Render sort
    public function renderFieldHeader($fld)
    {
        global $Security, $Language, $Page;
        $sortUrl = "";
        $attrs = "";
        if ($fld->Sortable) {
            $sortUrl = $this->sortUrl($fld);
            $attrs = ' role="button" data-ew-action="sort" data-ajax="' . ($this->UseAjaxActions ? "true" : "false") . '" data-sort-url="' . $sortUrl . '" data-sort-type="1"';
            if ($this->ContextClass) { // Add context
                $attrs .= ' data-context="' . HtmlEncode($this->ContextClass) . '"';
            }
        }
        $html = '<div class="ew-table-header-caption"' . $attrs . '>' . $fld->caption() . '</div>';
        if ($sortUrl) {
            $html .= '<div class="ew-table-header-sort">' . $fld->getSortIcon() . '</div>';
        }
        if ($fld->UseFilter && $Security->canSearch()) {
            $html .= '<div class="ew-filter-dropdown-btn" data-ew-action="filter" data-table="' . $fld->TableVar . '" data-field="' . $fld->FieldVar .
                '"><div class="ew-table-header-filter" role="button" aria-haspopup="true">' . $Language->phrase("Filter") . '</div></div>';
        }
        $html = '<div class="ew-table-header-btn">' . $html . '</div>';
        if ($this->UseCustomTemplate) {
            $scriptId = str_replace("{id}", $fld->TableVar . "_" . $fld->Param, "tpc_{id}");
            $html = '<template id="' . $scriptId . '">' . $html . '</template>';
        }
        return $html;
    }

    // Sort URL
    public function sortUrl($fld)
    {
        global $DashboardReport;
        if (
            $this->CurrentAction || $this->isExport() ||
            in_array($fld->Type, [128, 204, 205])
        ) { // Unsortable data type
                return "";
        } elseif ($fld->Sortable) {
            $urlParm = "order=" . urlencode($fld->Name) . "&amp;ordertype=" . $fld->getNextSort();
            if ($DashboardReport) {
                $urlParm .= "&amp;dashboard=true";
            }
            return $this->addMasterUrl($this->CurrentPageName . "?" . $urlParm);
        } else {
            return "";
        }
    }

    // Get record keys from Post/Get/Session
    public function getRecordKeys()
    {
        $arKeys = [];
        $arKey = [];
        if (Param("key_m") !== null) {
            $arKeys = Param("key_m");
            $cnt = count($arKeys);
        } else {
            if (($keyValue = Param("AdmissionNo") ?? Route("AdmissionNo")) !== null) {
                $arKeys[] = $keyValue;
            } elseif (IsApi() && (($keyValue = Key(0) ?? Route(2)) !== null)) {
                $arKeys[] = $keyValue;
            } else {
                $arKeys = null; // Do not setup
            }

            //return $arKeys; // Do not return yet, so the values will also be checked by the following code
        }
        // Check keys
        $ar = [];
        if (is_array($arKeys)) {
            foreach ($arKeys as $key) {
                if (!is_numeric($key)) {
                    continue;
                }
                $ar[] = $key;
            }
        }
        return $ar;
    }

    // Get filter from records
    public function getFilterFromRecords($rows)
    {
        $keyFilter = "";
        foreach ($rows as $row) {
            if ($keyFilter != "") {
                $keyFilter .= " OR ";
            }
            $keyFilter .= "(" . $this->getRecordFilter($row) . ")";
        }
        return $keyFilter;
    }

    // Get filter from record keys
    public function getFilterFromRecordKeys($setCurrent = true)
    {
        $arKeys = $this->getRecordKeys();
        $keyFilter = "";
        foreach ($arKeys as $key) {
            if ($keyFilter != "") {
                $keyFilter .= " OR ";
            }
            if ($setCurrent) {
                $this->AdmissionNo->CurrentValue = $key;
            } else {
                $this->AdmissionNo->OldValue = $key;
            }
            $keyFilter .= "(" . $this->getRecordFilter() . ")";
        }
        return $keyFilter;
    }

    // Load recordset based on filter
    public function loadRs($filter)
    {
        $sql = $this->getSql($filter); // Set up filter (WHERE Clause)
        $conn = $this->getConnection();
        return $conn->executeQuery($sql);
    }

    // Load row values from record
    public function loadListRowValues(&$rs)
    {
        if (is_array($rs)) {
            $row = $rs;
        } elseif ($rs && property_exists($rs, "fields")) { // Recordset
            $row = $rs->fields;
        } else {
            return;
        }
        $this->AdmissionNo->setDbValue($row['Admission No']);
        $this->FullName->setDbValue($row['Full Name']);
        $this->NameWithInitials->setDbValue($row['Name With Initials']);
        $this->FathersName->setDbValue($row['Father\'s Name']);
        $this->MothersName->setDbValue($row['Mother\'s Name']);
        $this->Address->setDbValue($row['Address']);
        $this->Occupation->setDbValue($row['Occupation']);
        $this->TravellingMethodtoschoo->setDbValue($row['Travelling Method to schoo']);
        $this->inEmergencycontactno->setDbValue($row['in Emergency contact no']);
        $this->Specialneeds->setDbValue($row['Special needs']);
        $this->Grade->setDbValue($row['Grade']);
        $this->prefect->setDbValue($row['prefect']);
    }

    // Render list content
    public function renderListContent($filter)
    {
        global $Response;
        $listPage = "StudentDetailsList";
        $listClass = PROJECT_NAMESPACE . $listPage;
        $page = new $listClass();
        $page->loadRecordsetFromFilter($filter);
        $view = Container("view");
        $template = $listPage . ".php"; // View
        $GLOBALS["Title"] ??= $page->Title; // Title
        try {
            $Response = $view->render($Response, $template, $GLOBALS);
        } finally {
            $page->terminate(); // Terminate page and clean up
        }
    }

    // Render list row values
    public function renderListRow()
    {
        global $Security, $CurrentLanguage, $Language;

        // Call Row Rendering event
        $this->rowRendering();

        // Common render codes

        // Admission No

        // Full Name

        // Name With Initials

        // Father's Name

        // Mother's Name

        // Address

        // Occupation

        // Travelling Method to schoo

        // in Emergency contact no

        // Special needs

        // Grade

        // prefect

        // Admission No
        $this->AdmissionNo->ViewValue = $this->AdmissionNo->CurrentValue;
        $this->AdmissionNo->ViewValue = FormatNumber($this->AdmissionNo->ViewValue, $this->AdmissionNo->formatPattern());

        // Full Name
        $this->FullName->ViewValue = $this->FullName->CurrentValue;

        // Name With Initials
        $this->NameWithInitials->ViewValue = $this->NameWithInitials->CurrentValue;

        // Father's Name
        $this->FathersName->ViewValue = $this->FathersName->CurrentValue;

        // Mother's Name
        $this->MothersName->ViewValue = $this->MothersName->CurrentValue;

        // Address
        $this->Address->ViewValue = $this->Address->CurrentValue;

        // Occupation
        $this->Occupation->ViewValue = $this->Occupation->CurrentValue;

        // Travelling Method to schoo
        if (strval($this->TravellingMethodtoschoo->CurrentValue) != "") {
            $this->TravellingMethodtoschoo->ViewValue = $this->TravellingMethodtoschoo->optionCaption($this->TravellingMethodtoschoo->CurrentValue);
        } else {
            $this->TravellingMethodtoschoo->ViewValue = null;
        }

        // in Emergency contact no
        $this->inEmergencycontactno->ViewValue = $this->inEmergencycontactno->CurrentValue;
        $this->inEmergencycontactno->ViewValue = FormatNumber($this->inEmergencycontactno->ViewValue, $this->inEmergencycontactno->formatPattern());

        // Special needs
        if (ConvertToBool($this->Specialneeds->CurrentValue)) {
            $this->Specialneeds->ViewValue = $this->Specialneeds->tagCaption(1) != "" ? $this->Specialneeds->tagCaption(1) : "Yes";
        } else {
            $this->Specialneeds->ViewValue = $this->Specialneeds->tagCaption(2) != "" ? $this->Specialneeds->tagCaption(2) : "No";
        }

        // Grade
        if (strval($this->Grade->CurrentValue) != "") {
            $this->Grade->ViewValue = $this->Grade->optionCaption($this->Grade->CurrentValue);
        } else {
            $this->Grade->ViewValue = null;
        }

        // prefect
        if (ConvertToBool($this->prefect->CurrentValue)) {
            $this->prefect->ViewValue = $this->prefect->tagCaption(1) != "" ? $this->prefect->tagCaption(1) : "Y";
        } else {
            $this->prefect->ViewValue = $this->prefect->tagCaption(2) != "" ? $this->prefect->tagCaption(2) : "N";
        }

        // Admission No
        $this->AdmissionNo->HrefValue = "";
        $this->AdmissionNo->TooltipValue = "";

        // Full Name
        $this->FullName->HrefValue = "";
        $this->FullName->TooltipValue = "";

        // Name With Initials
        $this->NameWithInitials->HrefValue = "";
        $this->NameWithInitials->TooltipValue = "";

        // Father's Name
        $this->FathersName->HrefValue = "";
        $this->FathersName->TooltipValue = "";

        // Mother's Name
        $this->MothersName->HrefValue = "";
        $this->MothersName->TooltipValue = "";

        // Address
        $this->Address->HrefValue = "";
        $this->Address->TooltipValue = "";

        // Occupation
        $this->Occupation->HrefValue = "";
        $this->Occupation->TooltipValue = "";

        // Travelling Method to schoo
        $this->TravellingMethodtoschoo->HrefValue = "";
        $this->TravellingMethodtoschoo->TooltipValue = "";

        // in Emergency contact no
        $this->inEmergencycontactno->HrefValue = "";
        $this->inEmergencycontactno->TooltipValue = "";

        // Special needs
        $this->Specialneeds->HrefValue = "";
        $this->Specialneeds->TooltipValue = "";

        // Grade
        $this->Grade->HrefValue = "";
        $this->Grade->TooltipValue = "";

        // prefect
        $this->prefect->HrefValue = "";
        $this->prefect->TooltipValue = "";

        // Call Row Rendered event
        $this->rowRendered();

        // Save data for Custom Template
        $this->Rows[] = $this->customTemplateFieldValues();
    }

    // Render edit row values
    public function renderEditRow()
    {
        global $Security, $CurrentLanguage, $Language;

        // Call Row Rendering event
        $this->rowRendering();

        // Admission No
        $this->AdmissionNo->setupEditAttributes();
        $this->AdmissionNo->EditValue = $this->AdmissionNo->CurrentValue;
        $this->AdmissionNo->PlaceHolder = RemoveHtml($this->AdmissionNo->caption());

        // Full Name
        $this->FullName->setupEditAttributes();
        $this->FullName->EditValue = $this->FullName->CurrentValue;
        $this->FullName->PlaceHolder = RemoveHtml($this->FullName->caption());

        // Name With Initials
        $this->NameWithInitials->setupEditAttributes();
        $this->NameWithInitials->EditValue = $this->NameWithInitials->CurrentValue;
        $this->NameWithInitials->PlaceHolder = RemoveHtml($this->NameWithInitials->caption());

        // Father's Name
        $this->FathersName->setupEditAttributes();
        $this->FathersName->EditValue = $this->FathersName->CurrentValue;
        $this->FathersName->PlaceHolder = RemoveHtml($this->FathersName->caption());

        // Mother's Name
        $this->MothersName->setupEditAttributes();
        $this->MothersName->EditValue = $this->MothersName->CurrentValue;
        $this->MothersName->PlaceHolder = RemoveHtml($this->MothersName->caption());

        // Address
        $this->Address->setupEditAttributes();
        $this->Address->EditValue = $this->Address->CurrentValue;
        $this->Address->PlaceHolder = RemoveHtml($this->Address->caption());

        // Occupation
        $this->Occupation->setupEditAttributes();
        $this->Occupation->EditValue = $this->Occupation->CurrentValue;
        $this->Occupation->PlaceHolder = RemoveHtml($this->Occupation->caption());

        // Travelling Method to schoo
        $this->TravellingMethodtoschoo->setupEditAttributes();
        $this->TravellingMethodtoschoo->EditValue = $this->TravellingMethodtoschoo->options(true);
        $this->TravellingMethodtoschoo->PlaceHolder = RemoveHtml($this->TravellingMethodtoschoo->caption());

        // in Emergency contact no
        $this->inEmergencycontactno->setupEditAttributes();
        $this->inEmergencycontactno->EditValue = $this->inEmergencycontactno->CurrentValue;
        $this->inEmergencycontactno->PlaceHolder = RemoveHtml($this->inEmergencycontactno->caption());
        if (strval($this->inEmergencycontactno->EditValue) != "" && is_numeric($this->inEmergencycontactno->EditValue)) {
            $this->inEmergencycontactno->EditValue = FormatNumber($this->inEmergencycontactno->EditValue, null);
        }

        // Special needs
        $this->Specialneeds->EditValue = $this->Specialneeds->options(false);
        $this->Specialneeds->PlaceHolder = RemoveHtml($this->Specialneeds->caption());

        // Grade
        $this->Grade->setupEditAttributes();
        $this->Grade->EditValue = $this->Grade->options(true);
        $this->Grade->PlaceHolder = RemoveHtml($this->Grade->caption());

        // prefect
        $this->prefect->EditValue = $this->prefect->options(false);
        $this->prefect->PlaceHolder = RemoveHtml($this->prefect->caption());

        // Call Row Rendered event
        $this->rowRendered();
    }

    // Aggregate list row values
    public function aggregateListRowValues()
    {
    }

    // Aggregate list row (for rendering)
    public function aggregateListRow()
    {
        // Call Row Rendered event
        $this->rowRendered();
    }

    // Export data in HTML/CSV/Word/Excel/Email/PDF format
    public function exportDocument($doc, $recordset, $startRec = 1, $stopRec = 1, $exportPageType = "")
    {
        if (!$recordset || !$doc) {
            return;
        }
        if (!$doc->ExportCustom) {
            // Write header
            $doc->exportTableHeader();
            if ($doc->Horizontal) { // Horizontal format, write header
                $doc->beginExportRow();
                if ($exportPageType == "view") {
                    $doc->exportCaption($this->AdmissionNo);
                    $doc->exportCaption($this->FullName);
                    $doc->exportCaption($this->NameWithInitials);
                    $doc->exportCaption($this->FathersName);
                    $doc->exportCaption($this->MothersName);
                    $doc->exportCaption($this->Address);
                    $doc->exportCaption($this->Occupation);
                    $doc->exportCaption($this->TravellingMethodtoschoo);
                    $doc->exportCaption($this->inEmergencycontactno);
                    $doc->exportCaption($this->Specialneeds);
                    $doc->exportCaption($this->Grade);
                    $doc->exportCaption($this->prefect);
                } else {
                    $doc->exportCaption($this->AdmissionNo);
                    $doc->exportCaption($this->inEmergencycontactno);
                    $doc->exportCaption($this->Specialneeds);
                    $doc->exportCaption($this->prefect);
                }
                $doc->endExportRow();
            }
        }

        // Move to first record
        $recCnt = $startRec - 1;
        $stopRec = ($stopRec > 0) ? $stopRec : PHP_INT_MAX;
        while (!$recordset->EOF && $recCnt < $stopRec) {
            $row = $recordset->fields;
            $recCnt++;
            if ($recCnt >= $startRec) {
                $rowCnt = $recCnt - $startRec + 1;

                // Page break
                if ($this->ExportPageBreakCount > 0) {
                    if ($rowCnt > 1 && ($rowCnt - 1) % $this->ExportPageBreakCount == 0) {
                        $doc->exportPageBreak();
                    }
                }
                $this->loadListRowValues($row);

                // Render row
                $this->RowType = ROWTYPE_VIEW; // Render view
                $this->resetAttributes();
                $this->renderListRow();
                if (!$doc->ExportCustom) {
                    $doc->beginExportRow($rowCnt); // Allow CSS styles if enabled
                    if ($exportPageType == "view") {
                        $doc->exportField($this->AdmissionNo);
                        $doc->exportField($this->FullName);
                        $doc->exportField($this->NameWithInitials);
                        $doc->exportField($this->FathersName);
                        $doc->exportField($this->MothersName);
                        $doc->exportField($this->Address);
                        $doc->exportField($this->Occupation);
                        $doc->exportField($this->TravellingMethodtoschoo);
                        $doc->exportField($this->inEmergencycontactno);
                        $doc->exportField($this->Specialneeds);
                        $doc->exportField($this->Grade);
                        $doc->exportField($this->prefect);
                    } else {
                        $doc->exportField($this->AdmissionNo);
                        $doc->exportField($this->inEmergencycontactno);
                        $doc->exportField($this->Specialneeds);
                        $doc->exportField($this->prefect);
                    }
                    $doc->endExportRow($rowCnt);
                }
            }

            // Call Row Export server event
            if ($doc->ExportCustom) {
                $this->rowExport($doc, $row);
            }
            $recordset->moveNext();
        }
        if (!$doc->ExportCustom) {
            $doc->exportTableFooter();
        }
    }

    // Get file data
    public function getFileData($fldparm, $key, $resize, $width = 0, $height = 0, $plugins = [])
    {
        global $DownloadFileName;

        // No binary fields
        return false;
    }

    // Table level events

    // Table Load event
    public function tableLoad()
    {
        // Enter your code here
    }

    // Recordset Selecting event
    public function recordsetSelecting(&$filter)
    {
        // Enter your code here
    }

    // Recordset Selected event
    public function recordsetSelected(&$rs)
    {
        //Log("Recordset Selected");
    }

    // Recordset Search Validated event
    public function recordsetSearchValidated()
    {
        // Example:
        //$this->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value
    }

    // Recordset Searching event
    public function recordsetSearching(&$filter)
    {
        // Enter your code here
    }

    // Row_Selecting event
    public function rowSelecting(&$filter)
    {
        // Enter your code here
    }

    // Row Selected event
    public function rowSelected(&$rs)
    {
        //Log("Row Selected");
    }

    // Row Inserting event
    public function rowInserting($rsold, &$rsnew)
    {
        // Enter your code here
        // To cancel, set return value to false
        return true;
    }

    // Row Inserted event
    public function rowInserted($rsold, &$rsnew)
    {
        //Log("Row Inserted");
    }

    // Row Updating event
    public function rowUpdating($rsold, &$rsnew)
    {
        // Enter your code here
        // To cancel, set return value to false
        return true;
    }

    // Row Updated event
    public function rowUpdated($rsold, &$rsnew)
    {
        //Log("Row Updated");
    }

    // Row Update Conflict event
    public function rowUpdateConflict($rsold, &$rsnew)
    {
        // Enter your code here
        // To ignore conflict, set return value to false
        return true;
    }

    // Grid Inserting event
    public function gridInserting()
    {
        // Enter your code here
        // To reject grid insert, set return value to false
        return true;
    }

    // Grid Inserted event
    public function gridInserted($rsnew)
    {
        //Log("Grid Inserted");
    }

    // Grid Updating event
    public function gridUpdating($rsold)
    {
        // Enter your code here
        // To reject grid update, set return value to false
        return true;
    }

    // Grid Updated event
    public function gridUpdated($rsold, $rsnew)
    {
        //Log("Grid Updated");
    }

    // Row Deleting event
    public function rowDeleting(&$rs)
    {
        // Enter your code here
        // To cancel, set return value to False
        return true;
    }

    // Row Deleted event
    public function rowDeleted(&$rs)
    {
        //Log("Row Deleted");
    }

    // Email Sending event
    public function emailSending($email, &$args)
    {
        //var_dump($email, $args); exit();
        return true;
    }

    // Lookup Selecting event
    public function lookupSelecting($fld, &$filter)
    {
        //var_dump($fld->Name, $fld->Lookup, $filter); // Uncomment to view the filter
        // Enter your code here
    }

    // Row Rendering event
    public function rowRendering()
    {
        // Enter your code here
    }

    // Row Rendered event
    public function rowRendered()
    {
        // To view properties of field class, use:
        //var_dump($this-><FieldName>);
    }

    // User ID Filtering event
    public function userIdFiltering(&$filter)
    {
        // Enter your code here
    }
}
