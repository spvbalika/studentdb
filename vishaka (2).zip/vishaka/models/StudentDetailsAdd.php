<?php

namespace PHPMaker2023\vishaka2;

use Doctrine\DBAL\ParameterType;
use Doctrine\DBAL\FetchMode;
use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Query\QueryBuilder;

/**
 * Page class
 */
class StudentDetailsAdd extends StudentDetails
{
    use MessagesTrait;

    // Page ID
    public $PageID = "add";

    // Project ID
    public $ProjectID = PROJECT_ID;

    // Page object name
    public $PageObjName = "StudentDetailsAdd";

    // View file path
    public $View = null;

    // Title
    public $Title = null; // Title for <title> tag

    // Rendering View
    public $RenderingView = false;

    // CSS class/style
    public $CurrentPageName = "StudentDetailsAdd";

    // Page headings
    public $Heading = "";
    public $Subheading = "";
    public $PageHeader;
    public $PageFooter;

    // Page layout
    public $UseLayout = true;

    // Page terminated
    private $terminated = false;

    // Page heading
    public function pageHeading()
    {
        global $Language;
        if ($this->Heading != "") {
            return $this->Heading;
        }
        if (method_exists($this, "tableCaption")) {
            return $this->tableCaption();
        }
        return "";
    }

    // Page subheading
    public function pageSubheading()
    {
        global $Language;
        if ($this->Subheading != "") {
            return $this->Subheading;
        }
        if ($this->TableName) {
            return $Language->phrase($this->PageID);
        }
        return "";
    }

    // Page name
    public function pageName()
    {
        return CurrentPageName();
    }

    // Page URL
    public function pageUrl($withArgs = true)
    {
        $route = GetRoute();
        $args = RemoveXss($route->getArguments());
        if (!$withArgs) {
            foreach ($args as $key => &$val) {
                $val = "";
            }
            unset($val);
        }
        return rtrim(UrlFor($route->getName(), $args), "/") . "?";
    }

    // Show Page Header
    public function showPageHeader()
    {
        $header = $this->PageHeader;
        $this->pageDataRendering($header);
        if ($header != "") { // Header exists, display
            echo '<p id="ew-page-header">' . $header . '</p>';
        }
    }

    // Show Page Footer
    public function showPageFooter()
    {
        $footer = $this->PageFooter;
        $this->pageDataRendered($footer);
        if ($footer != "") { // Footer exists, display
            echo '<p id="ew-page-footer">' . $footer . '</p>';
        }
    }

    // Constructor
    public function __construct()
    {
        parent::__construct();
        global $Language, $DashboardReport, $DebugTimer;
        $this->TableVar = 'student_details';
        $this->TableName = 'student details';

        // Table CSS class
        $this->TableClass = "table table-striped table-bordered table-hover table-sm ew-desktop-table ew-add-table";

        // Initialize
        $GLOBALS["Page"] = &$this;

        // Language object
        $Language = Container("language");

        // Table object (student_details)
        if (!isset($GLOBALS["student_details"]) || get_class($GLOBALS["student_details"]) == PROJECT_NAMESPACE . "student_details") {
            $GLOBALS["student_details"] = &$this;
        }

        // Table name (for backward compatibility only)
        if (!defined(PROJECT_NAMESPACE . "TABLE_NAME")) {
            define(PROJECT_NAMESPACE . "TABLE_NAME", 'student details');
        }

        // Start timer
        $DebugTimer = Container("timer");

        // Debug message
        LoadDebugMessage();

        // Open connection
        $GLOBALS["Conn"] ??= $this->getConnection();
    }

    // Get content from stream
    public function getContents(): string
    {
        global $Response;
        return is_object($Response) ? $Response->getBody() : ob_get_clean();
    }

    // Is lookup
    public function isLookup()
    {
        return SameText(Route(0), Config("API_LOOKUP_ACTION"));
    }

    // Is AutoFill
    public function isAutoFill()
    {
        return $this->isLookup() && SameText(Post("ajax"), "autofill");
    }

    // Is AutoSuggest
    public function isAutoSuggest()
    {
        return $this->isLookup() && SameText(Post("ajax"), "autosuggest");
    }

    // Is modal lookup
    public function isModalLookup()
    {
        return $this->isLookup() && SameText(Post("ajax"), "modal");
    }

    // Is terminated
    public function isTerminated()
    {
        return $this->terminated;
    }

    /**
     * Terminate page
     *
     * @param string $url URL for direction
     * @return void
     */
    public function terminate($url = "")
    {
        if ($this->terminated) {
            return;
        }
        global $TempImages, $DashboardReport, $Response;

        // Page is terminated
        $this->terminated = true;

         // Page Unload event
        if (method_exists($this, "pageUnload")) {
            $this->pageUnload();
        }

        // Global Page Unloaded event (in userfn*.php)
        Page_Unloaded();
        if (!IsApi() && method_exists($this, "pageRedirecting")) {
            $this->pageRedirecting($url);
        }

        // Close connection
        CloseConnections();

        // Return for API
        if (IsApi()) {
            $res = $url === true;
            if (!$res) { // Show response for API
                $ar = array_merge($this->getMessages(), $url ? ["url" => GetUrl($url)] : []);
                WriteJson($ar);
            }
            $this->clearMessages(); // Clear messages for API request
            return;
        } else { // Check if response is JSON
            if (StartsString("application/json", $Response->getHeaderLine("Content-type")) && $Response->getBody()->getSize()) { // With JSON response
                $this->clearMessages();
                return;
            }
        }

        // Go to URL if specified
        if ($url != "") {
            if (!Config("DEBUG") && ob_get_length()) {
                ob_end_clean();
            }

            // Handle modal response
            if ($this->IsModal) { // Show as modal
                $result = ["url" => GetUrl($url), "modal" => "1"];
                $pageName = GetPageName($url);
                if ($pageName != $this->getListUrl()) { // Not List page => View page
                    $result["caption"] = $this->getModalCaption($pageName);
                    $result["view"] = $pageName == "StudentDetailsView";
                } else { // List page
                    // $result["list"] = $this->PageID == "search"; // Refresh List page if current page is Search page
                    $result["error"] = $this->getFailureMessage(); // List page should not be shown as modal => error
                    $this->clearFailureMessage();
                }
                WriteJson($result);
            } else {
                SaveDebugMessage();
                Redirect(GetUrl($url));
            }
        }
        return; // Return to controller
    }

    // Get records from recordset
    protected function getRecordsFromRecordset($rs, $current = false)
    {
        $rows = [];
        if (is_object($rs)) { // Recordset
            while ($rs && !$rs->EOF) {
                $this->loadRowValues($rs); // Set up DbValue/CurrentValue
                $row = $this->getRecordFromArray($rs->fields);
                if ($current) {
                    return $row;
                } else {
                    $rows[] = $row;
                }
                $rs->moveNext();
            }
        } elseif (is_array($rs)) {
            foreach ($rs as $ar) {
                $row = $this->getRecordFromArray($ar);
                if ($current) {
                    return $row;
                } else {
                    $rows[] = $row;
                }
            }
        }
        return $rows;
    }

    // Get record from array
    protected function getRecordFromArray($ar)
    {
        $row = [];
        if (is_array($ar)) {
            foreach ($ar as $fldname => $val) {
                if (array_key_exists($fldname, $this->Fields) && ($this->Fields[$fldname]->Visible || $this->Fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
                    $fld = &$this->Fields[$fldname];
                    if ($fld->HtmlTag == "FILE") { // Upload field
                        if (EmptyValue($val)) {
                            $row[$fldname] = null;
                        } else {
                            if ($fld->DataType == DATATYPE_BLOB) {
                                $url = FullUrl(GetApiUrl(Config("API_FILE_ACTION") .
                                    "/" . $fld->TableVar . "/" . $fld->Param . "/" . rawurlencode($this->getRecordKeyValue($ar))));
                                $row[$fldname] = ["type" => ContentType($val), "url" => $url, "name" => $fld->Param . ContentExtension($val)];
                            } elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
                                $url = FullUrl(GetApiUrl(Config("API_FILE_ACTION") .
                                    "/" . $fld->TableVar . "/" . Encrypt($fld->physicalUploadPath() . $val)));
                                $row[$fldname] = ["type" => MimeContentType($val), "url" => $url, "name" => $val];
                            } else { // Multiple files
                                $files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
                                $ar = [];
                                foreach ($files as $file) {
                                    $url = FullUrl(GetApiUrl(Config("API_FILE_ACTION") .
                                        "/" . $fld->TableVar . "/" . Encrypt($fld->physicalUploadPath() . $file)));
                                    if (!EmptyValue($file)) {
                                        $ar[] = ["type" => MimeContentType($file), "url" => $url, "name" => $file];
                                    }
                                }
                                $row[$fldname] = $ar;
                            }
                        }
                    } else {
                        $row[$fldname] = $val;
                    }
                }
            }
        }
        return $row;
    }

    // Get record key value from array
    protected function getRecordKeyValue($ar)
    {
        $key = "";
        if (is_array($ar)) {
            $key .= @$ar['Admission No'];
        }
        return $key;
    }

    /**
     * Hide fields for add/edit
     *
     * @return void
     */
    protected function hideFieldsForAddEdit()
    {
    }

    // Lookup data
    public function lookup($ar = null)
    {
        global $Language, $Security;

        // Get lookup object
        $fieldName = $ar["field"] ?? Post("field");
        $lookup = $this->Fields[$fieldName]->Lookup;
        $name = $ar["name"] ?? Post("name");
        $isQuery = ContainsString($name, "query_builder_rule");
        if ($isQuery) {
            $lookup->FilterFields = []; // Skip parent fields if any
        }

        // Get lookup parameters
        $lookupType = $ar["ajax"] ?? Post("ajax", "unknown");
        $pageSize = -1;
        $offset = -1;
        $searchValue = "";
        if (SameText($lookupType, "modal") || SameText($lookupType, "filter")) {
            $searchValue = $ar["q"] ?? Param("q") ?? $ar["sv"] ?? Post("sv", "");
            $pageSize = $ar["n"] ?? Param("n") ?? $ar["recperpage"] ?? Post("recperpage", 10);
        } elseif (SameText($lookupType, "autosuggest")) {
            $searchValue = $ar["q"] ?? Param("q", "");
            $pageSize = $ar["n"] ?? Param("n", -1);
            $pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
            if ($pageSize <= 0) {
                $pageSize = Config("AUTO_SUGGEST_MAX_ENTRIES");
            }
        }
        $start = $ar["start"] ?? Param("start", -1);
        $start = is_numeric($start) ? (int)$start : -1;
        $page = $ar["page"] ?? Param("page", -1);
        $page = is_numeric($page) ? (int)$page : -1;
        $offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
        $userSelect = Decrypt($ar["s"] ?? Post("s", ""));
        $userFilter = Decrypt($ar["f"] ?? Post("f", ""));
        $userOrderBy = Decrypt($ar["o"] ?? Post("o", ""));
        $keys = $ar["keys"] ?? Post("keys");
        $lookup->LookupType = $lookupType; // Lookup type
        $lookup->FilterValues = []; // Clear filter values first
        if ($keys !== null) { // Selected records from modal
            if (is_array($keys)) {
                $keys = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $keys);
            }
            $lookup->FilterFields = []; // Skip parent fields if any
            $lookup->FilterValues[] = $keys; // Lookup values
            $pageSize = -1; // Show all records
        } else { // Lookup values
            $lookup->FilterValues[] = $ar["v0"] ?? $ar["lookupValue"] ?? Post("v0", Post("lookupValue", ""));
        }
        $cnt = is_array($lookup->FilterFields) ? count($lookup->FilterFields) : 0;
        for ($i = 1; $i <= $cnt; $i++) {
            $lookup->FilterValues[] = $ar["v" . $i] ?? Post("v" . $i, "");
        }
        $lookup->SearchValue = $searchValue;
        $lookup->PageSize = $pageSize;
        $lookup->Offset = $offset;
        if ($userSelect != "") {
            $lookup->UserSelect = $userSelect;
        }
        if ($userFilter != "") {
            $lookup->UserFilter = $userFilter;
        }
        if ($userOrderBy != "") {
            $lookup->UserOrderBy = $userOrderBy;
        }
        return $lookup->toJson($this, !is_array($ar)); // Use settings from current page
    }
    public $FormClassName = "ew-form ew-add-form";
    public $IsModal = false;
    public $IsMobileOrModal = false;
    public $DbMasterFilter = "";
    public $DbDetailFilter = "";
    public $StartRecord;
    public $Priv = 0;
    public $CopyRecord;

    /**
     * Page run
     *
     * @return void
     */
    public function run()
    {
        global $ExportType, $UserProfile, $Language, $Security, $CurrentForm, $SkipHeaderFooter;

        // Is modal
        $this->IsModal = ConvertToBool(Param("modal"));
        $this->UseLayout = $this->UseLayout && !$this->IsModal;

        // Use layout
        $this->UseLayout = $this->UseLayout && ConvertToBool(Param(Config("PAGE_LAYOUT"), true));

        // View
        $this->View = Get(Config("VIEW"));

        // Create form object
        $CurrentForm = new HttpForm();
        $this->CurrentAction = Param("action"); // Set up current action
        $this->AdmissionNo->setVisibility();
        $this->FullName->setVisibility();
        $this->NameWithInitials->setVisibility();
        $this->FathersName->setVisibility();
        $this->MothersName->setVisibility();
        $this->Address->setVisibility();
        $this->Occupation->setVisibility();
        $this->TravellingMethodtoschoo->setVisibility();
        $this->inEmergencycontactno->setVisibility();
        $this->Specialneeds->setVisibility();
        $this->Grade->setVisibility();
        $this->prefect->setVisibility();

        // Set lookup cache
        if (!in_array($this->PageID, Config("LOOKUP_CACHE_PAGE_IDS"))) {
            $this->setUseLookupCache(false);
        }

        // Global Page Loading event (in userfn*.php)
        Page_Loading();

        // Page Load event
        if (method_exists($this, "pageLoad")) {
            $this->pageLoad();
        }

        // Hide fields for add/edit
        if (!$this->UseAjaxActions) {
            $this->hideFieldsForAddEdit();
        }
        // Use inline delete
        if ($this->UseAjaxActions) {
            $this->InlineDelete = true;
        }

        // Set up lookup cache
        $this->setupLookupOptions($this->TravellingMethodtoschoo);
        $this->setupLookupOptions($this->Specialneeds);
        $this->setupLookupOptions($this->Grade);
        $this->setupLookupOptions($this->prefect);

        // Load default values for add
        $this->loadDefaultValues();

        // Check modal
        if ($this->IsModal) {
            $SkipHeaderFooter = true;
        }
        $this->IsMobileOrModal = IsMobile() || $this->IsModal;
        $postBack = false;

        // Set up current action
        if (IsApi()) {
            $this->CurrentAction = "insert"; // Add record directly
            $postBack = true;
        } elseif (Post("action") !== null) {
            $this->CurrentAction = Post("action"); // Get form action
            $this->setKey(Post($this->OldKeyName));
            $postBack = true;
        } else {
            // Load key values from QueryString
            if (($keyValue = Get("AdmissionNo") ?? Route("AdmissionNo")) !== null) {
                $this->AdmissionNo->setQueryStringValue($keyValue);
            }
            $this->OldKey = $this->getKey(true); // Get from CurrentValue
            $this->CopyRecord = !EmptyValue($this->OldKey);
            if ($this->CopyRecord) {
                $this->CurrentAction = "copy"; // Copy record
            } else {
                $this->CurrentAction = "show"; // Display blank record
            }
        }

        // Load old record or default values
        $rsold = $this->loadOldRecord();

        // Load form values
        if ($postBack) {
            $this->loadFormValues(); // Load form values
        }

        // Validate form if post back
        if ($postBack) {
            if (!$this->validateForm()) {
                $this->EventCancelled = true; // Event cancelled
                $this->restoreFormValues(); // Restore form values
                if (IsApi()) {
                    $this->terminate();
                    return;
                } else {
                    $this->CurrentAction = "show"; // Form error, reset action
                }
            }
        }

        // Perform current action
        switch ($this->CurrentAction) {
            case "copy": // Copy an existing record
                if (!$rsold) { // Record not loaded
                    if ($this->getFailureMessage() == "") {
                        $this->setFailureMessage($Language->phrase("NoRecord")); // No record found
                    }
                    $this->terminate("StudentDetailsList"); // No matching record, return to list
                    return;
                }
                break;
            case "insert": // Add new record
                $this->SendEmail = true; // Send email on add success
                if ($this->addRow($rsold)) {
                    // Do not return Json for UseAjaxActions
                    if ($this->IsModal && $this->UseAjaxActions) {
                        $this->IsModal = false;
                    }
                    if ($this->getSuccessMessage() == "" && Post("addopt") != "1") { // Skip success message for addopt (done in JavaScript)
                        $this->setSuccessMessage($Language->phrase("AddSuccess")); // Set up success message
                    }
                    $returnUrl = $this->getReturnUrl();
                    if (GetPageName($returnUrl) == "StudentDetailsList") {
                        $returnUrl = $this->addMasterUrl($returnUrl); // List page, return to List page with correct master key if necessary
                    } elseif (GetPageName($returnUrl) == "StudentDetailsView") {
                        $returnUrl = $this->getViewUrl(); // View page, return to View page with keyurl directly
                    }
                    if (IsJsonResponse()) { // Return to caller
                        $this->terminate(true);
                        return;
                    } else {
                        $this->terminate($returnUrl);
                        return;
                    }
                } elseif (IsApi()) { // API request, return
                    $this->terminate();
                    return;
                } elseif ($this->UseAjaxActions) { // Return JSON error message
                    WriteJson([ "success" => false, "error" => $this->getFailureMessage() ]);
                    $this->clearFailureMessage();
                    $this->terminate();
                    return; 
                } else {
                    $this->EventCancelled = true; // Event cancelled
                    $this->restoreFormValues(); // Add failed, restore form values
                }
        }

        // Set up Breadcrumb
        $this->setupBreadcrumb();

        // Render row based on row type
        if ($this->isConfirm()) { // Confirm page
            $this->RowType = ROWTYPE_VIEW; // Render view type
        } else {
            $this->RowType = ROWTYPE_ADD; // Render add type
        }

        // Render row
        $this->resetAttributes();
        $this->renderRow();

        // Set LoginStatus / Page_Rendering / Page_Render
        if (!IsApi() && !$this->isTerminated()) {
            // Setup login status
            SetupLoginStatus();

            // Pass login status to client side
            SetClientVar("login", LoginStatus());

            // Global Page Rendering event (in userfn*.php)
            Page_Rendering();

            // Page Render event
            if (method_exists($this, "pageRender")) {
                $this->pageRender();
            }

            // Render search option
            if (method_exists($this, "renderSearchOptions")) {
                $this->renderSearchOptions();
            }
        }
    }

    // Get upload files
    protected function getUploadFiles()
    {
        global $CurrentForm, $Language;
    }

    // Load default values
    protected function loadDefaultValues()
    {
    }

    // Load form values
    protected function loadFormValues()
    {
        // Load from form
        global $CurrentForm;
        $validate = !Config("SERVER_VALIDATE");

        // Check field name 'Admission No' first before field var 'x_AdmissionNo'
        $val = $CurrentForm->hasValue("Admission No") ? $CurrentForm->getValue("Admission No") : $CurrentForm->getValue("x_AdmissionNo");
        if (!$this->AdmissionNo->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->AdmissionNo->Visible = false; // Disable update for API request
            } else {
                $this->AdmissionNo->setFormValue($val, true, $validate);
            }
        }

        // Check field name 'Full Name' first before field var 'x_FullName'
        $val = $CurrentForm->hasValue("Full Name") ? $CurrentForm->getValue("Full Name") : $CurrentForm->getValue("x_FullName");
        if (!$this->FullName->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->FullName->Visible = false; // Disable update for API request
            } else {
                $this->FullName->setFormValue($val);
            }
        }

        // Check field name 'Name With Initials' first before field var 'x_NameWithInitials'
        $val = $CurrentForm->hasValue("Name With Initials") ? $CurrentForm->getValue("Name With Initials") : $CurrentForm->getValue("x_NameWithInitials");
        if (!$this->NameWithInitials->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->NameWithInitials->Visible = false; // Disable update for API request
            } else {
                $this->NameWithInitials->setFormValue($val);
            }
        }

        // Check field name 'Father's Name' first before field var 'x_FathersName'
        $val = $CurrentForm->hasValue("Father's Name") ? $CurrentForm->getValue("Father's Name") : $CurrentForm->getValue("x_FathersName");
        if (!$this->FathersName->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->FathersName->Visible = false; // Disable update for API request
            } else {
                $this->FathersName->setFormValue($val);
            }
        }

        // Check field name 'Mother's Name' first before field var 'x_MothersName'
        $val = $CurrentForm->hasValue("Mother's Name") ? $CurrentForm->getValue("Mother's Name") : $CurrentForm->getValue("x_MothersName");
        if (!$this->MothersName->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->MothersName->Visible = false; // Disable update for API request
            } else {
                $this->MothersName->setFormValue($val);
            }
        }

        // Check field name 'Address' first before field var 'x_Address'
        $val = $CurrentForm->hasValue("Address") ? $CurrentForm->getValue("Address") : $CurrentForm->getValue("x_Address");
        if (!$this->Address->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->Address->Visible = false; // Disable update for API request
            } else {
                $this->Address->setFormValue($val);
            }
        }

        // Check field name 'Occupation' first before field var 'x_Occupation'
        $val = $CurrentForm->hasValue("Occupation") ? $CurrentForm->getValue("Occupation") : $CurrentForm->getValue("x_Occupation");
        if (!$this->Occupation->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->Occupation->Visible = false; // Disable update for API request
            } else {
                $this->Occupation->setFormValue($val);
            }
        }

        // Check field name 'Travelling Method to schoo' first before field var 'x_TravellingMethodtoschoo'
        $val = $CurrentForm->hasValue("Travelling Method to schoo") ? $CurrentForm->getValue("Travelling Method to schoo") : $CurrentForm->getValue("x_TravellingMethodtoschoo");
        if (!$this->TravellingMethodtoschoo->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->TravellingMethodtoschoo->Visible = false; // Disable update for API request
            } else {
                $this->TravellingMethodtoschoo->setFormValue($val);
            }
        }

        // Check field name 'in Emergency contact no' first before field var 'x_inEmergencycontactno'
        $val = $CurrentForm->hasValue("in Emergency contact no") ? $CurrentForm->getValue("in Emergency contact no") : $CurrentForm->getValue("x_inEmergencycontactno");
        if (!$this->inEmergencycontactno->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->inEmergencycontactno->Visible = false; // Disable update for API request
            } else {
                $this->inEmergencycontactno->setFormValue($val, true, $validate);
            }
        }

        // Check field name 'Special needs' first before field var 'x_Specialneeds'
        $val = $CurrentForm->hasValue("Special needs") ? $CurrentForm->getValue("Special needs") : $CurrentForm->getValue("x_Specialneeds");
        if (!$this->Specialneeds->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->Specialneeds->Visible = false; // Disable update for API request
            } else {
                $this->Specialneeds->setFormValue($val);
            }
        }

        // Check field name 'Grade' first before field var 'x_Grade'
        $val = $CurrentForm->hasValue("Grade") ? $CurrentForm->getValue("Grade") : $CurrentForm->getValue("x_Grade");
        if (!$this->Grade->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->Grade->Visible = false; // Disable update for API request
            } else {
                $this->Grade->setFormValue($val);
            }
        }

        // Check field name 'prefect' first before field var 'x_prefect'
        $val = $CurrentForm->hasValue("prefect") ? $CurrentForm->getValue("prefect") : $CurrentForm->getValue("x_prefect");
        if (!$this->prefect->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->prefect->Visible = false; // Disable update for API request
            } else {
                $this->prefect->setFormValue($val);
            }
        }
    }

    // Restore form values
    public function restoreFormValues()
    {
        global $CurrentForm;
        $this->AdmissionNo->CurrentValue = $this->AdmissionNo->FormValue;
        $this->FullName->CurrentValue = $this->FullName->FormValue;
        $this->NameWithInitials->CurrentValue = $this->NameWithInitials->FormValue;
        $this->FathersName->CurrentValue = $this->FathersName->FormValue;
        $this->MothersName->CurrentValue = $this->MothersName->FormValue;
        $this->Address->CurrentValue = $this->Address->FormValue;
        $this->Occupation->CurrentValue = $this->Occupation->FormValue;
        $this->TravellingMethodtoschoo->CurrentValue = $this->TravellingMethodtoschoo->FormValue;
        $this->inEmergencycontactno->CurrentValue = $this->inEmergencycontactno->FormValue;
        $this->Specialneeds->CurrentValue = $this->Specialneeds->FormValue;
        $this->Grade->CurrentValue = $this->Grade->FormValue;
        $this->prefect->CurrentValue = $this->prefect->FormValue;
    }

    /**
     * Load row based on key values
     *
     * @return void
     */
    public function loadRow()
    {
        global $Security, $Language;
        $filter = $this->getRecordFilter();

        // Call Row Selecting event
        $this->rowSelecting($filter);

        // Load SQL based on filter
        $this->CurrentFilter = $filter;
        $sql = $this->getCurrentSql();
        $conn = $this->getConnection();
        $res = false;
        $row = $conn->fetchAssociative($sql);
        if ($row) {
            $res = true;
            $this->loadRowValues($row); // Load row values
        }
        return $res;
    }

    /**
     * Load row values from recordset or record
     *
     * @param Recordset|array $rs Record
     * @return void
     */
    public function loadRowValues($rs = null)
    {
        if (is_array($rs)) {
            $row = $rs;
        } elseif ($rs && property_exists($rs, "fields")) { // Recordset
            $row = $rs->fields;
        } else {
            $row = $this->newRow();
        }
        if (!$row) {
            return;
        }

        // Call Row Selected event
        $this->rowSelected($row);
        $this->AdmissionNo->setDbValue($row['Admission No']);
        $this->FullName->setDbValue($row['Full Name']);
        $this->NameWithInitials->setDbValue($row['Name With Initials']);
        $this->FathersName->setDbValue($row['Father\'s Name']);
        $this->MothersName->setDbValue($row['Mother\'s Name']);
        $this->Address->setDbValue($row['Address']);
        $this->Occupation->setDbValue($row['Occupation']);
        $this->TravellingMethodtoschoo->setDbValue($row['Travelling Method to schoo']);
        $this->inEmergencycontactno->setDbValue($row['in Emergency contact no']);
        $this->Specialneeds->setDbValue($row['Special needs']);
        $this->Grade->setDbValue($row['Grade']);
        $this->prefect->setDbValue($row['prefect']);
    }

    // Return a row with default values
    protected function newRow()
    {
        $row = [];
        $row['Admission No'] = $this->AdmissionNo->DefaultValue;
        $row['Full Name'] = $this->FullName->DefaultValue;
        $row['Name With Initials'] = $this->NameWithInitials->DefaultValue;
        $row['Father\'s Name'] = $this->FathersName->DefaultValue;
        $row['Mother\'s Name'] = $this->MothersName->DefaultValue;
        $row['Address'] = $this->Address->DefaultValue;
        $row['Occupation'] = $this->Occupation->DefaultValue;
        $row['Travelling Method to schoo'] = $this->TravellingMethodtoschoo->DefaultValue;
        $row['in Emergency contact no'] = $this->inEmergencycontactno->DefaultValue;
        $row['Special needs'] = $this->Specialneeds->DefaultValue;
        $row['Grade'] = $this->Grade->DefaultValue;
        $row['prefect'] = $this->prefect->DefaultValue;
        return $row;
    }

    // Load old record
    protected function loadOldRecord()
    {
        // Load old record
        if ($this->OldKey != "") {
            $this->setKey($this->OldKey);
            $this->CurrentFilter = $this->getRecordFilter();
            $sql = $this->getCurrentSql();
            $conn = $this->getConnection();
            $rs = LoadRecordset($sql, $conn);
            if ($rs && ($row = $rs->fields)) {
                $this->loadRowValues($row); // Load row values
                return $row;
            }
        }
        $this->loadRowValues(); // Load default row values
        return null;
    }

    // Render row values based on field settings
    public function renderRow()
    {
        global $Security, $Language, $CurrentLanguage;

        // Initialize URLs

        // Call Row_Rendering event
        $this->rowRendering();

        // Common render codes for all row types

        // Admission No
        $this->AdmissionNo->RowCssClass = "row";

        // Full Name
        $this->FullName->RowCssClass = "row";

        // Name With Initials
        $this->NameWithInitials->RowCssClass = "row";

        // Father's Name
        $this->FathersName->RowCssClass = "row";

        // Mother's Name
        $this->MothersName->RowCssClass = "row";

        // Address
        $this->Address->RowCssClass = "row";

        // Occupation
        $this->Occupation->RowCssClass = "row";

        // Travelling Method to schoo
        $this->TravellingMethodtoschoo->RowCssClass = "row";

        // in Emergency contact no
        $this->inEmergencycontactno->RowCssClass = "row";

        // Special needs
        $this->Specialneeds->RowCssClass = "row";

        // Grade
        $this->Grade->RowCssClass = "row";

        // prefect
        $this->prefect->RowCssClass = "row";

        // View row
        if ($this->RowType == ROWTYPE_VIEW) {
            // Admission No
            $this->AdmissionNo->ViewValue = $this->AdmissionNo->CurrentValue;
            $this->AdmissionNo->ViewValue = FormatNumber($this->AdmissionNo->ViewValue, $this->AdmissionNo->formatPattern());

            // Full Name
            $this->FullName->ViewValue = $this->FullName->CurrentValue;

            // Name With Initials
            $this->NameWithInitials->ViewValue = $this->NameWithInitials->CurrentValue;

            // Father's Name
            $this->FathersName->ViewValue = $this->FathersName->CurrentValue;

            // Mother's Name
            $this->MothersName->ViewValue = $this->MothersName->CurrentValue;

            // Address
            $this->Address->ViewValue = $this->Address->CurrentValue;

            // Occupation
            $this->Occupation->ViewValue = $this->Occupation->CurrentValue;

            // Travelling Method to schoo
            if (strval($this->TravellingMethodtoschoo->CurrentValue) != "") {
                $this->TravellingMethodtoschoo->ViewValue = $this->TravellingMethodtoschoo->optionCaption($this->TravellingMethodtoschoo->CurrentValue);
            } else {
                $this->TravellingMethodtoschoo->ViewValue = null;
            }

            // in Emergency contact no
            $this->inEmergencycontactno->ViewValue = $this->inEmergencycontactno->CurrentValue;
            $this->inEmergencycontactno->ViewValue = FormatNumber($this->inEmergencycontactno->ViewValue, $this->inEmergencycontactno->formatPattern());

            // Special needs
            if (ConvertToBool($this->Specialneeds->CurrentValue)) {
                $this->Specialneeds->ViewValue = $this->Specialneeds->tagCaption(1) != "" ? $this->Specialneeds->tagCaption(1) : "Yes";
            } else {
                $this->Specialneeds->ViewValue = $this->Specialneeds->tagCaption(2) != "" ? $this->Specialneeds->tagCaption(2) : "No";
            }

            // Grade
            if (strval($this->Grade->CurrentValue) != "") {
                $this->Grade->ViewValue = $this->Grade->optionCaption($this->Grade->CurrentValue);
            } else {
                $this->Grade->ViewValue = null;
            }

            // prefect
            if (ConvertToBool($this->prefect->CurrentValue)) {
                $this->prefect->ViewValue = $this->prefect->tagCaption(1) != "" ? $this->prefect->tagCaption(1) : "Y";
            } else {
                $this->prefect->ViewValue = $this->prefect->tagCaption(2) != "" ? $this->prefect->tagCaption(2) : "N";
            }

            // Admission No
            $this->AdmissionNo->HrefValue = "";

            // Full Name
            $this->FullName->HrefValue = "";

            // Name With Initials
            $this->NameWithInitials->HrefValue = "";

            // Father's Name
            $this->FathersName->HrefValue = "";

            // Mother's Name
            $this->MothersName->HrefValue = "";

            // Address
            $this->Address->HrefValue = "";

            // Occupation
            $this->Occupation->HrefValue = "";

            // Travelling Method to schoo
            $this->TravellingMethodtoschoo->HrefValue = "";

            // in Emergency contact no
            $this->inEmergencycontactno->HrefValue = "";

            // Special needs
            $this->Specialneeds->HrefValue = "";

            // Grade
            $this->Grade->HrefValue = "";

            // prefect
            $this->prefect->HrefValue = "";
        } elseif ($this->RowType == ROWTYPE_ADD) {
            // Admission No
            $this->AdmissionNo->setupEditAttributes();
            $this->AdmissionNo->EditValue = HtmlEncode($this->AdmissionNo->CurrentValue);
            $this->AdmissionNo->PlaceHolder = RemoveHtml($this->AdmissionNo->caption());
            if (strval($this->AdmissionNo->EditValue) != "" && is_numeric($this->AdmissionNo->EditValue)) {
                $this->AdmissionNo->EditValue = FormatNumber($this->AdmissionNo->EditValue, null);
            }

            // Full Name
            $this->FullName->setupEditAttributes();
            $this->FullName->EditValue = HtmlEncode($this->FullName->CurrentValue);
            $this->FullName->PlaceHolder = RemoveHtml($this->FullName->caption());

            // Name With Initials
            $this->NameWithInitials->setupEditAttributes();
            $this->NameWithInitials->EditValue = HtmlEncode($this->NameWithInitials->CurrentValue);
            $this->NameWithInitials->PlaceHolder = RemoveHtml($this->NameWithInitials->caption());

            // Father's Name
            $this->FathersName->setupEditAttributes();
            $this->FathersName->EditValue = HtmlEncode($this->FathersName->CurrentValue);
            $this->FathersName->PlaceHolder = RemoveHtml($this->FathersName->caption());

            // Mother's Name
            $this->MothersName->setupEditAttributes();
            $this->MothersName->EditValue = HtmlEncode($this->MothersName->CurrentValue);
            $this->MothersName->PlaceHolder = RemoveHtml($this->MothersName->caption());

            // Address
            $this->Address->setupEditAttributes();
            $this->Address->EditValue = HtmlEncode($this->Address->CurrentValue);
            $this->Address->PlaceHolder = RemoveHtml($this->Address->caption());

            // Occupation
            $this->Occupation->setupEditAttributes();
            $this->Occupation->EditValue = HtmlEncode($this->Occupation->CurrentValue);
            $this->Occupation->PlaceHolder = RemoveHtml($this->Occupation->caption());

            // Travelling Method to schoo
            $this->TravellingMethodtoschoo->setupEditAttributes();
            $this->TravellingMethodtoschoo->EditValue = $this->TravellingMethodtoschoo->options(true);
            $this->TravellingMethodtoschoo->PlaceHolder = RemoveHtml($this->TravellingMethodtoschoo->caption());

            // in Emergency contact no
            $this->inEmergencycontactno->setupEditAttributes();
            $this->inEmergencycontactno->EditValue = HtmlEncode($this->inEmergencycontactno->CurrentValue);
            $this->inEmergencycontactno->PlaceHolder = RemoveHtml($this->inEmergencycontactno->caption());
            if (strval($this->inEmergencycontactno->EditValue) != "" && is_numeric($this->inEmergencycontactno->EditValue)) {
                $this->inEmergencycontactno->EditValue = FormatNumber($this->inEmergencycontactno->EditValue, null);
            }

            // Special needs
            $this->Specialneeds->EditValue = $this->Specialneeds->options(false);
            $this->Specialneeds->PlaceHolder = RemoveHtml($this->Specialneeds->caption());

            // Grade
            $this->Grade->setupEditAttributes();
            $this->Grade->EditValue = $this->Grade->options(true);
            $this->Grade->PlaceHolder = RemoveHtml($this->Grade->caption());

            // prefect
            $this->prefect->EditValue = $this->prefect->options(false);
            $this->prefect->PlaceHolder = RemoveHtml($this->prefect->caption());

            // Add refer script

            // Admission No
            $this->AdmissionNo->HrefValue = "";

            // Full Name
            $this->FullName->HrefValue = "";

            // Name With Initials
            $this->NameWithInitials->HrefValue = "";

            // Father's Name
            $this->FathersName->HrefValue = "";

            // Mother's Name
            $this->MothersName->HrefValue = "";

            // Address
            $this->Address->HrefValue = "";

            // Occupation
            $this->Occupation->HrefValue = "";

            // Travelling Method to schoo
            $this->TravellingMethodtoschoo->HrefValue = "";

            // in Emergency contact no
            $this->inEmergencycontactno->HrefValue = "";

            // Special needs
            $this->Specialneeds->HrefValue = "";

            // Grade
            $this->Grade->HrefValue = "";

            // prefect
            $this->prefect->HrefValue = "";
        }
        if ($this->RowType == ROWTYPE_ADD || $this->RowType == ROWTYPE_EDIT || $this->RowType == ROWTYPE_SEARCH) { // Add/Edit/Search row
            $this->setupFieldTitles();
        }

        // Call Row Rendered event
        if ($this->RowType != ROWTYPE_AGGREGATEINIT) {
            $this->rowRendered();
        }
    }

    // Validate form
    protected function validateForm()
    {
        global $Language, $Security;

        // Check if validation required
        if (!Config("SERVER_VALIDATE")) {
            return true;
        }
        $validateForm = true;
        if ($this->AdmissionNo->Required) {
            if (!$this->AdmissionNo->IsDetailKey && EmptyValue($this->AdmissionNo->FormValue)) {
                $this->AdmissionNo->addErrorMessage(str_replace("%s", $this->AdmissionNo->caption(), $this->AdmissionNo->RequiredErrorMessage));
            }
        }
        if (!CheckInteger($this->AdmissionNo->FormValue)) {
            $this->AdmissionNo->addErrorMessage($this->AdmissionNo->getErrorMessage(false));
        }
        if ($this->FullName->Required) {
            if (!$this->FullName->IsDetailKey && EmptyValue($this->FullName->FormValue)) {
                $this->FullName->addErrorMessage(str_replace("%s", $this->FullName->caption(), $this->FullName->RequiredErrorMessage));
            }
        }
        if ($this->NameWithInitials->Required) {
            if (!$this->NameWithInitials->IsDetailKey && EmptyValue($this->NameWithInitials->FormValue)) {
                $this->NameWithInitials->addErrorMessage(str_replace("%s", $this->NameWithInitials->caption(), $this->NameWithInitials->RequiredErrorMessage));
            }
        }
        if ($this->FathersName->Required) {
            if (!$this->FathersName->IsDetailKey && EmptyValue($this->FathersName->FormValue)) {
                $this->FathersName->addErrorMessage(str_replace("%s", $this->FathersName->caption(), $this->FathersName->RequiredErrorMessage));
            }
        }
        if ($this->MothersName->Required) {
            if (!$this->MothersName->IsDetailKey && EmptyValue($this->MothersName->FormValue)) {
                $this->MothersName->addErrorMessage(str_replace("%s", $this->MothersName->caption(), $this->MothersName->RequiredErrorMessage));
            }
        }
        if ($this->Address->Required) {
            if (!$this->Address->IsDetailKey && EmptyValue($this->Address->FormValue)) {
                $this->Address->addErrorMessage(str_replace("%s", $this->Address->caption(), $this->Address->RequiredErrorMessage));
            }
        }
        if ($this->Occupation->Required) {
            if (!$this->Occupation->IsDetailKey && EmptyValue($this->Occupation->FormValue)) {
                $this->Occupation->addErrorMessage(str_replace("%s", $this->Occupation->caption(), $this->Occupation->RequiredErrorMessage));
            }
        }
        if ($this->TravellingMethodtoschoo->Required) {
            if (!$this->TravellingMethodtoschoo->IsDetailKey && EmptyValue($this->TravellingMethodtoschoo->FormValue)) {
                $this->TravellingMethodtoschoo->addErrorMessage(str_replace("%s", $this->TravellingMethodtoschoo->caption(), $this->TravellingMethodtoschoo->RequiredErrorMessage));
            }
        }
        if ($this->inEmergencycontactno->Required) {
            if (!$this->inEmergencycontactno->IsDetailKey && EmptyValue($this->inEmergencycontactno->FormValue)) {
                $this->inEmergencycontactno->addErrorMessage(str_replace("%s", $this->inEmergencycontactno->caption(), $this->inEmergencycontactno->RequiredErrorMessage));
            }
        }
        if (!CheckInteger($this->inEmergencycontactno->FormValue)) {
            $this->inEmergencycontactno->addErrorMessage($this->inEmergencycontactno->getErrorMessage(false));
        }
        if ($this->Specialneeds->Required) {
            if ($this->Specialneeds->FormValue == "") {
                $this->Specialneeds->addErrorMessage(str_replace("%s", $this->Specialneeds->caption(), $this->Specialneeds->RequiredErrorMessage));
            }
        }
        if ($this->Grade->Required) {
            if (!$this->Grade->IsDetailKey && EmptyValue($this->Grade->FormValue)) {
                $this->Grade->addErrorMessage(str_replace("%s", $this->Grade->caption(), $this->Grade->RequiredErrorMessage));
            }
        }
        if ($this->prefect->Required) {
            if ($this->prefect->FormValue == "") {
                $this->prefect->addErrorMessage(str_replace("%s", $this->prefect->caption(), $this->prefect->RequiredErrorMessage));
            }
        }

        // Return validate result
        $validateForm = $validateForm && !$this->hasInvalidFields();

        // Call Form_CustomValidate event
        $formCustomError = "";
        $validateForm = $validateForm && $this->formCustomValidate($formCustomError);
        if ($formCustomError != "") {
            $this->setFailureMessage($formCustomError);
        }
        return $validateForm;
    }

    // Add record
    protected function addRow($rsold = null)
    {
        global $Language, $Security;

        // Set new row
        $rsnew = [];

        // Admission No
        $this->AdmissionNo->setDbValueDef($rsnew, $this->AdmissionNo->CurrentValue, 0, false);

        // Full Name
        $this->FullName->setDbValueDef($rsnew, $this->FullName->CurrentValue, "", false);

        // Name With Initials
        $this->NameWithInitials->setDbValueDef($rsnew, $this->NameWithInitials->CurrentValue, "", false);

        // Father's Name
        $this->FathersName->setDbValueDef($rsnew, $this->FathersName->CurrentValue, "", false);

        // Mother's Name
        $this->MothersName->setDbValueDef($rsnew, $this->MothersName->CurrentValue, "", false);

        // Address
        $this->Address->setDbValueDef($rsnew, $this->Address->CurrentValue, "", false);

        // Occupation
        $this->Occupation->setDbValueDef($rsnew, $this->Occupation->CurrentValue, "", false);

        // Travelling Method to schoo
        $this->TravellingMethodtoschoo->setDbValueDef($rsnew, $this->TravellingMethodtoschoo->CurrentValue, "", false);

        // in Emergency contact no
        $this->inEmergencycontactno->setDbValueDef($rsnew, $this->inEmergencycontactno->CurrentValue, 0, false);

        // Special needs
        $this->Specialneeds->setDbValueDef($rsnew, strval($this->Specialneeds->CurrentValue) == "1" ? "1" : "0", 0, false);

        // Grade
        $this->Grade->setDbValueDef($rsnew, $this->Grade->CurrentValue, "", false);

        // prefect
        $this->prefect->setDbValueDef($rsnew, strval($this->prefect->CurrentValue) == "1" ? "1" : "0", 0, false);

        // Update current values
        $this->setCurrentValues($rsnew);
        if ($this->AdmissionNo->CurrentValue != "") { // Check field with unique index
            $filter = "(`Admission No` = " . AdjustSql($this->AdmissionNo->CurrentValue, $this->Dbid) . ")";
            $rsChk = $this->loadRs($filter)->fetch();
            if ($rsChk !== false) {
                $idxErrMsg = str_replace("%f", $this->AdmissionNo->caption(), $Language->phrase("DupIndex"));
                $idxErrMsg = str_replace("%v", $this->AdmissionNo->CurrentValue, $idxErrMsg);
                $this->setFailureMessage($idxErrMsg);
                return false;
            }
        }
        $conn = $this->getConnection();

        // Load db values from old row
        $this->loadDbValues($rsold);

        // Call Row Inserting event
        $insertRow = $this->rowInserting($rsold, $rsnew);

        // Check if key value entered
        if ($insertRow && $this->ValidateKey && strval($rsnew['Admission No']) == "") {
            $this->setFailureMessage($Language->phrase("InvalidKeyValue"));
            $insertRow = false;
        }

        // Check for duplicate key
        if ($insertRow && $this->ValidateKey) {
            $filter = $this->getRecordFilter($rsnew);
            $rsChk = $this->loadRs($filter)->fetch();
            if ($rsChk !== false) {
                $keyErrMsg = str_replace("%f", $filter, $Language->phrase("DupKey"));
                $this->setFailureMessage($keyErrMsg);
                $insertRow = false;
            }
        }
        if ($insertRow) {
            $addRow = $this->insert($rsnew);
            if ($addRow) {
            } elseif (!EmptyValue($this->DbErrorMessage)) { // Show database error
                $this->setFailureMessage($this->DbErrorMessage);
            }
        } else {
            if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {
                // Use the message, do nothing
            } elseif ($this->CancelMessage != "") {
                $this->setFailureMessage($this->CancelMessage);
                $this->CancelMessage = "";
            } else {
                $this->setFailureMessage($Language->phrase("InsertCancelled"));
            }
            $addRow = false;
        }
        if ($addRow) {
            // Call Row Inserted event
            $this->rowInserted($rsold, $rsnew);
        }

        // Write JSON response
        if (IsJsonResponse() && $addRow) {
            $row = $this->getRecordsFromRecordset([$rsnew], true);
            $table = $this->TableVar;
            WriteJson(["success" => true, "action" => Config("API_ADD_ACTION"), $table => $row]);
        }
        return $addRow;
    }

    // Set up Breadcrumb
    protected function setupBreadcrumb()
    {
        global $Breadcrumb, $Language;
        $Breadcrumb = new Breadcrumb("index");
        $url = CurrentUrl();
        $Breadcrumb->add("list", $this->TableVar, $this->addMasterUrl("StudentDetailsList"), "", $this->TableVar, true);
        $pageId = ($this->isCopy()) ? "Copy" : "Add";
        $Breadcrumb->add("add", $pageId, $url);
    }

    // Setup lookup options
    public function setupLookupOptions($fld)
    {
        if ($fld->Lookup !== null && $fld->Lookup->Options === null) {
            // Get default connection and filter
            $conn = $this->getConnection();
            $lookupFilter = "";

            // No need to check any more
            $fld->Lookup->Options = [];

            // Set up lookup SQL and connection
            switch ($fld->FieldVar) {
                case "x_TravellingMethodtoschoo":
                    break;
                case "x_Specialneeds":
                    break;
                case "x_Grade":
                    break;
                case "x_prefect":
                    break;
                default:
                    $lookupFilter = "";
                    break;
            }

            // Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
            $sql = $fld->Lookup->getSql(false, "", $lookupFilter, $this);

            // Set up lookup cache
            if (!$fld->hasLookupOptions() && $fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0) {
                $totalCnt = $this->getRecordCount($sql, $conn);
                if ($totalCnt > $fld->LookupCacheCount) { // Total count > cache count, do not cache
                    return;
                }
                $rows = $conn->executeQuery($sql)->fetchAll();
                $ar = [];
                foreach ($rows as $row) {
                    $row = $fld->Lookup->renderViewRow($row, Container($fld->Lookup->LinkTable));
                    $key = $row["lf"];
                    if (IsFloatType($fld->Type)) { // Handle float field
                        $key = (float)$key;
                    }
                    $ar[strval($key)] = $row;
                }
                $fld->Lookup->Options = $ar;
            }
        }
    }

    // Page Load event
    public function pageLoad()
    {
        //Log("Page Load");
    }

    // Page Unload event
    public function pageUnload()
    {
        //Log("Page Unload");
    }

    // Page Redirecting event
    public function pageRedirecting(&$url)
    {
        // Example:
        //$url = "your URL";
    }

    // Message Showing event
    // $type = ''|'success'|'failure'|'warning'
    public function messageShowing(&$msg, $type)
    {
        if ($type == 'success') {
            //$msg = "your success message";
        } elseif ($type == 'failure') {
            //$msg = "your failure message";
        } elseif ($type == 'warning') {
            //$msg = "your warning message";
        } else {
            //$msg = "your message";
        }
    }

    // Page Render event
    public function pageRender()
    {
        //Log("Page Render");
    }

    // Page Data Rendering event
    public function pageDataRendering(&$header)
    {
        // Example:
        //$header = "your header";
    }

    // Page Data Rendered event
    public function pageDataRendered(&$footer)
    {
        // Example:
        //$footer = "your footer";
    }

    // Page Breaking event
    public function pageBreaking(&$break, &$content)
    {
        // Example:
        //$break = false; // Skip page break, or
        //$content = "<div style=\"break-after:page;\"></div>"; // Modify page break content
    }

    // Form Custom Validate event
    public function formCustomValidate(&$customError)
    {
        // Return error message in $customError
        return true;
    }
}
